from django.urls import path
from Home import views


urlpatterns = [
    path('Dashboard', views.Dashboard, name='Dashboard'),
    path('Layout', views.Layout, name='Layout'),
]