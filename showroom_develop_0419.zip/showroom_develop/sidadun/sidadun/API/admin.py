from django.contrib import admin

# Register your models here.
from API.models import Heatmap_mainlist, Area_mainlist, AreaVisitor_mainlist, Visitor_mainlist, Avgtime_mainlist

admin.site.register(Heatmap_mainlist)
admin.site.register(Area_mainlist)
admin.site.register(AreaVisitor_mainlist)
admin.site.register(Visitor_mainlist)
admin.site.register(Avgtime_mainlist)