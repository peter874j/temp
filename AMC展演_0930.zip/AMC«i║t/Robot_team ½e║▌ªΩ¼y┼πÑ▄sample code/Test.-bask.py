from operator import methodcaller
from flask import Flask, Response, render_template
from camera_video_read import ImageCapture
import cv2
from threading import Thread

class f(Flask):
    def __init__(self) -> None:
        self.app = Flask(__name__)
    
    @Flask.app.route("/stream", methods=['GET'])
    def displayStream(self):
        return Response(self.get(), mimetype='multipart/x-mixed-replace; boundary=frame') 
    
    def push_img(self, img):
        img = cv2.imencode(".jpg", img)
        encodedImage = b'--frame\r\n' b'Content-Type: image/jpeg\r\n\r\n' + bytearray(encodedImage) + b'\r\n'
        yield encodedImage 

if __name__ == "__main__":
    tranfer = f()
    while True:
        img = get_capture()
        f.push_img(img)


app = Flask(__name__)

@app.route("/stream", methods=['GET'])
def displayStream():
    return Response(get(), mimetype='multipart/x-mixed-replace; boundary=frame') 


def get():
    while(True):
        frame = cap.getframe()
        (flag, encodedImage) = cv2.imencode(".jpg", frame)         
        if flag: 
            encodedImage = b'--frame\r\n' b'Content-Type: image/jpeg\r\n\r\n' + bytearray(encodedImage) + b'\r\n'
            yield encodedImage 


@app.route("/hello", methods=['GET'])
def main():
    return render_template('Test.html')


if __name__ == "__main__":
    cap = ImageCapture("0")
    app.run(host='localhost', port=5001, debug=True, use_reloader=False)
    
    
