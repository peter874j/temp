var info = new Vue({
    el: "#info",
    data: {
        isDisplay: true
    }
})

var app = new Vue({
    el: "#app",
    data: {
        AreaData1: [],
        AreaData2: [],
        VisitorOptions: [],
        AllCount: {
            week_day: [],
            data: []
        },
        AreaVisitor: {
            area: [],
            max: [],
            avg: []
        },
        VisitorData: {},
        SelectVisitor: 'All',
        FilterData: {
            SelectStartDate: null,
            SelectEndDate: null,
            SelectDate: null,
            SelectType: 'all',
            SelectGoal: 'all'
        },
        ChartSearchData: ''
    },
    created: function () {
        this.init();
    },
    methods: {
        init: async function () {
            let self = this;
            await self.LoadAllCountOneWeekData();
            await self.LoadVisitorData();
            await self.LoadAreaVisitorAllCountData();
            await self.GetVisitor();
            await self.GetArea();
            await self.CreateAllCountChart();
            await self.CreateAreaVisitorChart();
        },
        async LoadAllCountOneWeekData() {
            let self = this;
            await axios.get('../API/GetAllCountOneWeek')
                .then((res) => {
                    self.AllCount.week_day = res.data['week_day'];
                    self.AllCount.data = res.data['data'];
                    // console.log(self.AllCount.week_day);
                    // console.log(self.AllCount.data);
                })
                .catch((error) => {
                    console.log('LoadAllCountOneWeekData:', error);
                });
        },
        async LoadAllCountTwoWeekData() {
            let self = this;
            await axios.get('../API/GetAllCountTwoWeek')
                .then((res) => {
                    self.AllCount.week_day = res.data['week_day'];
                    self.AllCount.data = res.data['data'];
                    // console.log(self.AllCount.week_day);
                    // console.log(self.AllCount.data);
                })
                .catch((error) => {
                    console.log('LoadAllCountTwoWeekData:', error);
                });
        },
        async LoadAreaVisitorAllCountData() {
            let self = this;
            await axios.get('../API/GetAreaVisitorAllCount')
                .then((res) => {
                    console.log('LoadAreaVisitorAllCountData:', res.data);
                    self.AreaVisitor.area = res.data[0];
                    self.AreaVisitor.max = res.data[1];
                    self.AreaVisitor.avg = res.data[2];
                    // console.log(self.AreaVisitor.area);
                    // console.log(self.AreaVisitor.max);
                    // console.log(self.AreaVisitor.avg);
                })
                .catch((error) => {
                    console.log('LoadAreaVisitorAllCountData:', error);
                });
        },
        async LoadAreaVisitorFilterCountData() {
            let self = this;

            self.FilterData.SelectDate = self.FilterData.SelectStartDate + '_' + self.FilterData.SelectEndDate
            console.log('LoadAreaVisitorFilterCountData_SelectDate:', self.FilterData.SelectDate);

            if (self.FilterData.SelectGoal != 'all' || self.FilterData.SelectType != 'all') {
                // console.log('self.ChartSearchData', self.ChartSearchData);
                var result = self.ChartSearchData.split('<br>');                
                var filter_time = [];
                for (var i = 0; i < result.length; i++) {
                    console.log(result[i].split('&nbsp;&nbsp;&nbsp;'))
                    filter_time.push(result[i].split('&nbsp;&nbsp;&nbsp;')[1])
                }
                var filter_time_str = `&`
                for (var j = 0; j < filter_time.length; j++) {
                    filter_time_str += 'filter_time=' + filter_time[j]
                    if (j+1 != filter_time.length) {
                        filter_time_str += '&'
                    }
                }
                console.log('filter_time_str:', filter_time_str);
            }
            // 訪客和類型都是all
            else {
                var filter_time_str = ``
            }

            var filter_url = `../API/GetAreaVisitorFilterCount?insert_time=${self.FilterData.SelectDate}` + filter_time_str
            console.log('Count filter_url:', filter_url);
            
            await axios.get(filter_url)
                .then((res) => {
                    console.log('LoadAreaVisitorFilterCountData:', res.data);
                    self.AreaVisitor.area = res.data[0];
                    self.AreaVisitor.max = res.data[1];
                    self.AreaVisitor.avg = res.data[2];
                    self.CreateAreaVisitorChart();                 
                    // console.log(self.AreaVisitor.area);
                    // console.log(self.AreaVisitor.max);
                    // console.log(self.AreaVisitor.avg);
                })
                .catch((error) => {
                    console.log('LoadAreaVisitorFilterCountData:', error);
                });
        },
        async LoadVisitorData() {
            let self = this;
            await axios.get('../API/GetAreaVisitor')
                .then((res) => {
                    self.VisitorData = res.data[0];
                })
                .catch((error) => {
                    console.log('LoadVisitorData:', error);
                });
        },
        async GetArea() {
            let self = this;
            await axios.get('../API/GetAllArea')
                .then(function (response) {
                    // console.log('AreaList:', response.data);
                    var options_num = [];
                    var options_name = [];
                    for (var i = 0; i < response.data.length; i++) {
                        options_num.push(response.data[i]['area_num']);
                        options_name.push(response.data[i]['area_name']);
                    }
                    // console.log('options_num:', options_num);
                    // console.log('options_name:', options_name);

                    const num_middleIndex = Math.ceil(options_num.length / 2);
                    const num_firstHalf = options_num.splice(0, num_middleIndex);
                    const num_secondHalf = options_num.splice(-num_middleIndex);
                    const name_middleIndex = Math.ceil(options_name.length / 2);
                    const name_firstHalf = options_name.splice(0, name_middleIndex);
                    const name_secondHalf = options_name.splice(-name_middleIndex);

                    // console.log(num_firstHalf);
                    // console.log(num_secondHalf);
                    // console.log(name_firstHalf);
                    // console.log(name_secondHalf);

                    var Data1 = [];
                    for (var i = 0; i < num_firstHalf.length; i++) {
                        var tmp_dict = {
                            num: num_firstHalf[i],
                            name: name_firstHalf[i]
                        };
                        Data1.push(tmp_dict);
                    }
                    self.AreaData1 = Data1;
                    // console.log('AreaData1:', self.AreaData1);

                    var Data2 = [];
                    for (var i = 0; i < num_secondHalf.length; i++) {
                        var tmp_dict = {
                            num: num_secondHalf[i],
                            name: name_secondHalf[i]
                        };
                        Data2.push(tmp_dict);
                    }
                    self.AreaData2 = Data2;
                    // console.log('AreaData2:', self.AreaData2);
                })
                .catch((error) => {
                    console.log('GetArea error - ', error);
                });
        },
        async GetVisitor() {
            let self = this;

            function search(params, data) {
                if ($.trim(params.term) === '') {
                    return data;
                }
                if (typeof data.text === 'undefined') {
                    return null;
                }
                if (data.text.indexOf(params.term) > -1) {
                    var modifiedData = $.extend({}, data, true);
                    modifiedData.text += ' (匹配)';
                    return modifiedData;
                }
                return null;
            }
            await axios.get('../API/GetAllVisitor')
                .then(response => {
                    // console.log('VisitorList:', response.data);

                    var options = [];
                    for (var i = 0; i < response.data.length; i++) {
                        var tmp_dict = {
                            text: response.data[i]['visitor_name'],
                            value: response.data[i]['visitor_name']
                        };
                        options.push(tmp_dict);
                    }
                    self.VisitorOptions = options
                })
                .catch((error) => {
                    console.log('GetVisitor error - ', error);
                });

            $('#VisitorFilter').select2({
                width: '100%',
                allowClear: true,
                closeOnSelect: true,
                dropdownAutoWidth: true,
                matcher: search
            });
        },
        UpdateVisitor() {
            console.log('Update Visitor');
        },
        CreateAllCountChart() {
            let self = this;
            var myAllCountChart = echarts.init(document.getElementById('AllCountChart'));
            myAllCountChart.setOption({
                grid: {
                    left: '5%',
                    right: '0%'
                },
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {
                        type: 'shadow',
                        shadowStyle: {
                            color: 'rgba(134, 110, 97, 0.1)'
                        }
                    },
                    valueFormatter: (value) => value + '人'
                },
                xAxis: [{
                    type: 'category',
                    data: self.AllCount.week_day,
                    axisTick: {
                        show: false,
                    },
                    splitLine: {
                        show: false,
                    },
                    axisLine: {
                        show: false,
                    },
                    axisLabel: {
                        color: '#959494',
                        fontSize: 14,
                        fontWeight: 600,
                        interval: 0,
                        padding: [8, 0, 0, 0],
                        formatter: function (value) {
                            return value.split('-')[1] + '/' + value.split('-')[2]
                        }
                    },
                }],
                yAxis: [{
                    type: 'value',
                    name: '(人)',
                    nameTextStyle: {
                        color: '#959494',
                        fontSize: 12,
                        padding: [0, 0, 6, -60],
                    },
                    axisLabel: {
                        show: true,
                        textStyle: {
                            color: '#959494'
                        },
                        padding: 10
                    },
                }],
                series: [{
                    name: '總人數',
                    type: 'bar',
                    emphasis: {
                        focus: 'series'
                    },
                    barWidth: 30,
                    itemStyle: {
                        color: '#866E61'
                    },
                    label: {
                        normal: {
                            show: true,
                            position: "inside",
                            formatter: function (data) {
                                return '{a0|' + data.value + '}';
                            },
                            rich: {
                                a0: {
                                    color: '#ffffff',
                                    fontSize: 12,
                                },
                            }
                        },
                    },
                    data: self.AllCount.data
                }]
            });
            window.addEventListener('resize', function () {
                myAllCountChart.resize();
            })
        },
        CreateAreaVisitorChart() {
            let self = this;
            console.log('self.AreaVisitor:', self.AreaVisitor);
            console.log('self.AreaVisitor.avg:', self.AreaVisitor.avg)
            console.log('self.AreaVisitor.avg.length:', self.AreaVisitor.avg.length)
            if (self.AreaVisitor.avg.length == 0) {
                var list_avg = [];
                for (var i = 0; i < self.AreaVisitor.area.length; i++) {
                    list_avg.push(0);
                }
                self.AreaVisitor.avg = list_avg
            }
            if (self.AreaVisitor.max.length == 0) {
                var list_max = [];
                for (var i = 0; i < self.AreaVisitor.area.length; i++) {
                    list_max.push(0);
                }
                self.AreaVisitor.max = list_max
            }

            var area = app.VisitorData.area.substring(2, app.VisitorData.area.length - 2).replaceAll("'", "").split(", ")
            var myLayoutCountChart = echarts.init(document.getElementById('LayoutCountChart'));
            myLayoutCountChart.setOption({
                grid: {
                    left: '6%',
                    right: '0%'
                },
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {
                        type: 'shadow',
                        shadowStyle: {
                            color: 'rgba(134, 110, 97, 0.1)'
                        }
                    },
                    valueFormatter: (value) => value + '人'
                },
                legend: {
                    bottom: "0%",
                    itemHeight: 15,
                    itemWidth: 25,
                    itemGap: 25,
                    padding: [0, 10],
                    textStyle: {
                        fontSize: 14,
                        color: "#959494",
                    },
                    data: [{
                            name: "平均人數",
                            icon: "square",
                        },
                        {
                            name: "最大人數",
                        }
                    ],
                },
                xAxis: [{
                    type: 'category',
                    data: self.AreaVisitor.area,
                    axisTick: {
                        show: false,
                    },
                    splitLine: {
                        show: false,
                    },
                    axisLine: {
                        show: false,
                    },
                    axisLabel: {
                        color: '#959494',
                        fontSize: 12,
                        fontWeight: 600,
                        interval: 0,
                        padding: [8, 0, 0, 0]
                    },
                }],
                yAxis: [{
                    type: 'value',
                    name: '(人)',
                    nameTextStyle: {
                        color: "#959494",
                        fontSize: 12,
                        padding: [0, 0, 6, -60],
                    },
                    axisLabel: {
                        show: true,
                        textStyle: {
                            color: '#959494'
                        },
                        padding: 10
                    },
                }],
                series: [{
                        name: '平均人數',
                        type: 'bar',
                        emphasis: {
                            focus: 'series'
                        },
                        barWidth: 30,
                        itemStyle: {
                            color: '#866E61'
                        },
                        label: {
                            normal: {
                                show: true,
                                position: "inside",
                                formatter: function (data) {
                                    return '{a0|' + data.value + '}';
                                },
                                rich: {
                                    a0: {
                                        color: '#ffffff',
                                        fontSize: 12
                                    },
                                }
                            },
                        },
                        data: self.AreaVisitor.avg
                    },
                    {
                        name: '最大人數',
                        type: "line",
                        symbol: "square",
                        symbolSize: 10,
                        color: "#E0552A",
                        lineStyle: {
                            normal: {
                                width: 2
                            }
                        },
                        itemStyle: {
                            normal: {
                                color: '#E0552A',
                            }
                        },
                        data: self.AreaVisitor.max,
                        label: {
                            normal: {
                                show: true,
                                position: "top",
                                color: '#E0552A',
                                formatter: "{c}"
                            }
                        }
                    }
                ]
            });
            window.addEventListener('resize', function () {
                myLayoutCountChart.resize();
            })
        },
        async WeekChange(event) {
            let self = this;
            var change_week = event.target.value;
            // console.log('change_week:', change_week);

            if (change_week === 'oneweek') {
                await self.LoadAllCountOneWeekData();
                console.log(self.AllCount.week_day);
                console.log(self.AllCount.data);
            } else {
                await self.LoadAllCountTwoWeekData();
                console.log(self.AllCount.week_day);
                console.log(self.AllCount.data);
            }

            var myAllCountChart = echarts.init(document.getElementById('AllCountChart'));
            myAllCountChart.clear()
            self.CreateAllCountChart();
        },
        async ChartSearch() {
            let self = this;
            console.log('SelectType:', self.FilterData.SelectType);
            console.log('SelectStartDate:', self.FilterData.SelectStartDate);
            console.log('SelectEndDate:', self.FilterData.SelectEndDate);
            console.log('SelectGoal:', self.FilterData.SelectGoal);
            
            self.FilterData.SelectDate = self.FilterData.SelectStartDate + '_' + self.FilterData.SelectEndDate;

            if (self.FilterData.SelectDate === null || self.FilterData.SelectDate === '') {
                if (self.FilterData.SelectType != 'all' || self.FilterData.SelectGoal != 'all') {
                    console.log('SelectDate = null + SelectType != all + SelectGoal != all');
                    self.FilterData.SelectDate = '';
                    var filter_url = `../API/GetVisitorFilter?visit_type=${self.FilterData.SelectType}&visit_goal=${self.FilterData.SelectGoal}&visit_date=${self.FilterData.SelectDate}`
                    console.log('Search filter_url -1:', filter_url);
                    await axios.get(filter_url)
                        .then((res) => {
                            // console.log('GetVisitorFilter:', res.data);
                            var ChartSearchData = ''
                            for (var i = 0; i < res.data.length; i++) {
                                var tmp = (res.data[i].visit_date).replaceAll('-', '/') + '&nbsp;&nbsp;&nbsp;' + res.data[i].visit_time + '&nbsp;&nbsp;&nbsp;' + res.data[i].visitor_name + '&nbsp;(' + res.data[i].visit_type + '/' + res.data[i].visit_goal + ')'
                                if (i != res.data.length - 1) {
                                    tmp += '<br>'
                                }
                                ChartSearchData += tmp
                            }
                            self.ChartSearchData = ChartSearchData;
                            self.LoadAreaVisitorFilterCountData();
                        })
                        .catch((error) => {
                            console.log('ChartSearch -1:', error);
                        });
                } else {
                    console.log('SelectDate = null + SelectType = all + SelectGoal = all');
                    await self.LoadAreaVisitorAllCountData();
                    var myLayoutCountChart = echarts.init(document.getElementById('LayoutCountChart'));
                    myLayoutCountChart.clear();
                    self.CreateAreaVisitorChart();
                    self.ChartSearchData = '';
                }                
            } else {
                console.log('SelectDate != null + SelectType != all + SelectGoal != all');                
                var filter_url = `../API/GetVisitorFilter?visit_type=${self.FilterData.SelectType}&visit_goal=${self.FilterData.SelectGoal}&visit_date=${self.FilterData.SelectDate}`
                console.log('Search filter_url -2:', filter_url);
                await axios.get(filter_url)
                    .then((res) => {
                        // console.log('GetVisitorFilter:', res.data);
                        var ChartSearchData = ''
                        for (var i = 0; i < res.data.length; i++) {
                            var tmp = (res.data[i].visit_date).replaceAll('-', '/') + '&nbsp;&nbsp;&nbsp;' + res.data[i].visit_time + '&nbsp;&nbsp;&nbsp;' + res.data[i].visitor_name + '&nbsp;(' + res.data[i].visit_type + '/' + res.data[i].visit_goal + ')'
                            if (i != res.data.length - 1) {
                                tmp += '<br>'
                            }
                            ChartSearchData += tmp
                        }
                        self.ChartSearchData = ChartSearchData;
                        self.LoadAreaVisitorFilterCountData();
                    })
                    .catch((error) => {
                        console.log('ChartSearch -2:', error);
                    });
            }
        }
    }
});