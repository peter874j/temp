var info = new Vue({
    el: "#info",
    data: {
        isDisplay: false
    }
})