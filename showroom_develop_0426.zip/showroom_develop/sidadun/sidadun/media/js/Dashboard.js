var info = new Vue({
    el: "#info",
    data: {
        isDisplay: true
    }
})

var app = new Vue({
    el: "#app",
    data: {
        AreaData1: [],
        AreaData2: [],
        VisitorOptions: [],
        AllCount: {
            week_day: [],
            data: []
        },
        AreaVisitor: {
            area: [],
            max: [],
            avg: []
        },
        VisitorData: {},
        AvgtimeVisitData: {},
        SelectVisitor: 'All',
        FilterData: {
            SelectStartDate: null,
            SelectEndDate: null,
            SelectDate: null,
            SelectType: 'all',
            SelectGoal: 'all'
        },
        ChartSearchData: ''
    },
    created: function () {
        this.init();
    },
    methods: {
        init: async function () {
            let self = this;
            await self.LoadAllCountOneWeekData();
            await self.LoadVisitorData();
            await self.LoadAreaVisitorAllCountData();
            await self.LoadAvgtimeVisitData();
            await self.GetVisitor();
            await self.GetArea();
            await self.CreateAllCountChart();
            await self.CreateAreaVisitorChart();
        },
        async LoadAllCountOneWeekData() {
            let self = this;
            await axios.get('../API/GetAllCountOneWeek')
                .then((res) => {
                    self.AllCount.week_day = res.data['week_day'];
                    self.AllCount.data = res.data['data'];
                    // console.log(self.AllCount.week_day);
                    // console.log(self.AllCount.data);
                })
                .catch((error) => {
                    console.log('LoadAllCountOneWeekData:', error);
                });
        },
        async LoadAllCountTwoWeekData() {
            let self = this;
            await axios.get('../API/GetAllCountTwoWeek')
                .then((res) => {
                    self.AllCount.week_day = res.data['week_day'];
                    self.AllCount.data = res.data['data'];
                    // console.log(self.AllCount.week_day);
                    // console.log(self.AllCount.data);
                })
                .catch((error) => {
                    console.log('LoadAllCountTwoWeekData:', error);
                });
        },
        async LoadAreaVisitorAllCountData() {
            let self = this;
            await axios.get('../API/GetAreaVisitorAllCountLastWeek')
                .then((res) => {
                    console.log('LoadAreaVisitorAllCountData:', res.data);
                    self.AreaVisitor.area = res.data[0];
                    self.AreaVisitor.max = res.data[1];
                    self.AreaVisitor.avg = res.data[2];
                    // console.log(self.AreaVisitor.area);
                    // console.log(self.AreaVisitor.max);
                    // console.log(self.AreaVisitor.avg);
                    console.log('Init Date:', res.data[3], '~', res.data[4]);
                    self.FilterData.SelectStartDate = res.data[3];
                    self.FilterData.SelectEndDate = res.data[4];
                })
                .catch((error) => {
                    console.log('LoadAreaVisitorAllCountData:', error);
                });
        },
        async LoadAreaVisitorFilterCountData() {
            let self = this;

            self.FilterData.SelectDate = self.FilterData.SelectStartDate + '_' + self.FilterData.SelectEndDate
            console.log('LoadAreaVisitorFilterCountData_SelectDate:', self.FilterData.SelectDate);

            if (self.FilterData.SelectGoal != 'all' || self.FilterData.SelectType != 'all') {
                // console.log('self.ChartSearchData', self.ChartSearchData);
                var result = self.ChartSearchData.split('<br>');
                var filter_time = [];
                for (var i = 0; i < result.length; i++) {
                    console.log(result[i].split('&nbsp;&nbsp;&nbsp;'))
                    filter_time.push(result[i].split('&nbsp;&nbsp;&nbsp;')[1])
                }
                var filter_time_str = `&`
                for (var j = 0; j < filter_time.length; j++) {
                    filter_time_str += 'filter_time=' + filter_time[j]
                    if (j + 1 != filter_time.length) {
                        filter_time_str += '&'
                    }
                }
                console.log('(1) - filter_time_str:', filter_time_str);
            }
            // 訪客和類型都是all
            else {
                var filter_time_str = ``
            }

            var filter_url = `../API/GetAreaVisitorFilterCount?insert_time=${self.FilterData.SelectDate}` + filter_time_str
            console.log('(1) - LoadAreaVisitorFilterCountData Count filter_url:', filter_url);

            await axios.get(filter_url)
                .then((res) => {
                    if (res.status == 200) {
                        console.log('LoadAreaVisitorFilterCountData:', res.data);
                        self.AreaVisitor.area = res.data[0];
                        self.AreaVisitor.max = res.data[1];
                        self.AreaVisitor.avg = res.data[2];
                        self.CreateAreaVisitorChart();
                        // console.log(self.AreaVisitor.area);
                        // console.log(self.AreaVisitor.max);
                        // console.log(self.AreaVisitor.avg);
                    }
                })
                .catch((error) => {
                    console.log('LoadAreaVisitorFilterCountData:', error);
                });
        },
        async LoadAvgtimeVisitData() {
            let self = this;
            await axios.get('../API/GetAvgtimeVisitLastWeek')
                .then((res) => {
                    console.log('LoadAvgtimeVisitData:', res.data);
                    self.AvgtimeVisitData = res.data;
                    // console.log(self.AvgtimeVisitData);
                })
                .catch((error) => {
                    console.log('LoadAvgtimeVisitData:', error);
                });
        },
        async LoadAvgtimeVisitFilterCountData() {
            let self = this;

            self.FilterData.SelectDate = self.FilterData.SelectStartDate + '_' + self.FilterData.SelectEndDate
            console.log('LoadAvgtimeVisitFilterCountData_SelectDate:', self.FilterData.SelectDate);

            if (self.FilterData.SelectGoal != 'all' || self.FilterData.SelectType != 'all') {
                // console.log('self.ChartSearchData', self.ChartSearchData);
                var result = self.ChartSearchData.split('<br>');
                var filter_time = [];
                for (var i = 0; i < result.length; i++) {
                    console.log(result[i].split('&nbsp;&nbsp;&nbsp;'))
                    filter_time.push(result[i].split('&nbsp;&nbsp;&nbsp;')[1])
                }
                var filter_time_str = `&`
                for (var j = 0; j < filter_time.length; j++) {
                    filter_time_str += 'filter_time=' + filter_time[j]
                    if (j + 1 != filter_time.length) {
                        filter_time_str += '&'
                    }
                }
                console.log('(2) - filter_time_str:', filter_time_str);
            }
            // 訪客和類型都是all
            else {
                var filter_time_str = ``
            }

            var filter_url = `../API/GetAvgtimeVisitFilterCount?insert_time=${self.FilterData.SelectDate}` + filter_time_str
            console.log('(2) - LoadAvgtimeVisitFilterCountData Count filter_url:', filter_url);

            await axios.get(filter_url)
                .then((res) => {
                    if (res.status == 200) {
                        console.log('LoadAvgtimeVisitFilterCountData:', res.data);
                        self.AvgtimeVisitData = res.data;
                        self.CreateAreaVisitorChart();
                    }
                })
                .catch((error) => {
                    console.log('LoadAvgtimeVisitFilterCountData:', error);
                });
        },
        async LoadVisitorData() {
            let self = this;
            await axios.get('../API/GetAreaVisitor')
                .then((res) => {
                    self.VisitorData = res.data[0];
                })
                .catch((error) => {
                    console.log('LoadVisitorData:', error);
                });
        },
        async GetArea() {
            let self = this;
            await axios.get('../API/GetAllArea')
                .then(function (response) {
                    // console.log('AreaList:', response.data);
                    var options_num = [];
                    var options_name = [];
                    for (var i = 0; i < response.data.length; i++) {
                        options_num.push(response.data[i]['area_num']);
                        options_name.push(response.data[i]['area_name']);
                    }
                    // console.log('options_num:', options_num);
                    // console.log('options_name:', options_name);

                    const num_middleIndex = Math.ceil(options_num.length / 2);
                    const num_firstHalf = options_num.splice(0, num_middleIndex);
                    const num_secondHalf = options_num.splice(-num_middleIndex);
                    const name_middleIndex = Math.ceil(options_name.length / 2);
                    const name_firstHalf = options_name.splice(0, name_middleIndex);
                    const name_secondHalf = options_name.splice(-name_middleIndex);

                    // console.log(num_firstHalf);
                    // console.log(num_secondHalf);
                    // console.log(name_firstHalf);
                    // console.log(name_secondHalf);

                    var Data1 = [];
                    for (var i = 0; i < num_firstHalf.length; i++) {
                        var tmp_dict = {
                            num: num_firstHalf[i],
                            name: name_firstHalf[i]
                        };
                        Data1.push(tmp_dict);
                    }
                    self.AreaData1 = Data1;
                    // console.log('AreaData1:', self.AreaData1);

                    var Data2 = [];
                    for (var i = 0; i < num_secondHalf.length; i++) {
                        var tmp_dict = {
                            num: num_secondHalf[i],
                            name: name_secondHalf[i]
                        };
                        Data2.push(tmp_dict);
                    }
                    self.AreaData2 = Data2;
                    // console.log('AreaData2:', self.AreaData2);
                })
                .catch((error) => {
                    console.log('GetArea error - ', error);
                });
        },
        async GetVisitor() {
            let self = this;

            function search(params, data) {
                if ($.trim(params.term) === '') {
                    return data;
                }
                if (typeof data.text === 'undefined') {
                    return null;
                }
                if (data.text.indexOf(params.term) > -1) {
                    var modifiedData = $.extend({}, data, true);
                    modifiedData.text += ' (匹配)';
                    return modifiedData;
                }
                return null;
            }
            await axios.get('../API/GetAllVisitor')
                .then(response => {
                    // console.log('VisitorList:', response.data);

                    var options = [];
                    for (var i = 0; i < response.data.length; i++) {
                        var tmp_dict = {
                            text: response.data[i]['visitor_name'],
                            value: response.data[i]['visitor_name']
                        };
                        options.push(tmp_dict);
                    }
                    self.VisitorOptions = options
                })
                .catch((error) => {
                    console.log('GetVisitor error - ', error);
                });

            $('#VisitorFilter').select2({
                width: '100%',
                allowClear: true,
                closeOnSelect: true,
                dropdownAutoWidth: true,
                matcher: search
            });
        },
        UpdateVisitor() {
            console.log('Update Visitor');
        },
        CreateAllCountChart() {
            let self = this;
            var myAllCountChart = echarts.init(document.getElementById('AllCountChart'));
            myAllCountChart.setOption({
                grid: {
                    left: '5%',
                    right: '0%'
                },
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {
                        type: 'shadow',
                        shadowStyle: {
                            color: 'rgba(134, 110, 97, 0.1)'
                        }
                    },
                    valueFormatter: (value) => value + '人'
                },
                xAxis: [{
                    type: 'category',
                    data: self.AllCount.week_day,
                    axisTick: {
                        show: false,
                    },
                    splitLine: {
                        show: false,
                    },
                    axisLine: {
                        show: false,
                    },
                    axisLabel: {
                        color: '#959494',
                        fontSize: 14,
                        fontWeight: 600,
                        interval: 0,
                        padding: [8, 0, 0, 0],
                        formatter: function (value) {
                            return value.split('-')[1] + '/' + value.split('-')[2]
                        }
                    },
                }],
                yAxis: [{
                    type: 'value',
                    name: '(人)',
                    nameTextStyle: {
                        color: '#959494',
                        fontSize: 12,
                        padding: [0, 0, 6, -60],
                    },
                    axisLabel: {
                        show: true,
                        textStyle: {
                            color: '#959494'
                        },
                        padding: 10
                    },
                }],
                series: [{
                    name: '總人數',
                    type: 'line',
                    symbol: 'circle',
                    symbolSize: 8,
                    emphasis: {
                        focus: 'series'
                    },
                    lineStyle: {
                        normal: {
                            width: 3,
                            color: '#2581BA'
                        },
                    },
                    itemStyle: {
                        color: '#2581BA'
                    },
                    label: {
                        normal: {
                            show: true,
                            position: "top",
                            formatter: function (data) {
                                return '{a0|' + data.value + '}';
                            },
                            rich: {
                                a0: {
                                    color: '#2581BA',
                                    fontSize: 16,
                                },
                            }
                        },
                    },
                    data: self.AllCount.data
                }]
            });
            window.addEventListener('resize', function () {
                myAllCountChart.resize();
            })
        },
        CreateAreaVisitorChart() {
            let self = this;
            // console.log('self.AreaVisitor:', self.AreaVisitor);
            // console.log('self.AreaVisitor.avg:', self.AreaVisitor.avg)
            // console.log('self.AreaVisitor.avg.length:', self.AreaVisitor.avg.length)
            if (self.AreaVisitor.avg.length == 0) {
                var list_avg = [];
                for (var i = 0; i < self.AreaVisitor.area.length; i++) {
                    list_avg.push(0);
                }
                self.AreaVisitor.avg = list_avg
            }
            if (self.AreaVisitor.max.length == 0) {
                var list_max = [];
                for (var i = 0; i < self.AreaVisitor.area.length; i++) {
                    list_max.push(0);
                }
                self.AreaVisitor.max = list_max
            }

            var area = app.VisitorData.area.substring(2, app.VisitorData.area.length - 2).replaceAll("'", "").split(", ")
            var myLayoutCountChart = echarts.init(document.getElementById('LayoutCountChart'));

            var splitNumber = 6;
            var interval1 = (calMax(self.AreaVisitor.max) * 2 - 0) / splitNumber;
            var interval2 = (calMax(self.AvgtimeVisitData) * 2 - 0) / splitNumber;

            function calMax(arr) {
                let min = Math.min.apply(null, arr);
                let max = Math.max.apply(null, arr);
                let interval = (max - min) / splitNumber; // 平均值
                max = Math.ceil(max + interval); // 向上取整
                return max;
            }

            function calMin(arr) {
                let min = Math.min.apply(null, arr);
                let max = Math.max.apply(null, arr);
                let interval = (max - min) / splitNumber; // 平均值
                min = min > 0 ? min : Math.floor(min - interval); // 向下取整
                return min;
            }

            myLayoutCountChart.setOption({
                grid: {
                    left: '6%',
                    right: '6%',
                    top: '20%'
                },
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {
                        type: 'shadow',
                        shadowStyle: {
                            color: 'rgba(134, 110, 97, 0.1)'
                        }
                    },
                    formatter: function (datas) {
                        var res = "<b style='font-size:16px;'>" + datas[0].name + '</b><br/><br/>',
                            val;
                        for (var i = 0, length = datas.length; i < length; i++) {
                            if (datas[i].seriesName == "平均停留時間") {
                                res += datas[i].marker + ' ' + datas[i].seriesName + '：' + datas[i].value + '秒<br/>';
                            } else {
                                res += datas[i].marker + ' ' + datas[i].seriesName + '：' + datas[i].value + '人<br/>';
                            }
                        }
                        return res;
                    }
                },
                toolbox: {
                    right: '1%',
                    top: '0%',
                    feature: {
                        dataZoom: {
                            show: true,
                            readOnly: false,
                            title: '區域檢視',
                        },
                        myrestore: {
                            show: true,
                            title: '重置',
                            icon: 'path://M 25 2 A 1.0001 1.0001 0 1 0 25 4 C 36.609534 4 46 13.390466 46 25 C 46 36.609534 36.609534 46 25 46 C 13.390466 46 4 36.609534 4 25 C 4 18.307314 7.130711 12.364806 12 8.5195312 L 12 15 A 1.0001 1.0001 0 1 0 14 15 L 14 6.5507812 L 14 5 L 4 5 A 1.0001 1.0001 0 1 0 4 7 L 10.699219 7 C 5.4020866 11.214814 2 17.712204 2 25 C 2 37.690466 12.309534 48 25 48 C 37.690466 48 48 37.690466 48 25 C 48 12.309534 37.690466 2 25 2 z',
                            onclick: async () => {
                                $('#inputStartDate').val('');
                                $('#inputEndDate').val('');
                                await self.LoadAreaVisitorAllCountData();
                                await self.LoadAvgtimeVisitData();
                                var myLayoutCountChart = echarts.init(document.getElementById('LayoutCountChart'));
                                myLayoutCountChart.clear();
                                await self.CreateAreaVisitorChart();
                            }
                        },
                        dataView: {
                            show: true,
                            title: '詳細',
                            lang: ['詳細資料', '關閉', '更新'],
                            optionToContent: function (opt) {
                                var axisData = opt.xAxis[0].data;
                                var series = opt.series;
                                var tdHeads = '<td style="padding:10px 20px; font-size:18px;">展區名稱</td>';
                                series.forEach(function (item) {
                                    if (item.name == '最大人數') {
                                        item.name += ' (人)'
                                    } else if (item.name == '平均停留時間') {
                                        item.name += ' (秒)'
                                    }

                                    tdHeads += '<td style="padding: 10px 20px; font-size:18px;">' + item.name + '</td>';
                                });
                                var table = '<table border="1" style="margin-left:20px;border-collapse:collapse;font-size:14px;text-align:center"><tbody><tr>' + tdHeads + '</tr>';
                                var tdBodys = '';
                                for (var i = 0, l = axisData.length; i < l; i++) {
                                    for (var j = 0; j < series.length; j++) {
                                        if (typeof (series[j].data[i]) == 'object') {
                                            tdBodys += '<td>' + series[j].data[i].value + '</td>';
                                        } else {
                                            tdBodys += '<td>' + series[j].data[i] + '</td>';
                                        }
                                    }
                                    table += '<tr><td style="padding: 0 10px">' + axisData[i] + '</td>' + tdBodys + '</tr>';
                                    tdBodys = '';
                                }
                                table += '</tbody></table>';
                                return table;
                            }
                        },
                        magicType: {
                            type: ["line", "bar"]
                        },
                        saveAsImage: {
                            title: '儲存',
                            type: 'jpeg',
                            backgroundColor: '#ffffff',
                            name: '各展區人數及平均停留時間統計'
                        },
                    },
                    iconStyle: {
                        borderColor: '#2581BA',
                        fontSize: '22px',
                    },
                },
                legend: {
                    bottom: "0%",
                    itemHeight: 15,
                    itemWidth: 25,
                    itemGap: 25,
                    padding: [0, 10],
                    textStyle: {
                        fontSize: 14,
                        color: "#959494",
                    },
                    data: [{
                            name: "平均人數",
                        },
                        {
                            name: "最大人數",
                        },
                        {
                            name: "平均停留時間",
                        }
                    ],
                },
                xAxis: [{
                    type: 'category',
                    data: self.AreaVisitor.area,
                    axisTick: {
                        show: false,
                    },
                    splitLine: {
                        show: false,
                    },
                    axisLine: {
                        show: false,
                    },
                    axisLabel: {
                        color: '#959494',
                        fontSize: 12,
                        fontWeight: 600,
                        interval: 0,
                        padding: [8, 0, 0, 0]
                    },
                }],
                yAxis: [{
                        type: 'value',
                        name: '人數 (人)',
                        min: 0,
                        max: 60,
                        // splitNumber: 6,
                        interval: 10,
                        nameTextStyle: {
                            color: "#2581BA",
                            fontSize: 12,
                            padding: [0, 0, 6, -50],
                        },
                        axisLabel: {
                            show: true,
                            textStyle: {
                                color: '#2581BA'
                            },
                            padding: 10,
                            formatter: function (value, index) {
                                return Math.round(value);
                            }
                        },
                        axisLine: {
                            lineStyle: {
                                color: '#fff'
                            }
                        }
                    },
                    {
                        type: 'value',
                        name: '時間(秒)',
                        min: 0,
                        max: 360,
                        // splitNumber: 6,
                        interval: 60,
                        nameTextStyle: {
                            color: "#D9A500",
                            fontSize: 12,
                            padding: [0, 0, 6, 50],
                        },
                        axisLabel: {
                            show: true,
                            textStyle: {
                                color: '#D9A500'
                            },
                            padding: 10,
                            formatter: function (value, index) {
                                return Math.round(value);
                            }
                        },
                        // splitLine: {
                        //     lineStyle: {
                        //         color: '#fff'
                        //     }
                        // },
                        axisLine: {
                            lineStyle: {
                                color: '#fff'
                            }
                        }
                    }
                ],
                series: [
                    // {
                    //     name: '平均人數',
                    //     type: 'bar',
                    //     yAxisIndex: "0",
                    //     emphasis: {
                    //         focus: 'series'
                    //     },
                    //     barWidth: 30,
                    //     itemStyle: {
                    //         color: '#2581BA'
                    //     },
                    //     label: {
                    //         normal: {
                    //             show: true,
                    //             position: "inside",
                    //             formatter: function (data) {
                    //                 return '{a0|' + data.value + '}';
                    //             },
                    //             rich: {
                    //                 a0: {
                    //                     color: '#ffffff',
                    //                     fontSize: 12
                    //                 },
                    //             }
                    //         },
                    //     },
                    //     data: self.AreaVisitor.avg
                    // },
                    {
                        name: '最大人數',
                        type: "bar",
                        yAxisIndex: "0",
                        symbol: "square",
                        symbolSize: 12,
                        color: "#2581BA",
                        lineStyle: {
                            normal: {
                                width: 2
                            }
                        },
                        itemStyle: {
                            normal: {
                                color: '#2581BA',
                                borderWidth: 1,
                                borderColor: '#f3f3f3',
                            }
                        },
                        data: self.AreaVisitor.max,
                        label: {
                            normal: {
                                show: true,
                                position: "top",
                                color: '#2581BA',
                                fontSize: 14,
                                formatter: "{c}"
                            }
                        }
                    },
                    {
                        name: '平均停留時間',
                        type: "bar",
                        yAxisIndex: "1",
                        symbol: "diamond",
                        symbolSize: 12,
                        color: "#D9A500",
                        lineStyle: {
                            normal: {
                                width: 2
                            }
                        },
                        itemStyle: {
                            normal: {
                                color: '#D9A500',
                                borderWidth: 1,
                                borderColor: '#f3f3f3',
                            }
                        },
                        data: self.AvgtimeVisitData,
                        label: {
                            normal: {
                                show: true,
                                position: "top",
                                color: '#D9A500',
                                fontSize: 14,
                                formatter: "{c}"
                            }
                        }
                    }
                ]
            });

            window.addEventListener('resize', function () {
                myLayoutCountChart.resize();
            })
        },
        async WeekChange(event) {
            let self = this;
            var change_week = event.target.value;
            // console.log('change_week:', change_week);

            if (change_week === 'oneweek') {
                await self.LoadAllCountOneWeekData();
                // console.log(self.AllCount.week_day);
                // console.log(self.AllCount.data);
            } else {
                await self.LoadAllCountTwoWeekData();
                // console.log(self.AllCount.week_day);
                // console.log(self.AllCount.data);
            }

            var myAllCountChart = echarts.init(document.getElementById('AllCountChart'));
            myAllCountChart.clear()
            self.CreateAllCountChart();
        },
        async ChartSearch() {
            let self = this;
            console.log('SelectStartDate:', self.FilterData.SelectStartDate);
            console.log('SelectEndDate:', self.FilterData.SelectEndDate);
            console.log('SelectType:', self.FilterData.SelectType);
            console.log('SelectGoal:', self.FilterData.SelectGoal);

            if (self.FilterData.SelectStartDate === null || self.FilterData.SelectStartDate === '' ||
                self.FilterData.SelectEndDate === null || self.FilterData.SelectEndDate === '') {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: '請輸入完整的時間區段'
                });
            } else {
                self.FilterData.SelectDate = self.FilterData.SelectStartDate + '_' + self.FilterData.SelectEndDate;

                if (self.FilterData.SelectDate === null || self.FilterData.SelectDate === '') {
                    if (self.FilterData.SelectType != 'all' || self.FilterData.SelectGoal != 'all') {
                        console.log('[1] SelectDate = null + SelectType != all + SelectGoal != all');
                        self.FilterData.SelectDate = '';
                        var filter_url = `../API/GetVisitorFilter?visit_type=${self.FilterData.SelectType}&visit_goal=${self.FilterData.SelectGoal}&visit_date=${self.FilterData.SelectDate}`
                        console.log('Search filter_url -1:', filter_url);
                        await axios.get(filter_url)
                            .then((res) => {
                                // console.log('GetVisitorFilter:', res.data);
                                var ChartSearchData = ''
                                for (var i = 0; i < res.data.length; i++) {
                                    var tmp = (res.data[i].visit_date).replaceAll('-', '/') + '&nbsp;&nbsp;&nbsp;' + res.data[i].visit_time + '&nbsp;&nbsp;&nbsp;' + res.data[i].visitor_name + '&nbsp;(' + res.data[i].visit_type + '/' + res.data[i].visit_goal + ')'
                                    if (i != res.data.length - 1) {
                                        tmp += '<br>'
                                    }
                                    ChartSearchData += tmp
                                }
                                self.ChartSearchData = ChartSearchData;
                                self.LoadAreaVisitorFilterCountData();
                                self.LoadAvgtimeVisitFilterCountData();
                            })
                            .catch((error) => {
                                console.log('ChartSearch -1:', error);
                            });
                    } else {
                        console.log('[2] SelectDate = null + SelectType = all + SelectGoal = all');
                        await self.LoadAreaVisitorAllCountData();
                        await self.LoadAvgtimeVisitData();
                        var myLayoutCountChart = echarts.init(document.getElementById('LayoutCountChart'));
                        myLayoutCountChart.clear();
                        self.CreateAreaVisitorChart();
                        self.ChartSearchData = '';
                    }
                } else {
                    console.log('[3] SelectDate != null + SelectType != all + SelectGoal != all');
                    var filter_url = `../API/GetVisitorFilter?visit_type=${self.FilterData.SelectType}&visit_goal=${self.FilterData.SelectGoal}&visit_date=${self.FilterData.SelectDate}`
                    console.log('Search filter_url -3:', filter_url);
                    await axios.get(filter_url)
                        .then((res) => {
                            // console.log('GetVisitorFilter:', res.data);
                            var ChartSearchData = ''
                            for (var i = 0; i < res.data.length; i++) {
                                var tmp = (res.data[i].visit_date).replaceAll('-', '/') + '&nbsp;&nbsp;&nbsp;' + res.data[i].visit_time + '&nbsp;&nbsp;&nbsp;' + res.data[i].visitor_name + '&nbsp;(' + res.data[i].visit_type + '/' + res.data[i].visit_goal + ')'
                                if (i != res.data.length - 1) {
                                    tmp += '<br>'
                                }
                                ChartSearchData += tmp
                            }
                            self.ChartSearchData = ChartSearchData;
                            self.LoadAreaVisitorFilterCountData();
                            self.LoadAvgtimeVisitFilterCountData();
                        })
                        .catch((error) => {
                            console.log('ChartSearch -3:', error);
                        });
                }
            }
        }
    }
});