from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt


@ csrf_exempt
def Dashboard(request):
    return render(request, 'Dashboard.html')


@ csrf_exempt
def Layout(request):
    return render(request, 'Layout.html')