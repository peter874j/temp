from codecs import utf_16_be_decode
from re import I, X
import pymysql, datetime, math
from datetime import date
from itertools import chain
from django.http import Http404
from django.db import connection
from django.contrib.auth.models import User
from django.contrib.auth.hashers import make_password, check_password
from django.views.decorators.csrf import csrf_exempt
from rest_framework import views, generics
from rest_framework import status
from rest_framework.response import Response
from drf_yasg.utils import swagger_auto_schema
from API.models import Heatmap_mainlist, AreaVisitor_mainlist
from API.models import Area_mainlist, Visitor_mainlist, Avgtime_mainlist
from API.serializers import HeatmapMainlistSerializer, AreaVisitorMainlistSerializer 
from API.serializers import AreaMainlistSerializer, VisitorMainlistSerializer, AvgtimeMainlistSerializer, UserSerializer
import datetime
from django.conf import settings


class HeatmapMainlistView(views.APIView):
    @swagger_auto_schema(operation_summary='列出最近一筆熱點資訊')
    def get(self, request):
        # queryset = Heatmap_mainlist.objects.order_by('-insert_time')[:1]
        latest = Heatmap_mainlist.objects.all().last()
        queryset = Heatmap_mainlist.objects.filter(id=latest.id)
        serializer = HeatmapMainlistSerializer(queryset, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
    
    @csrf_exempt
    @swagger_auto_schema(operation_summary='新增熱點資訊')
    def post(self, request, *args, **kwargs):
        serializer = HeatmapMainlistSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)


class AllCountOneWeekView(views.APIView):
    @swagger_auto_schema(operation_summary='列出近一週總人數統計')       
    def get(self, request):
        def day_get(d):
            for i in range(0, 7):
                oneday = datetime.timedelta(days = i)
                day = d - oneday
                date_to = datetime.datetime(day.year, day.month, day.day)
                yield str(date_to)[0:10]
        result = day_get(datetime.datetime.now())        
        list = []
        for obj in result:
            list.append(obj)
        list_week_day = list[::-1]
        # print('list_week_day:', list_week_day)

        tomorrow = datetime.date.today() + datetime.timedelta(days = 1)
        start_y = int(list_week_day[0].split('-')[0])
        start_m = int(list_week_day[0].split('-')[1])
        start_d = int(list_week_day[0].split('-')[2])
        end_y = int(tomorrow.year)
        end_m = int(tomorrow.month)
        end_d = int(tomorrow.day)
        start_date = datetime.date(start_y, start_m, start_d)
        end_date = datetime.date(end_y, end_m, end_d)
        # print(start_date)
        # print(end_date)

        queryset = Heatmap_mainlist.objects.filter(insert_time__range=(start_date, end_date)).values('acc_count','insert_time')
        list_queryset = [entry for entry in queryset]
        # print('list_queryset', list_queryset)

        acc_count = [int(i['acc_count']) for i in list_queryset]
        insert_time = [datetime.datetime.strftime(i['insert_time'],'%Y-%m-%d') for i in list_queryset]
        # print('acc_count:', acc_count)
        # print('insert_time:', insert_time)
        
        def access_elements(nums, list_index):
            result = [nums[i] for i in list_index]
            return result

        final_count = []
        for u in range(len(list_week_day)):
            pos_lst = [ i for i, e in enumerate(insert_time) if e in list_week_day[u] ]
            # print('pos_lst:', pos_lst)
            if (len(pos_lst) == 0):
                # print('pos_lst len:', len(pos_lst))
                final_count.append(0)
            else:
                acc_count_select = access_elements(acc_count, pos_lst)
                # print('acc_count_select:', acc_count_select)
                # print('acc_count_max', max(acc_count_select))
                final_count.append(max(acc_count_select))

        res = {
            'week_day': list_week_day,
            'data': final_count
        }
        print('AllCountOneWeek:', res)
        return Response(res, status=status.HTTP_200_OK)


class AllCountTwoWeekView(views.APIView):
    @swagger_auto_schema(operation_summary='列出近兩週總人數統計')       
    def get(self, request):
        def day_get(d):
            for i in range(0, 14):
                oneday = datetime.timedelta(days = i)
                day = d - oneday
                date_to = datetime.datetime(day.year, day.month, day.day)
                yield str(date_to)[0:10]
        result = day_get(datetime.datetime.now())        
        list = []
        for obj in result:
            list.append(obj)
        list_week_day = list[::-1]
        # print('list_week_day:', list_week_day)

        tomorrow = datetime.date.today() + datetime.timedelta(days = 1)
        start_y = int(list_week_day[0].split('-')[0])
        start_m = int(list_week_day[0].split('-')[1])
        start_d = int(list_week_day[0].split('-')[2])
        end_y = int(tomorrow.year)
        end_m = int(tomorrow.month)
        end_d = int(tomorrow.day)
        start_date = datetime.date(start_y, start_m, start_d)
        end_date = datetime.date(end_y, end_m, end_d)
        # print(start_date)
        # print(end_date)

        queryset = Heatmap_mainlist.objects.filter(insert_time__range=(start_date, end_date)).values('acc_count','insert_time')
        list_queryset = [entry for entry in queryset]
        # print('list_queryset', list_queryset)

        acc_count = [int(i['acc_count']) for i in list_queryset]
        insert_time = [datetime.datetime.strftime(i['insert_time'],'%Y-%m-%d') for i in list_queryset]
        # print('acc_count:', acc_count)
        # print('insert_time:', insert_time)
        
        def access_elements(nums, list_index):
            result = [nums[i] for i in list_index]
            return result

        final_count = []
        for u in range(len(list_week_day)):
            pos_lst = [ i for i, e in enumerate(insert_time) if e in list_week_day[u] ]
            # print('pos_lst:', pos_lst)
            if (len(pos_lst) == 0):
                # print('pos_lst len:', len(pos_lst))
                final_count.append(0)
            else:
                acc_count_select = access_elements(acc_count, pos_lst)
                # print('acc_count_select:', acc_count_select)
                # print('acc_count_max', max(acc_count_select))
                final_count.append(max(acc_count_select))

        res = {
            'week_day': list_week_day,
            'data': final_count
        }
        return Response(res, status=status.HTTP_200_OK)


class AreaVisitorMainlistView(views.APIView):
    @swagger_auto_schema(operation_summary='列出最近一筆各展區人數統計資訊')
    def get(self, request):
        queryset = AreaVisitor_mainlist.objects.order_by('-insert_time')[:1]
        serializer = AreaVisitorMainlistSerializer(queryset, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
    
    @csrf_exempt
    @swagger_auto_schema(operation_summary='新增一筆各展區人數統計資訊')
    def post(self, request, *args, **kwargs):
        serializer = AreaVisitorMainlistSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)


class HotAreaVisitorView(views.APIView):
    @swagger_auto_schema(operation_summary='列出最近一筆熱門展區資訊')
    def get(self, request):
        latest = AreaVisitor_mainlist.objects.all().last()
        queryset_visitor = AreaVisitor_mainlist.objects.filter(id=latest.id).values('area', 'count')
        # queryset_visitor = AreaVisitor_mainlist.objects.order_by('-insert_time')[:1].values('area', 'count')
        list_queryset_visitor = [entry for entry in queryset_visitor]
        count = [i['count'] for i in list_queryset_visitor]
        queryset_area = Area_mainlist.objects.order_by('area_num').values('area_name')
        list_queryset_area = [entry for entry in queryset_area]
        area = [i['area_name'] for i in list_queryset_area]

        for i in range(len(count)):
            count_pre = count[i].replace('"', '').replace('[', '').replace(']', '').replace(' ', '')
            count_res = [int(x) for x in count_pre.split(',')]

        def sort_index(lst, rev=True):
            index = range(len(lst))
            s = sorted(index, reverse=rev, key=lambda i: lst[i])
            return s
        
        top_3_idx = sort_index(count_res)[:3]
        # print('top_3_idx:', top_3_idx)

        tmp1 = []
        tmp2 = []
        for i in range(len(top_3_idx)):
            tmp1.append(area[top_3_idx[i]])
            tmp2.append(count_res[top_3_idx[i]])
        now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        final = [tmp1, tmp2, now]
            
        return Response(final, status=status.HTTP_200_OK)


class AreaVisitorAllCountLastWeekView(views.APIView):
    @swagger_auto_schema(operation_summary='列出近一周各展區人數統計資訊')
    def get(self, request):
        def day_get(d):
            for i in range(0, 7):
                oneday = datetime.timedelta(days = i)
                day = d - oneday
                date_to = datetime.datetime(day.year, day.month, day.day)
                yield str(date_to)[0:10]
        result = day_get(datetime.datetime.now())        
        list = []
        for obj in result:
            list.append(obj)
        list_week_day = list[::-1]
        print('list_week_day:', list_week_day)

        tomorrow = datetime.date.today() + datetime.timedelta(days = 1)
        today_y = int(list_week_day[6].split('-')[0])
        today_m = int(list_week_day[6].split('-')[1])
        today_d = int(list_week_day[6].split('-')[2])
        start_y = int(list_week_day[0].split('-')[0])
        start_m = int(list_week_day[0].split('-')[1])
        start_d = int(list_week_day[0].split('-')[2])
        end_y = int(tomorrow.year)
        end_m = int(tomorrow.month)
        end_d = int(tomorrow.day)
        today_date = datetime.date(today_y, today_m, today_d)
        start_date = datetime.date(start_y, start_m, start_d)
        end_date = datetime.date(end_y, end_m, end_d)
        # print('today_date:', today_date)
        # print('start_date:', start_date)
        # print('end_date:', end_date)

        queryset = AreaVisitor_mainlist.objects.filter(insert_time__range=(start_date, end_date)).values('count')
        list_queryset = [entry for entry in queryset]
        count = [i['count'] for i in list_queryset]

        tmp = []
        for i in range(len(count)):
            u = count[i].replace('"', '').replace('[', '').replace(']', '').replace(' ', '')
            w = [int(x) for x in u.split(',')]
            tmp.append(w)
        
        def transpose(matrix):
            if matrix == None or len(matrix) == 0:
                return []      
            result = [[None for i in range(len(matrix))] for j in range(len(matrix[0]))]
            for i in range(len(matrix[0])):
                for j in range(len(matrix)):
                    result[i][j] = matrix[j][i]       
            return result
        result = transpose(tmp)

        lst_max_value = []
        lst_avg_value = []
        for i in range(len(result)):
            lst_max_value.append(max(result[i]))
            lst_avg_value.append(math.ceil(sum(result[i]) / len(result[i])))

        queryset_area = Area_mainlist.objects.order_by('area_num').values('area_name')
        list_queryset_area = [entry for entry in queryset_area]
        area_name = [i['area_name'] for i in list_queryset_area]

        final = []
        final.append(area_name)
        final.append(lst_max_value)
        final.append(lst_avg_value)
        final.append(start_date)
        final.append(today_date)
        # print('AreaVisitorAllCountLastWeekView Final:', final)

        return Response(final, status=status.HTTP_200_OK)


class AreaVisitorAllCountView(views.APIView):
    @swagger_auto_schema(operation_summary='列出各展區人數統計資訊')
    def get(self, request):
        queryset = AreaVisitor_mainlist.objects.values('count')
        list_queryset = [entry for entry in queryset]
        count = [i['count'] for i in list_queryset]

        tmp = []
        for i in range(len(count)):
            u = count[i].replace('"', '').replace('[', '').replace(']', '').replace(' ', '')
            w = [int(x) for x in u.split(',')]
            tmp.append(w)
        
        def transpose(matrix):
            if matrix == None or len(matrix) == 0:
                return []      
            result = [[None for i in range(len(matrix))] for j in range(len(matrix[0]))]
            for i in range(len(matrix[0])):
                for j in range(len(matrix)):
                    result[i][j] = matrix[j][i]       
            return result
        result = transpose(tmp)

        lst_max_value = []
        lst_avg_value = []
        for i in range(len(result)):
            lst_max_value.append(max(result[i]))
            lst_avg_value.append(math.ceil(sum(result[i]) / len(result[i])))

        queryset_area = Area_mainlist.objects.order_by('area_num').values('area_name')
        list_queryset_area = [entry for entry in queryset_area]
        area_name = [i['area_name'] for i in list_queryset_area]

        final = []
        final.append(area_name)
        final.append(lst_max_value)
        final.append(lst_avg_value)
        # print('AreaVisitorAllCount Final:', final)

        return Response(final, status=status.HTTP_200_OK)


class AvgtimeVisitLastWeekView(views.APIView):
    @swagger_auto_schema(operation_summary='列出各展區平均停留時間統計資訊')
    def get(self, request):
        def day_get(d):
            for i in range(0, 7):
                oneday = datetime.timedelta(days = i)
                day = d - oneday
                date_to = datetime.datetime(day.year, day.month, day.day)
                yield str(date_to)[0:10]
        result = day_get(datetime.datetime.now())        
        list = []
        for obj in result:
            list.append(obj)
        list_week_day = list[::-1]
        print('list_week_day:', list_week_day)

        tomorrow = datetime.date.today() + datetime.timedelta(days = 1)
        today_y = int(list_week_day[6].split('-')[0])
        today_m = int(list_week_day[6].split('-')[1])
        today_d = int(list_week_day[6].split('-')[2])
        start_y = int(list_week_day[0].split('-')[0])
        start_m = int(list_week_day[0].split('-')[1])
        start_d = int(list_week_day[0].split('-')[2])
        end_y = int(tomorrow.year)
        end_m = int(tomorrow.month)
        end_d = int(tomorrow.day)
        today_date = datetime.date(today_y, today_m, today_d)
        start_date = datetime.date(start_y, start_m, start_d)
        end_date = datetime.date(end_y, end_m, end_d)
        # print('today_date:', today_date)
        # print('start_date:', start_date)
        # print('end_date:', end_date)

        queryset_Avgtime = Avgtime_mainlist.objects.filter(insert_time__range=(start_date, end_date)).values('noid', 'time_in', 'time_out', 'duration')
        list_queryset_Avgtime = [entry for entry in queryset_Avgtime]
        noid = [i['noid'] for i in list_queryset_Avgtime]
        duration_tmp = [i['duration'] for i in list_queryset_Avgtime]
        duration = []
        for p in range(len(duration_tmp)):
            if (duration_tmp[p] == ''):
                duration.append(0)
            else:
                duration.append(float(duration_tmp[p]))
        # print('noid:', noid)
        # print('duration:', duration)

        queryset_Area = Area_mainlist.objects.order_by('area_num').values_list('area_num', flat=True)
        area = sorted([string for string in queryset_Area])
        # print('area:', area)

        final_noid = []
        final_duration = []
        for i in range(len(area)):
            # print(i+1)
            final_noid.append([])
            final_duration.append([])
            for k in range(len(noid)):
                if (int(noid[k].split('_')[2]) == (i+1)):
                    # print(k, ' - ', noid[k], ' - ', duration[k])                    
                    if (noid[k] != '' and duration[k] != ''):
                        final_noid[i].append(noid[k])
                        final_duration[i].append(duration[k])
        # print('final_noid:', final_noid)
        # print('final_duration:', final_duration)

        result = []
        for m in range(len(final_duration)):
            if(len(final_duration[m]) == 0):
                tmp_avg = 0
            else:
                tmp_avg = round(sum(final_duration[m]) / len(final_duration[m]), 0)
            result.append(tmp_avg)
        print('result:', result)

        return Response(result, status=status.HTTP_200_OK)


class AvgtimeVisitView(views.APIView):
    @swagger_auto_schema(operation_summary='列出各展區平均停留時間統計資訊')
    def get(self, request):
        queryset_Avgtime = Avgtime_mainlist.objects.values('noid', 'time_in', 'time_out', 'duration')
        list_queryset_Avgtime = [entry for entry in queryset_Avgtime]
        noid = [i['noid'] for i in list_queryset_Avgtime]
        duration_tmp = [i['duration'] for i in list_queryset_Avgtime]
        duration = []
        for p in range(len(duration_tmp)):
            if (duration_tmp[p] == ''):
                duration.append(0)
            else:
                duration.append(float(duration_tmp[p]))
        # print('noid:', noid)
        # print('duration:', duration)

        queryset_Area = Area_mainlist.objects.order_by('area_num').values_list('area_num', flat=True)
        area = sorted([string for string in queryset_Area])
        # print('area:', area)

        final_noid = []
        final_duration = []
        for i in range(len(area)):
            # print(i+1)
            final_noid.append([])
            final_duration.append([])
            for k in range(len(noid)):
                if (int(noid[k].split('_')[2]) == (i+1)):
                    # print(k, ' - ', noid[k], ' - ', duration[k])                    
                    if (noid[k] != '' and duration[k] != ''):
                        final_noid[i].append(noid[k])
                        final_duration[i].append(duration[k])
        # print('final_noid:', final_noid)
        # print('final_duration:', final_duration)

        result = []
        for m in range(len(final_duration)):
            if(len(final_duration[m]) == 0):
                tmp_avg = 0
            else:
                tmp_avg = round(sum(final_duration[m]) / len(final_duration[m]), 0)
            result.append(tmp_avg)
        print('result:', result)

        return Response(result, status=status.HTTP_200_OK)


class AreaVisitorFilterCountView(generics.ListCreateAPIView):
    queryset = AreaVisitor_mainlist.objects.all().order_by('insert_time')
    serializer_class = AreaVisitorMainlistSerializer

    @swagger_auto_schema(operation_summary='列出特定條件下各展區人數統計資訊')
    def get(self, request):
        queryset = self.queryset
        print('request (insert_time):', self.request.query_params.get('insert_time'))
        print('request (filter_time):', self.request.query_params.getlist('filter_time'))
 
        if ((self.request.query_params.get('insert_time') != None) and (self.request.query_params.get('filter_time') == None)):
            print('Filter 1')
            print('insert_time:', self.request.query_params['insert_time'])
            from_date = self.request.query_params['insert_time'].split('_')[0]
            # gDate = datetime.datetime(int(from_date.split('-')[0]), int(from_date.split('-')[1]), int(from_date.split('-')[2]))
            # end_date = str(gDate + datetime.timedelta(days = 1)).split(' ')[0]
            end_date = self.request.query_params['insert_time'].split('_')[1]
            print('Time Range:', from_date, '~', end_date)
            gDate = datetime.datetime(int(end_date.split('-')[0]), int(end_date.split('-')[1]), int(end_date.split('-')[2]))
            end_date = str(gDate + datetime.timedelta(days = 1)).split(' ')[0]
            queryset = AreaVisitor_mainlist.objects.filter(insert_time__range=[from_date, end_date]).values('count', 'insert_time')

            list_queryset = [entry for entry in queryset]
            count = [i['count'] for i in list_queryset]
            # print('flat_list:', count)

            tmp = []
            for i in range(len(count)):
                u = count[i].replace('"', '').replace('[', '').replace(']', '').replace(' ', '')
                w = [int(x) for x in u.split(',')]
                tmp.append(w)
            
            def transpose(matrix):
                if matrix == None or len(matrix) == 0:
                    return []      
                result = [[None for i in range(len(matrix))] for j in range(len(matrix[0]))]
                for i in range(len(matrix[0])):
                    for j in range(len(matrix)):
                        result[i][j] = matrix[j][i]       
                return result
            result = transpose(tmp)

            lst_max_value = []
            lst_avg_value = []
            for i in range(len(result)):
                lst_max_value.append(max(result[i]))
                lst_avg_value.append(math.ceil(sum(result[i]) / len(result[i])))

            queryset_area = Area_mainlist.objects.order_by('area_num').values('area_name')
            list_queryset_area = [entry for entry in queryset_area]
            area_name = [i['area_name'] for i in list_queryset_area]

            final = []
            final.append(area_name)
            final.append(lst_max_value)
            final.append(lst_avg_value)
            print('2- AreaVisitorFilterCount Final (insert_time):', final)

        elif ((self.request.query_params.get('insert_time') != None) and (self.request.query_params.get('filter_time') != None)):
            print('Filter 2')

            print('insert_time:', self.request.query_params['insert_time'])
            print('filter_time:', self.request.query_params.getlist('filter_time'))
            # print(len(self.request.query_params.getlist('filter_time')))

            if ('undefined' in self.request.query_params.getlist('filter_time')):
                queryset_area = Area_mainlist.objects.order_by('area_num').values('area_name')
                list_queryset_area = [entry for entry in queryset_area]
                area_name = [i['area_name'] for i in list_queryset_area]
                lst_max_value = []
                lst_avg_value = []
                for i in range(len(area_name)):
                    lst_max_value.append(0)
                    lst_avg_value.append(0)
                final = []
                final.append(area_name)
                final.append(lst_max_value)
                final.append(lst_avg_value)
                print('3-1 AreaVisitorFilterCount Final (insert_time+filter_time):', final)
            else:
                all_result = []
                for n in range(len(self.request.query_params.getlist('filter_time'))):
                    time_min = self.request.query_params['insert_time'].split('_')[0] + ' ' + self.request.query_params.getlist('filter_time')[n].split('-')[0] + ':00'
                    time_max = self.request.query_params['insert_time'].split('_')[1] + ' ' + self.request.query_params.getlist('filter_time')[n].split('-')[1] + ':59'
                    # print('time_min:', time_min)
                    # print('time_max:', time_max)
                    queryset = AreaVisitor_mainlist.objects.filter(insert_time__range=(time_min, time_max)).values('count', 'insert_time')
                    list_queryset = [entry for entry in queryset]
                    count = [i['count'] for i in list_queryset]
                    all_result.append(count)
                # print('all_result:', all_result)
                flat_list = [item for sublist in all_result for item in sublist]
                # print('flat_list:', flat_list)

                tmp = []
                for i in range(len(flat_list)):
                    u = flat_list[i].replace('"', '').replace('[', '').replace(']', '').replace(' ', '')
                    w = [int(x) for x in u.split(',')]
                    tmp.append(w)
                
                def transpose(matrix):
                    if matrix == None or len(matrix) == 0:
                        return []      
                    result = [[None for i in range(len(matrix))] for j in range(len(matrix[0]))]
                    for i in range(len(matrix[0])):
                        for j in range(len(matrix)):
                            result[i][j] = matrix[j][i]       
                    return result
                result = transpose(tmp)

                lst_max_value = []
                lst_avg_value = []
                for i in range(len(result)):
                    lst_max_value.append(max(result[i]))
                    lst_avg_value.append(math.ceil(sum(result[i]) / len(result[i])))

                queryset_area = Area_mainlist.objects.order_by('area_num').values('area_name')
                list_queryset_area = [entry for entry in queryset_area]
                area_name = [i['area_name'] for i in list_queryset_area]

                final = []
                final.append(area_name)
                final.append(lst_max_value)
                final.append(lst_avg_value)
                print('3-2 AreaVisitorFilterCount Final (insert_time+filter_time):', final)

        return Response(final, status=status.HTTP_200_OK)


class AvgtimeVisitFilterCountView(generics.ListCreateAPIView):
    @swagger_auto_schema(operation_summary='列出特定條件下各展區平均停留時間統計資訊')
    def get(self, request):
        queryset = self.queryset
        print('request (insert_time):', self.request.query_params.get('insert_time'))
        print('request (filter_time):', self.request.query_params.getlist('filter_time'))

        if ((self.request.query_params.get('insert_time') != None) and (self.request.query_params.get('filter_time') == None)):
            print('Filter 3')

            from_date = self.request.query_params['insert_time'].split('_')[0]
            end_date = self.request.query_params['insert_time'].split('_')[1]
            print('Filter 3 - Time Range:', from_date, '~', end_date)
            gDate = datetime.datetime(int(end_date.split('-')[0]), int(end_date.split('-')[1]), int(end_date.split('-')[2]))
            end_date = str(gDate + datetime.timedelta(days = 1)).split(' ')[0]

            queryset_Avgtime = Avgtime_mainlist.objects.filter(insert_time__range=[from_date, end_date]).values('noid', 'time_in', 'time_out', 'duration')
            list_queryset_Avgtime = [entry for entry in queryset_Avgtime]
            noid = [i['noid'] for i in list_queryset_Avgtime]
            duration_tmp = [i['duration'] for i in list_queryset_Avgtime]
            duration = []
            for p in range(len(duration_tmp)):
                if (duration_tmp[p] == ''):
                    duration.append(0)
                else:
                    duration.append(float(duration_tmp[p]))
            # print('Filter 3 - noid:', noid)
            # print('Filter 3 - duration:', duration)

            queryset_Area = Area_mainlist.objects.order_by('area_num').values_list('area_num', flat=True)
            area = sorted([string for string in queryset_Area])
            # print('area:', area)

            final_noid = []
            final_duration = []
            for i in range(len(area)):
                # print(i+1)
                final_noid.append([])
                final_duration.append([])
                for k in range(len(noid)):
                    if (int(noid[k].split('_')[2]) == (i+1)):
                        # print(k, ' - ', noid[k], ' - ', duration[k])                    
                        if (noid[k] != '' and duration[k] != ''):
                            final_noid[i].append(noid[k])
                            final_duration[i].append(duration[k])
            # print('final_noid:', final_noid)
            # print('final_duration:', final_duration)

            result = []
            for m in range(len(final_duration)):
                if(len(final_duration[m]) == 0):
                    tmp_avg = 0
                else:
                    tmp_avg = round(sum(final_duration[m]) / len(final_duration[m]), 0)
                result.append(tmp_avg)
            print('Filter 3 - result:', result)

            return Response(result, status=status.HTTP_200_OK)

        elif ((self.request.query_params.get('insert_time') != None) and (self.request.query_params.get('filter_time') != None)):
            print('Filter 4')

            print('insert_time:', self.request.query_params['insert_time'])
            print('filter_time:', self.request.query_params.getlist('filter_time'))

            if ('undefined' in self.request.query_params.getlist('filter_time')):
                queryset_area = Area_mainlist.objects.order_by('area_num').values('area_name')
                list_queryset_area = [entry for entry in queryset_area]
                area_name = [i['area_name'] for i in list_queryset_area]
                final = []
                for i in range(len(area_name)):
                    final.append(0)

                print('4-1 AvgtimeVisitFilterCount Final (insert_time+filter_time):', final)
            
            else:
                for n in range(len(self.request.query_params.getlist('filter_time'))):
                    time_min = self.request.query_params['insert_time'].split('_')[0] + ' ' + self.request.query_params.getlist('filter_time')[n].split('-')[0] + ':00'
                    time_max = self.request.query_params['insert_time'].split('_')[1] + ' ' + self.request.query_params.getlist('filter_time')[n].split('-')[1] + ':59'
                    # print('time_min:', time_min)
                    # print('time_max:', time_max)
                    queryset_Avgtime = Avgtime_mainlist.objects.filter(insert_time__range=(time_min, time_max)).values('noid', 'duration', 'insert_time')
                    list_queryset_Avgtime = [entry for entry in queryset_Avgtime]
                    noid = [i['noid'] for i in list_queryset_Avgtime]
                    duration_tmp = [i['duration'] for i in list_queryset_Avgtime]
                    duration = []
                    for p in range(len(duration_tmp)):
                        if (duration_tmp[p] == ''):
                            duration.append(0)
                        else:
                            duration.append(float(duration_tmp[p]))
                # print('Filter 4 - noid:', noid)
                # print('Filter 4 - duration:', duration)

                queryset_Area = Area_mainlist.objects.order_by('area_num').values_list('area_num', flat=True)
                area = sorted([string for string in queryset_Area])
                # print('area:', area)

                final_noid = []
                final_duration = []
                for i in range(len(area)):
                    # print(i+1)
                    final_noid.append([])
                    final_duration.append([])
                    for k in range(len(noid)):
                        if (int(noid[k].split('_')[2]) == (i+1)):
                            # print(k, ' - ', noid[k], ' - ', duration[k])                    
                            if (noid[k] != '' and duration[k] != ''):
                                final_noid[i].append(noid[k])
                                final_duration[i].append(duration[k])
                # print('final_noid:', final_noid)
                # print('final_duration:', final_duration)

                result = []
                for m in range(len(final_duration)):
                    if(len(final_duration[m]) == 0):
                        tmp_avg = 0
                    else:
                        tmp_avg = round(sum(final_duration[m]) / len(final_duration[m]), 0)
                    result.append(tmp_avg)
                print('Filter 4 - result:', )
        
            return Response(result, status=status.HTTP_200_OK)


class AreaMainlistView(views.APIView):
    @swagger_auto_schema(operation_summary='列出展區清單')
    def get(self, request):
        queryset = Area_mainlist.objects.order_by('area_num')
        serializer = AreaMainlistSerializer(queryset, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
    
    @csrf_exempt
    @swagger_auto_schema(operation_summary='新增展區')
    def post(self, request, *args, **kwargs):
        serializer = AreaMainlistSerializer(data=request.data) 
        queryset_area = Area_mainlist.objects.get_queryset().values('id', 'area_num', 'area_name')
        result_area = [entry for entry in queryset_area]
        result_area_name = [i['area_name'] for i in result_area]

        if (request.data['area_name'] in result_area_name):
            return Response('CONFLICT')
        else:
            serializer.is_valid(raise_exception=True)
            serializer.save()
            return Response(serializer.data)


class AreaMainlist_Id(views.APIView):
    queryset = Area_mainlist.objects.all()
    serializer_class = AreaMainlistSerializer

    def get_object(self, id):
        try:
            return Area_mainlist.objects.get(id=id)
        except Area_mainlist.DoesNotExist:
            raise Http404
    
    @swagger_auto_schema(operation_summary='使用id查詢單筆展區')
    def get(self, request, id):
        if id is None:
            queryset2 = Area_mainlist.objects.get_queryset()
            serializer = AreaMainlistSerializer(queryset2, many=True)
            return Response(serializer.data)
        else:
            queryset2 = Area_mainlist.objects.get_queryset().filter(id=id)
            serializers = AreaMainlistSerializer(queryset2, many=True)
            return Response(serializers.data)
    
    @csrf_exempt
    @swagger_auto_schema(operation_summary='使用id更新展區')
    def patch(self, request, id):
        result = self.get_object(id)
        serializer = AreaMainlistSerializer(result, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    @csrf_exempt
    @swagger_auto_schema(operation_summary='使用id刪除展區')
    def delete(self, request, id):
        result = self.get_object(id)
        result.delete()
        return Response(status=status.HTTP_200_OK)


class VisitorMainlistView(views.APIView):
    @swagger_auto_schema(operation_summary='列出參訪團清單')
    def get(self, request):
        queryset = Visitor_mainlist.objects.all()
        serializer = VisitorMainlistSerializer(queryset, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
    
    @csrf_exempt
    @swagger_auto_schema(operation_summary='新增參訪團')
    def post(self, request, *args, **kwargs):
        serializer = VisitorMainlistSerializer(data=request.data) 
        queryset_visitor = Visitor_mainlist.objects.get_queryset().values('id', 'visitor_name', 'visit_date', 'visit_time')
        result_visitor = [entry for entry in queryset_visitor]
        result_visitor_name = [i['visitor_name'] for i in result_visitor]

        if (request.data['visitor_name'] in result_visitor_name):
            return Response('CONFLICT')
        else:
            serializer.is_valid(raise_exception=True)
            serializer.save()
            return Response(serializer.data)


class VisitorMainlist_Id(views.APIView):
    queryset = Visitor_mainlist.objects.all()
    serializer_class = VisitorMainlistSerializer

    def get_object(self, id):
        try:
            return Visitor_mainlist.objects.get(id=id)
        except Visitor_mainlist.DoesNotExist:
            raise Http404
    
    @swagger_auto_schema(operation_summary='使用id查詢單筆參訪團')
    def get(self, request, id):
        if id is None:
            queryset2 = Visitor_mainlist.objects.get_queryset()
            serializer = VisitorMainlistSerializer(queryset2, many=True)
            return Response(serializer.data)
        else:
            queryset2 = Visitor_mainlist.objects.get_queryset().filter(id=id)
            serializers = VisitorMainlistSerializer(queryset2, many=True)
            return Response(serializers.data)
    
    @csrf_exempt
    @swagger_auto_schema(operation_summary='使用id更新參訪團')
    def patch(self, request, id):
        result = self.get_object(id)
        serializer = VisitorMainlistSerializer(result, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    @csrf_exempt
    @swagger_auto_schema(operation_summary='使用id刪除參訪團')
    def delete(self, request, id):
        result = self.get_object(id)
        result.delete()
        return Response(status=status.HTTP_200_OK)


class VisitorFilterView(generics.ListCreateAPIView):
    queryset = Visitor_mainlist.objects.all().order_by('visit_time')
    serializer_class = VisitorMainlistSerializer
    
    @swagger_auto_schema(operation_summary='依據篩選條件列出參訪團')
    def get_queryset(self):
        queryset = self.queryset
        if self.request.query_params.get('visit_type'):
            # print(self.request.query_params['visit_type'])
            if (self.request.query_params['visit_type'] == 'all'):
                queryset = queryset.filter(visit_type__in=['學校','企業'])
            else:
                queryset = queryset.filter(visit_type=self.request.query_params['visit_type'])
        if self.request.query_params.get('visit_goal'):
            # print(self.request.query_params['visit_goal'])
            if (self.request.query_params['visit_goal'] == 'all'):
                queryset = queryset.filter(visit_goal__in=['導覽','參觀'])
            else:
                queryset = queryset.filter(visit_goal=self.request.query_params['visit_goal'])
        if self.request.query_params.get('visit_date'):
            # print(self.request.query_params['visit_date'])
            # queryset = queryset.filter(visit_date=self.request.query_params['visit_date'])
            from_date = self.request.query_params['visit_date'].split('_')[0]
            end_date = self.request.query_params['visit_date'].split('_')[1]
            print('Visit Time Range:', from_date, '~', end_date)
            queryset = queryset.filter(visit_date__range=[from_date, end_date])
        return queryset


class AdministerMainlistView(views.APIView):
    @swagger_auto_schema(operation_summary='列出管理員清單')
    def get(self, request):
        queryset = User.objects.get_queryset().values()
        return Response(queryset, status=status.HTTP_200_OK)
    
    @csrf_exempt
    @swagger_auto_schema(operation_summary='新增管理員')
    def post(self, request, *args, **kwargs):
        # print(request.data)
        queryset_user = User.objects.get_queryset().values('username')
        result_user = [entry for entry in queryset_user]
        result_user_username = [i['username'] for i in result_user]
        # print(result_user_username)

        if (request.data['username'] in result_user_username):
            return Response('CONFLICT', status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        else:
            user = User.objects.create_user(request.data['username'], '', request.data['password'])
            user.is_staff = True
            if (request.data['superuser'] == 'True'):
                user.is_superuser = True
            else:
                user.is_superuser = False
            user.save()
            return Response('OK', status=status.HTTP_201_CREATED)


class AdministerMainlist_Id(views.APIView):
    def get_object(self, id):
        try:
            return User.objects.get(id=id)
        except User.DoesNotExist:
            raise Http404

    @swagger_auto_schema(operation_summary='使用id查詢管理員')
    def get(self, request, id):
        queryset = User.objects.get_queryset().filter(id=id).values()
        result = [entry for entry in queryset]
        password = [i['password'] for i in result][0]
        return Response(queryset, status=status.HTTP_200_OK)

    @csrf_exempt
    @swagger_auto_schema(operation_summary='使用id刪除管理員')
    def delete(self, request, id):
        result = self.get_object(id)
        result.delete()
        return Response(status=status.HTTP_200_OK)


class AvgtimeMainlistView(views.APIView):
    @swagger_auto_schema(operation_summary='列出所有平均參訪時間資訊')
    def get(self, request):
        queryset = Avgtime_mainlist.objects.order_by('-insert_time').all()
        serializer = AvgtimeMainlistSerializer(queryset, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
    
    @csrf_exempt
    @swagger_auto_schema(operation_summary='新增平均參訪時間資訊')
    def post(self, request, *args, **kwargs):
        serializer = AvgtimeMainlistSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)


class AvgtimeMainlist_Noid(views.APIView):
    queryset = Avgtime_mainlist.objects.all()
    serializer_class = AvgtimeMainlistSerializer

    def get_object(self, noid):
        try:
            return Avgtime_mainlist.objects.get(noid=noid)
        except Avgtime_mainlist.DoesNotExist:
            raise Http404
    
    @swagger_auto_schema(operation_summary='使用noid查詢平均參訪時間資訊')
    def get(self, request, noid):
        if noid is None:
            queryset2 = Avgtime_mainlist.objects.get_queryset()
            serializer = AvgtimeMainlistSerializer(queryset2, many=True)
            return Response(serializer.data)
        else:
            queryset2 = Avgtime_mainlist.objects.get_queryset().filter(noid=noid)
            serializers = AvgtimeMainlistSerializer(queryset2, many=True)
            return Response(serializers.data)

    @csrf_exempt
    @swagger_auto_schema(operation_summary='使用noid更新平均參訪時間')
    def patch(self, request, noid):
        result = self.get_object(noid)
        serializer = AvgtimeMainlistSerializer(result, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    

class CheckPermissionView(views.APIView):
    @swagger_auto_schema(operation_summary='管理員權限檢查')
    def get(self, request, username):
        queryset_check = User.objects.filter(username=username).values('is_superuser')
        result = [entry for entry in queryset_check]
        check_is_superuser = [i['is_superuser'] for i in result][0]
        # print('CheckPermission:', check_is_superuser)
        return Response(check_is_superuser, status=status.HTTP_200_OK)


class GenerateCount(views.APIView):
    queryset = Avgtime_mainlist.objects.all()
    serializer_class = AvgtimeMainlistSerializer

    @swagger_auto_schema(operation_summary='回傳平均時間最後編號noid和今日累計人數')
    def get(self, request):
        queryset_Heatmap = Heatmap_mainlist.objects.order_by('-insert_time').values_list('acc_count', flat=True)[:1]
        pre_lst_Heatmap = sorted([string for string in queryset_Heatmap])
        last_count = pre_lst_Heatmap[-1]
        print('last_count:', last_count)
        queryset_Avgtime = Avgtime_mainlist.objects.order_by('noid').values_list('noid', flat=True)
        pre_lst_Avgtime = sorted([string for string in queryset_Avgtime])
        
        # 計算展區數量
        queryset_Area = Area_mainlist.objects.order_by('area_num').values_list('area_num', flat=True)
        pre_lst_Area = sorted([string for string in queryset_Area])
        # print('pre_lst_Area:', pre_lst_Area)

        res = []
        for i in range(len(pre_lst_Avgtime)):
            tmp = pre_lst_Avgtime[i].split('_')
            res.append(tmp)
        # print('res:', res)
        
        final = []
        for j in range(len(pre_lst_Area)):
            # print(j+1)
            final.append([])
            for k in range(len(res)):
                if (int(res[k][2]) == (j+1)):
                    # print(res[k])
                    final[j].append(res[k])
        # print('final:', final)

        last_noid = []
        for t in range(len(final)):
            if (final[t] != []):
                now_max_date = 0
                now_max_count = 0
                for k in range(len(final[t])):
                    if (int(final[t][k][0]) > now_max_date):
                        now_max_date = int(final[t][k][0])
                        # print('now_max_date:', now_max_date)
                    if (int(final[t][k][1]) > now_max_count):
                        now_max_count = int(final[t][k][1])
                        # print('now_max_count:', now_max_count)
                last_noid.append(str(now_max_date) + '_' + str(now_max_count) + '_' + str(t+1))
            else:
                last_noid.append('')

        print('last_noid:', last_noid)

        result = [last_count, last_noid]
        return Response(result)