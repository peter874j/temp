from operator import methodcaller
from flask import Flask, Response, render_template
from camera_video_read import ImageCapture
import cv2
from threading import Thread

# class f(Flask):
#     def __init__(self) -> None:
#         self.app = Flask(__name__)
    
#     @Flask.app.route("/stream", methods=['GET'])
#     def displayStream(self):
#         return Response(self.get(), mimetype='multipart/x-mixed-replace; boundary=frame') 
    
#     def push_img(self, img):
#         img = cv2.imencode(".jpg", img)
#         encodedImage = b'--frame\r\n' b'Content-Type: image/jpeg\r\n\r\n' + bytearray(encodedImage) + b'\r\n'
#         yield encodedImage 

# if __name__ == "__main__":
#     tranfer = f()
#     while True:
#         img = get_capture()
#         f.push_img(img)


class FlaskAPI:

    __app = Flask(__name__)

    @classmethod
    def run(cls):
        cls.__app.run(host='localhost', port=5001, debug=True, use_reloader=False)

    @staticmethod
    def index():
        return render_template('Test.html')

    @staticmethod
    def displayStream():
        return Response(Utils.get(), mimetype='multipart/x-mixed-replace; boundary=frame') 

    @classmethod
    def set_flaskAPI(cls):
        cls.__app.add_url_rule("/index", view_func=cls.index)
        cls.__app.add_url_rule("/stream", view_func=cls.displayStream)


class Utils:

    @staticmethod
    def encode_frame(frame):
        (flag, encodedImage) = cv2.imencode(".jpg", frame)         
        if flag: 
            encodedImage = b'--frame\r\n' b'Content-Type: image/jpeg\r\n\r\n' + bytearray(encodedImage) + b'\r\n'
            return encodedImage 

    @classmethod
    def get(cls):
        while(True):
            frame = cap.getframe()
            yield cls.encode_frame(frame)


if __name__ == "__main__":
    cap = ImageCapture("0")
    FlaskAPI.set_flaskAPI()
    Thread(target=FlaskAPI.run, args=())
    print("----------Test----------")
    
    
    
    
