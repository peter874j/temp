import cv2
import os
import shutil


class Crop:
    def __init__(self, outputImgFolder):
        ### image mode
        # self.cropRegionDict = {
        #     "all": [(90, 15), (90 + 2271, 15 + 1955)],
        #     "1": [(0, 0), (0 + 1260, 0 + 1075)],
        #     "2": [(2271 - 1230, 0), (2271, 0 + 1075)],
        #     "3": [(0, 1955 - 1075), (0 + 1230, 1955)],
        #     "4": [(2271 - 1230, 1955 - 1075), (2271, 1955)],
        # }
        ### show room camera mode
        self.cropRegionDict = {
            "all": [(0,0), (2448,2048)],
            "1": [(0, 0), (0 + 1275, 0 + 1075)],
            "2": [(2448 - 1300, 0), (2448, 0 + 1075)],
            "3": [(0, 2050 - 1090), (0 + 1300, 2050)],
            "4": [(2448 - 1300, 2050 - 1080), (2448, 2050)],
        }

        self.outputImgFolder = outputImgFolder

    def crop_one_img(self, img, imgName):
        """大圖切成想小圖

        Args:
            img (_type_): _description_
        """

        ### 清空資料夾
        if os.path.exists(self.outputImgFolder):
            shutil.rmtree(self.outputImgFolder)
        os.makedirs(self.outputImgFolder)

        ### crop 大圖
        cropRegion = self.cropRegionDict["all"]
        img2 = img[cropRegion[0][1] : cropRegion[1][1], cropRegion[0][0] : cropRegion[1][0]]

        ### crop 各象限小圖
        for quadrant in ["1", "2", "3", "4"]:
            cropRegion = self.cropRegionDict[quadrant]
            cropImg = img2[cropRegion[0][1] : cropRegion[1][1], cropRegion[0][0] : cropRegion[1][0]]
            cv2.imwrite(os.path.join(self.outputImgFolder, f"{imgName}_{quadrant}.jpg"), cropImg)

if __name__ == '__main__':
    inputFolder = r'C:\yjchou\20230424_paneltray\data\sample\raw_img'
    crop = Crop(r'C:\yjchou\20230424_paneltray\data\sample\crop_img')
    for imgFilename in os.listdir(inputFolder):
        img = cv2.imread(os.path.join(inputFolder, imgFilename))
        crop.crop_one_img(img, imgFilename[:-4])