import pandas as pd
import os
import cv2


regionList = {
    ### (168, 162), (1230, 1075)
    "Quadrant1": {
        "x1": 166 - 20,
        "y1": 126 - 20,
        "x2": 1230,
        "y2": 1075,
    },
    ### (0, 172), (1045, 1075)
    "Quadrant2": {
        "x1": 0,
        "y1": 142 - 30,
        "x2": 1054 + 30,
        "y2": 1075,
    },
    ### (162, 0), (1230, 904)
    "Quadrant3": {
        "x1": 170 - 10,
        "y1": 0,
        "x2": 1230,
        "y2": 875,
    },
    ### (0, 0), (1054, 908)
    "Quadrant4": {
        "x1": 0,
        "y1": 0,
        "x2": 1045 + 25,
        "y2": 883,
    },
}


### 2023_04_07
# regionList = {
#     ### (168, 162), (1230, 1075)
#     "Quadrant1": {
#         "x1": 166 - 20 + 50,
#         "y1": 126,
#         "x2": 1230,
#         "y2": 1075,
#     },
#     ### (0, 172), (1045, 1075)
#     "Quadrant2": {
#         "x1": 0,
#         "y1": 142 - 20,
#         "x2": 1054 + 30 - 70,
#         "y2": 1075,
#     },
#     ### (162, 0), (1230, 904)
#     "Quadrant3": {
#         "x1": 170 - 10 + 30,
#         "y1": 0,
#         "x2": 1230 + 50,
#         "y2": 875 - 70,
#     },
#     ### (0, 0), (1054, 908)
#     "Quadrant4": {
#         "x1": 0,
#         "y1": 0,
#         "x2": 1045 + 25 - 70,
#         "y2": 883 - 80,
#     },
# }


def is_bbox_in_rigion(bbox, region):
    x1, y1, x2, y2 = bbox
    regionX1, regionY1, regionX2, regionY2 = (region["x1"], region["y1"], region["x2"], region["y2"])
    if x2 < regionX1 or x1 > regionX2 or y2 < regionY1 or y1 > regionY2:
        return False
    else:
        return True


### 在瑕疵關切區內
def in_focus_region(labelClassName, bbox, region):
    if labelClassName == "broken" or is_bbox_in_rigion(bbox, region):
        return True
    else:
        return False


def cntPredictNum(modelResultPath, classNames):
    gtDict = {}
    for __class in classNames:
        gtDict[__class] = 0

    modelResults = pd.read_csv(modelResultPath)
    for index, row in modelResults.iterrows():
        imgName, __class, x1, y1, x2, y2, score = row

        ### FIXME
        # if __class != "broken" and score < 0.3:
        #     continue
        if __class == "broken" and score < 0.4:
            continue

        bbox = [int(x1), int(y1), int(x2), int(y1)]
        imgName, extension = os.path.splitext(imgName)  # 分割檔名與附檔名
        quadrant = imgName[-1]
        region = regionList[f"Quadrant{quadrant}"]

        if in_focus_region(__class, bbox, region):
            gtDict[__class] += 1
    print(gtDict)


def show_focus_region(imgFolder):
    for imgName in os.listdir(imgFolder):
        img = cv2.imread(os.path.join(imgFolder, imgName))
        imgName, extension = os.path.splitext(imgName)
        quadrant = imgName[-1]
        region = regionList[f"Quadrant{quadrant}"]
        cv2.rectangle(img, (region["x1"], region["y1"]), (region["x2"], region["y2"]), (0, 0, 0), 3, cv2.LINE_AA)
        cv2.imshow("img", img)
        cv2.waitKey(0)


if __name__ == "__main__":
    cntPredictNum(
        modelResultPath=r"D:\UserShare\GitLab\kinsus-panel-tray-defect-detection\ResultBackup\v5.1_20230406\2023_03_22\score0.3\Inference_result.csv",
        classNames=["other", "broken", "scratch", "residue"],
    )
    # show_focus_region(
    #     imgFolder=r"D:\UserShare\GitLab\kinsus-panel-tray-defect-detection\ResultBackup\v5.1_20230406\2023_03_22\score0.3\InferenceImageResult"
    # )
