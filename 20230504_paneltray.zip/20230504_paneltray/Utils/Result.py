import pandas as pd
import cv2
import os
import matplotlib.pyplot as plt
import datetime

COLOR = {
    # "other": (36, 44, 183), # 菊
    "other": (104, 219, 95),  # 綠
    "broken": (31, 69, 133),
    "scratch": (220, 105, 10),  # 藍
    "residue": (125, 14, 145),  # 紫
}


class Result:
    def __init__(self, inferenceResultPath, scoreThresDict) -> None:
        self.inferenceResultPath = inferenceResultPath
        self.scoreThresDict = scoreThresDict
        ### image mode
        # self.cropRegionDict = {
        #     "all": [(90, 15), (90 + 2271, 15 + 1955)],
        #     "1": [(0, 0), (0 + 1260, 0 + 1075)],
        #     "2": [(2271 - 1230, 0), (2271, 0 + 1075)],
        #     "3": [(0, 1955 - 1075), (0 + 1230, 1955)],
        #     "4": [(2271 - 1230, 1955 - 1075), (2271, 1955)],
        # }
        ### show room camera mode
        self.cropRegionDict = {
            "all": [(0,0), (2448,2048)],
            "1": [(0, 0), (0 + 1275, 0 + 1075)],
            "2": [(2448 - 1300, 0), (2448, 0 + 1075)],
            "3": [(0, 2050 - 1090), (0 + 1300, 2050)],
            "4": [(2448 - 1300, 2050 - 1080), (2448, 2050)],
        }
        self.criticalList = ["broken", "residue", "scratch", "other"]  # 嚴重層度由大至小
        self.actionDict = {
            "broken": "Scrap",
            "residue": "Rework",
            "scratch": "Idle",
            "other": "Idle",
        }
        self.num_detect, self.num_scrap = 0, 0

    def cnt_predict_and_draw_bbox(self, img):
        resImg = img.copy()
        predictNumDict = dict()
        for key in self.scoreThresDict.keys():
            predictNumDict[key] = 0

        inferenceResult = pd.read_csv(self.inferenceResultPath)

        for index, row in inferenceResult.iterrows():
            imgFileName, label, x1, y1, x2, y2, score = row
            bbox = (x1, y1, x2, y2)
            ### 濾除低自信度的結果
            if score < self.scoreThresDict[label]:
                continue
            imgName, extension = os.path.splitext(imgFileName)
            quadrant = imgName.split("_")[-1]

            predictNumDict[label] += 1
            resImg = self.__draw_bbox(resImg, bbox, label, score, quadrant)
        return predictNumDict, resImg

    def __draw_bbox(self, img, bbox, label, score, quadrant):
        bbox = self.__claibrate_bbox(bbox, quadrant)
        x1, y1, x2, y2 = bbox[0], bbox[1], bbox[2], bbox[3]
        ### 畫框
        cv2.rectangle(
            img,
            (x1, y1),
            (x2, y2),
            COLOR[label],
            1,
            cv2.LINE_AA,
        )
        ### 顯示類別, 分數
        displayStr = "{}: {}%".format(label, int(100 * score))
        fonFace, fontScale, thickness = cv2.FONT_HERSHEY_DUPLEX, 0.8, 1
        textSize = cv2.getTextSize(displayStr, fonFace, fontScale, thickness)[0]
        textBox = [x1, y1 - textSize[1] * 2, x1 + textSize[0], y1]
        cv2.rectangle(
            img,
            (textBox[0], textBox[1]),
            (textBox[2], textBox[3]),
            COLOR[label],
            -1,
            cv2.LINE_AA,
        )
        cv2.putText(
            img,
            displayStr,
            (x1 + 5, y1 - 8),
            fonFace,
            fontScale,
            (0, 0, 0),
            thickness,
            cv2.LINE_AA,
        )

        return img

    def __claibrate_bbox(self, bbox, quadrant):
        """將小圖的bbox還原回大圖

        Args:
            bbox (_type_): _description_
            quadrant (_type_): _description_
        """
        cropRegion1 = self.cropRegionDict[quadrant]
        cropRegion2 = self.cropRegionDict["all"]
        x1, y1, x2, y2 = bbox[0], bbox[1], bbox[2], bbox[3]
        x1, y1, x2, y2 = x1 + cropRegion1[0][0], y1 + cropRegion1[0][1], x2 + cropRegion1[0][0], y2 + cropRegion1[0][1]
        x1, y1, x2, y2 = x1 + cropRegion2[0][0], y1 + cropRegion2[0][1], x2 + cropRegion2[0][0], y2 + cropRegion2[0][1]
        return (x1, y1, x2, y2)

    def get_result_form(self, predictNumDict):
        ### 產生預測瑕疵字串
        predictLabelStr = ""
        for predictLabel, num in predictNumDict.items():
            if num != 0:
                if predictLabelStr == "":
                    predictLabelStr = predictLabel.title()
                else:
                    predictLabelStr = f"{predictLabelStr}, {predictLabel.title()}"
        if predictLabelStr == "":
            predictLabelStr = 'None'
        predictLabelStr.title()

        ### 找出最嚴重的瑕疵類別
        criticalDefect = "None"
        for label in self.criticalList:
            if predictNumDict[label] != 0:
                criticalDefect = label
                break

        ### 找出對應的動作建議
        if criticalDefect in self.actionDict.keys():
            action = self.actionDict[criticalDefect]
        else:
            action = "Idle"

        ### 作圖
        imgPath = r"data\web_display_img\result_form.jpg"
        plt.figure(dpi=500)
        plt.rcParams["font.family"] = ["Microsoft JhengHei"]
        detectTime = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        columns = ["Time", detectTime]
        data = [
            ["AI Prediction", predictLabelStr],
            ["Critical", criticalDefect.title()],
            ["Action", action.title()],
        ]
        plt.axis("off")
        plt.table(
            cellText=data, colLabels=columns, colWidths=[0.2, 0.3], loc="center", cellLoc="center", colLoc="center"
        )
        # plt.show()
        plt.savefig(imgPath, bbox_inches="tight", pad_inches=0)
        img = cv2.imread(imgPath)
        img = img[747:1105, 605:1880]
        img = cv2.resize(img, (1079,266))
        cv2.imwrite(imgPath, img)

        ### 更新檢測片數, 報廢片數
        self.num_detect += 1
        if self.num_detect == 49:
            self.num_detect = 1
        if action == "Scrap":
            self.num_scrap += 1
        return img, self.num_detect, self.num_scrap
