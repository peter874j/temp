import cv2
import os
import shutil


class Mask:
    def __init__(self, cropImgFolder, outputImgFolder):
        ### image mode
        # self.maskRegionDict = {
        #     "Quadrant1": {
        #         "x1": 230,
        #         "y1": 220,
        #         "x2": 1090,
        #         "y2": 930,
        #     },
        #     "Quadrant2": {
        #         "x1": 140,
        #         "y1": 230,
        #         "x2": 1000,
        #         "y2": 930,
        #     },
        #     "Quadrant3": {
        #         "x1": 230,
        #         "y1": 140,
        #         "x2": 1090,
        #         "y2": 850,
        #     },
        #     "Quadrant4": {
        #         "x1": 130,
        #         "y1": 140,
        #         "x2": 1000,
        #         "y2": 850,
        #     },
        # }

        ### show room camera mode
        self.maskRegionDict = {
            "Quadrant1": {
                "x1": 244,
                "y1": 193,
                "x2": 1185,
                "y2": 965,
            },
            "Quadrant2": {
                "x1": 131,
                "y1": 199,
                "x2": 1069,
                "y2": 977,
            },
            "Quadrant3": {
                "x1": 239,
                "y1": 99,
                "x2": 1183,
                "y2": 869,
            },
            "Quadrant4": {
                "x1": 115,
                "y1": 85,
                "x2": 1075,
                "y2": 865,
            },
        }

        self.cropImgFolder = cropImgFolder
        self.outputImgFolder = outputImgFolder

    def mask(self):
        ### 清空資料夾
        if os.path.exists(self.outputImgFolder):
            shutil.rmtree(self.outputImgFolder)
        os.makedirs(self.outputImgFolder)

        for cropImgFilename in os.listdir(self.cropImgFolder):
            imgName, extension = os.path.splitext(cropImgFilename)
            quadrant = imgName.split("_")[-1]
            maskRegion = self.maskRegionDict[f"Quadrant{quadrant}"]
            cropImg = cv2.imread(os.path.join(self.cropImgFolder, cropImgFilename))
            maskImg = self.__mask_one_img(cropImg, maskRegion)
            cv2.imwrite(os.path.join(self.outputImgFolder, cropImgFilename), maskImg)

    def __mask_one_img(self, img, maskRegion):
        x1, y1, x2, y2 = maskRegion["x1"], maskRegion["y1"], maskRegion["x2"], maskRegion["y2"]
        resultImg = img.copy()
        resultImg[y1:y2, x1:x2] = 0
        return resultImg


if __name__ == '__main__':
    mask = Mask(cropImgFolder=r'C:\yjchou\20230424_paneltray\data\sample\crop_img',
                outputImgFolder=r'C:\yjchou\20230424_paneltray\data\sample\mask_img')
    mask.mask()