import matplotlib.pyplot as plt
import cv2
import numpy as np


def get_result_form():
    imgPath = r"upload_data\images\result_form.jpg"
    plt.figure(dpi=500)
    plt.rcParams["font.family"] = ["Microsoft JhengHei"]
    detectTime = "2023-04-19-09-25-36"
    columns = ["Detection", detectTime]
    data = [
        ["AI Prediction", "Broken, Scratch, Residue"],
        ["Critical", "Broken"],
        ["Action", "Scrap"],
    ]
    plt.axis("off")
    plt.table(cellText=data, colLabels=columns, colWidths=[0.2, 0.3], loc="center", cellLoc="center", colLoc="center")
    # plt.show()
    plt.savefig(imgPath, bbox_inches="tight", pad_inches=0)
    img = cv2.imread(imgPath)
    img = img[747:1105, 605:1880]
    cv2.imwrite(imgPath, img)


def get_recipe_form():
    imgPath = r"upload_data\images\recipe_form.jpg"
    plt.figure(dpi=500)
    plt.subplot(211)
    plt.axis("off")
    data = [["Product", "ABF"]]
    plt.table(cellText=data, colWidths=[0.25, 0.25], loc="center", cellLoc="center", colLoc="center")
    plt.rcParams["font.family"] = ["Microsoft JhengHei"]

    columns = ["LV", "Action", "Defect"]
    data = [
        ["0", "Idle", "Other, Scratch"],
        ["1", "Rework", "Residue"],
        ["2", "Scrap", "Broken"],
    ]
    plt.subplot(212)

    plt.axis("off")
    plt.table(
        cellText=data, colLabels=columns, colWidths=[0.1, 0.2, 0.2], loc="center", cellLoc="center", colLoc="center"
    )
    plt.rcParams["font.family"] = ["Microsoft JhengHei"]

    # plt.show()
    plt.savefig(imgPath, bbox_inches="tight", pad_inches=0)

    img = cv2.imread(imgPath)
    img = img[:, 610:1879]
    img1 = img[367:471, :]
    img2 = img[1249:1715, :]
    newImg = np.vstack((img1, img2))
    cv2.imwrite(imgPath, newImg)


get_result_form()
# get_recipe_form()
