import pandas as pd
import os
import cv2
import shutil


### 刮傷觀切區域
# regionList = {
#     ### (168, 162), (1230, 1075)
#     "Quadrant1": {
#         "x1": 168,
#         "y1": 162,
#         "x2": 1230,
#         "y2": 1075,
#     },
#     ### (0, 172), (1045, 1075)
#     "Quadrant2": {
#         "x1": 0,
#         "y1": 172,
#         "x2": 1045,
#         "y2": 1075,
#     },
#     ### (162, 0), (1230, 904)
#     "Quadrant3": {
#         "x1": 162,
#         "y1": 0,
#         "x2": 1230,
#         "y2": 904,
#     },
#     ### (0, 0), (1054, 908)
#     "Quadrant4": {
#         "x1": 0,
#         "y1": 0,
#         "x2": 1054,
#         "y2": 908,
#     },
# }

### 0103
# regionList = {
#     ### (168, 162), (1230, 1075)
#     "Quadrant1": {
#         "x1": 162,
#         "y1": 151,
#         "x2": 1230,
#         "y2": 1075,
#     },
#     ### (0, 172), (1045, 1075)
#     "Quadrant2": {
#         "x1": 0,
#         "y1": 156,
#         "x2": 1048,
#         "y2": 1075,
#     },
#     ### (162, 0), (1230, 904)
#     "Quadrant3": {
#         "x1": 157,
#         "y1": 0,
#         "x2": 1230,
#         "y2": 900,
#     },
#     ### (0, 0), (1054, 908)
#     "Quadrant4": {
#         "x1": 0,
#         "y1": 0,
#         "x2": 1080,
#         "y2": 917,
#     },
# }


### LV2_0118
# regionList = {
#     ### (168, 162), (1230, 1075)
#     "Quadrant1": {
#         "x1": 163,
#         "y1": 145,
#         "x2": 1230,
#         "y2": 1075,
#     },
#     ### (0, 172), (1045, 1075)
#     "Quadrant2": {
#         "x1": 0,
#         "y1": 149,
#         "x2": 1054,
#         "y2": 1075,
#     },
#     ### (162, 0), (1230, 904)
#     "Quadrant3": {
#         "x1": 157,
#         "y1": 0,
#         "x2": 1230,
#         "y2": 900,
#     },
#     ### (0, 0), (1054, 908)
#     "Quadrant4": {
#         "x1": 0,
#         "y1": 0,
#         "x2": 1050,
#         "y2": 895,
#     },
# }

### LV3_0215
# regionList = {
#     ### (168, 162), (1230, 1075)
#     "Quadrant1": {
#         "x1": 164,
#         "y1": 130,
#         "x2": 1230,
#         "y2": 1075,
#     },
#     ### (0, 172), (1045, 1075)
#     "Quadrant2": {
#         "x1": 0,
#         "y1": 137,
#         "x2": 1050,
#         "y2": 1075,
#     },
#     ### (162, 0), (1230, 904)
#     "Quadrant3": {
#         "x1": 168,
#         "y1": 0,
#         "x2": 1230,
#         "y2": 879,
#     },
#     ### (0, 0), (1054, 908)
#     "Quadrant4": {
#         "x1": 0,
#         "y1": 0,
#         "x2": 1046,
#         "y2": 887,
#     },
# }

## LV4_0302
regionList = {
    ### (168, 162), (1230, 1075)
    "Quadrant1": {
        "x1": 166,
        "y1": 126,
        "x2": 1230,
        "y2": 1075,
    },
    ### (0, 172), (1045, 1075)
    "Quadrant2": {
        "x1": 0,
        "y1": 142,
        "x2": 1054,
        "y2": 1075,
    },
    ### (162, 0), (1230, 904)
    "Quadrant3": {
        "x1": 170,
        "y1": 0,
        "x2": 1230,
        "y2": 875,
    },
    ### (0, 0), (1054, 908)
    "Quadrant4": {
        "x1": 0,
        "y1": 0,
        "x2": 1045,
        "y2": 883,
    },
}


if False:
    imputSize = (1230 * 2, 1075 * 2)
    regionList = {
        ### (168, 162), (1230, 1075)
        "Quadrant1": {
            "x1": int(imputSize[0] * 0.14),
            "y1": int(imputSize[1] * 0.15),
            "x2": int(imputSize[0]),
            "y2": int(imputSize[1]),
        },
        ### (0, 172), (1045, 1075)
        "Quadrant2": {
            "x1": 0,
            "y1": int(imputSize[1] * 0.16),
            "x2": int(imputSize[0] * 0.85),
            "y2": int(imputSize[1]),
        },
        ### (162, 0), (1230, 904)
        "Quadrant3": {
            "x1": int(imputSize[0] * 0.13),
            "y1": 0,
            "x2": int(imputSize[0]),
            "y2": int(imputSize[1] * 0.84),
        },
        ### (0, 0), (1054, 908)
        "Quadrant4": {
            "x1": 0,
            "y1": 0,
            "x2": int(imputSize[0] * 0.86),
            "y2": int(imputSize[1] * 0.84),
        },
    }

### 讀取圖片對應的模型輸出結果
def get_model_result(imgName, modelResults, scoreThres=0.5):
    predicts = []
    orgScoreThres = scoreThres
    for index, row in modelResults.iterrows():
        if row["Image name"] == imgName:
            _, __class, x1, y1, x2, y2, score, iou = row
            ### FIXME:
            if __class == "broken":
                scoreThres = 0.4
            else:
                scoreThres = orgScoreThres
            if float(score) >= scoreThres:
                predicts.append([int(x1), int(y1), int(x2), int(y2), __class])
    return predicts


### 讀取 ground truth
def get_ground_truth(labelFolderPath, imgName):
    gts = []
    file = open(os.path.join(labelFolderPath, imgName + ".txt"), "r")
    for line in file:
        labelClass, labelX1, labelY1, labelX2, labelY2 = line.split(" ")
        labelY2 = labelY2[:-1]  # 去掉換行符號
        gts.append([int(labelX1), int(labelY1), int(labelX2), int(labelY2), labelClass])
    return gts


def get_iou(bbox_ai, bbox_gt):
    bbox_ai = bbox_ai[0], bbox_ai[1], bbox_ai[2] - bbox_ai[0], bbox_ai[3] - bbox_ai[1]
    bbox_gt = bbox_gt[0], bbox_gt[1], bbox_gt[2] - bbox_gt[0], bbox_gt[3] - bbox_gt[1]
    iou_x = max(bbox_ai[0], bbox_gt[0])  # x
    iou_y = max(bbox_ai[1], bbox_gt[1])  # y
    iou_w = min(bbox_ai[2] + bbox_ai[0], bbox_gt[2] + bbox_gt[0]) - iou_x  # w
    iou_w = max(iou_w, 0)
    # print(f"{iou_w=}")
    iou_h = min(bbox_ai[3] + bbox_ai[1], bbox_gt[3] + bbox_gt[1]) - iou_y  # h
    iou_h = max(iou_h, 0)
    # print(f"{iou_h=}")

    iou_area = iou_w * iou_h
    # print(f"{iou_area=}")

    all_area = bbox_ai[2] * bbox_ai[3] + bbox_gt[2] * bbox_gt[3] - iou_area
    # print(f"{all_area=}")

    return max(iou_area / all_area, 0)


def match_bbox(label, predicts, iouThres=0.5):
    bestMatchIndex = -1
    maxIoU = 0
    for index, predict in enumerate(predicts):
        iou = get_iou(predict, label)
        if iou >= iouThres and iou >= maxIoU:
            maxIoU = iou
            bestMatchIndex = index

    return bestMatchIndex


### 在瑕疵關切區內
def in_focus_region(labelClassName, bbox, region):
    if labelClassName == "broken" or is_bbox_in_rigion(bbox, region):
        return True
    else:
        return False


def is_bbox_in_rigion(bbox, region):
    x1, y1, x2, y2 = bbox
    regionX1, regionY1, regionX2, regionY2 = (region["x1"], region["y1"], region["x2"], region["y2"])
    if x2 < regionX1 or x1 > regionX2 or y2 < regionY1 or y1 > regionY2:
        return False
    else:
        return True


def evaluate(
    modelResultPath: str,
    imgFolderPath: str,
    labelFolderPath: str,
    outputFolderPath: str,
    classNames: list,
    iouThres: float,
    scoreThres: float,
    focusRegion=True,
):
    """可判率指標
    (檢出的瑕疵總數/總瑕疵數)

    Args:
        modelResultPath (str): 瑕疵檢測模組輸出的csv路徑
        imgFolderPath (str): 原圖資料夾路徑
        outputFolderPath (str): 分析後輸出圖片的資料夾路徑
    """

    if not os.path.isdir(outputFolderPath):
        os.makedirs(outputFolderPath)
    if not os.path.isdir(os.path.join(outputFolderPath, "Leakage")):
        os.makedirs(os.path.join(outputFolderPath, "Leakage"))
    for className in classNames:
        if not os.path.isdir(os.path.join(outputFolderPath, "Leakage", className)):
            os.makedirs(os.path.join(outputFolderPath, "Leakage", className))
        if not os.path.isdir(os.path.join(outputFolderPath, "TP", className)):
            os.makedirs(os.path.join(outputFolderPath, "TP", className))

    gtDict, okDict, fpDict, fnDict, tpDict = {}, {}, {}, {}, {}
    gtInRegionDict, okInRegionDict, fpInRegionDict, fnInRegionDict, tpInRegionDict = {}, {}, {}, {}, {}
    predictDict, predictInRegionDict = {}, {}
    precisionDict, recallDict = {}, {}
    precisionInRegionDict, recallInRegionDict = {}, {}
    confusionDict = {}

    for _class in classNames:
        gtDict[_class], okDict[_class], fpDict[_class], fnDict[_class], tpDict[_class] = 0, 0, 0, 0, 0
        (
            gtInRegionDict[_class],
            okInRegionDict[_class],
            fpInRegionDict[_class],
            fnInRegionDict[_class],
            tpInRegionDict[_class],
        ) = (0, 0, 0, 0, 0)
        predictDict[_class], predictInRegionDict[_class] = 0, 0

    for _class in classNames:
        confusionDict[_class] = dict()
        for _class2 in classNames:
            confusionDict[_class][_class2] = 0

    ### 瑕疵檢測模組輸出結果 (.csv)
    if not os.path.isdir(modelResultPath):
        modelResults = pd.read_csv(modelResultPath)
    ### yolo 輸出結果 (.txt folder)
    else:
        imgNameList, labelList, x1List, x2List, y1List, y2List, socreList, iouList = [], [], [], [], [], [], [], []
        allFileList = os.listdir(modelResultPath)
        for fileName in allFileList:
            imgName = fileName[:-4] + ".jpg"
            file = open(os.path.join(modelResultPath, fileName), "r")
            for line in file:
                info = line.split(" ")
                imgNameList.append(imgName)
                labelList.append(info[0])
                socreList.append(info[1])
                x1List.append(info[2])
                y1List.append(info[3])
                x2List.append(info[4])
                y2List.append(info[5][:-1])
                iouList.append(0)
        data = {
            "Image name": imgNameList,
            "label": labelList,
            "x1": x1List,
            "y1": y1List,
            "x2": x2List,
            "y2": y2List,
            "score": socreList,
            "iou": iouList,
        }
        modelResults = pd.DataFrame(data)

    orgImgList = os.listdir(imgFolderPath)
    for index, imgName in enumerate(orgImgList):
        if index == 69:
            print("")
        print(f"\n[{index+1}/{len(orgImgList)}] {imgName}")
        ### 讀取圖片並且判斷屬於第幾象限
        img = cv2.imread(os.path.join(imgFolderPath, imgName))
        imgName, extension = os.path.splitext(imgName)  # 分割檔名與附檔名
        quadrant = imgName[-1]
        # FIXME:
        if False:
            quadrant = imgName[-11]

        if focusRegion:
            region = regionList[f"Quadrant{quadrant}"]
        else:
            region = {
                "x1": 0,
                "y1": 0,
                "x2": img.shape[1],
                "y2": img.shape[0],
            }

        ### 讀取圖片對應的模型輸出結果
        predicts = get_model_result(imgName=imgName + extension, modelResults=modelResults, scoreThres=scoreThres)
        for predict in predicts:
            predictDict[predict[4]] += 1
            if in_focus_region(predict[4], predict[0:4], region):
                predictInRegionDict[predict[4]] += 1

        ### 讀取 ground truth
        gts = get_ground_truth(labelFolderPath, imgName)
        okClassList = list()
        leakageClassList = list()
        for _gt in gts:
            gt = _gt[0:4]
            labelClass = _gt[4]
            labelClassName = classNames[int(labelClass)]

            gtDict[labelClassName] += 1
            if in_focus_region(labelClassName, gt, region):
                gtInRegionDict[labelClassName] += 1

            bestMatchIndex = match_bbox(gt, predicts, iouThres)
            ### 有匹配到預測框 (ok)
            if bestMatchIndex != -1:
                okClassList.append(labelClassName)
                okDict[labelClassName] += 1
                ### 考慮類別是否正確 (tp)
                if labelClassName == predicts[bestMatchIndex][4]:
                    tpDict[labelClassName] += 1
                    cv2.rectangle(
                        img,
                        (predicts[bestMatchIndex][0], predicts[bestMatchIndex][1]),
                        (predicts[bestMatchIndex][2], predicts[bestMatchIndex][3]),
                        (0, 255, 0),
                        1,
                        cv2.LINE_AA,
                    )
                    if labelClassName == "broken":
                        print("")
                else:
                    cv2.rectangle(
                        img,
                        (predicts[bestMatchIndex][0], predicts[bestMatchIndex][1]),
                        (predicts[bestMatchIndex][2], predicts[bestMatchIndex][3]),
                        (255, 0, 0),
                        1,
                        cv2.LINE_AA,
                    )
                ### 關切區內且有框到 (okInRegion)
                if in_focus_region(labelClassName, gt, region):
                    okInRegionDict[labelClassName] += 1
                    ### 考慮類別是否正確 (tpInRegion)
                    if labelClassName == predicts[bestMatchIndex][4]:
                        tpInRegionDict[labelClassName] += 1
                        print(
                            f"gt: {labelClassName}, {gt[0]}, {gt[1]}, {gt[2]}, {gt[3]}; \
                    predict: {predicts[bestMatchIndex][0]}, {predicts[bestMatchIndex][1]}, \
                        {predicts[bestMatchIndex][2]}, {predicts[bestMatchIndex][3]}, {predicts[bestMatchIndex][4]}"
                        )
                        # if labelClassName == "other":
                        #     print("")

                    else:
                        print(f"{labelClassName} 判成 {predicts[bestMatchIndex][4]}")
                        confusionDict[labelClassName][predicts[bestMatchIndex][4]] += 1
                        if predicts[bestMatchIndex][4] == "broken":
                            print("")
                        # if labelClassName == "broken":
                        # cv2.imshow("img", img)
                        # cv2.waitKey(0)
                ### 關切區外且有框到
                else:
                    print(
                        f"關切區外 gt: {labelClassName}, {gt[0]}, {gt[1]}, {gt[2]}, {gt[3]}; \
                    predict: {predicts[bestMatchIndex][0]}, {predicts[bestMatchIndex][1]}, \
                        {predicts[bestMatchIndex][2]}, {predicts[bestMatchIndex][3]}, {predicts[bestMatchIndex][4]}"
                    )

            ### 沒有匹配到預測框 (fn)
            else:
                leakageClassList.append(labelClassName)
                cv2.rectangle(
                    img,
                    (gt[0], gt[1]),
                    (gt[2], gt[3]),
                    (0, 0, 255),
                    1,
                    cv2.LINE_AA,
                )
                ### 關切區內leakage (fnInRegion)
                if in_focus_region(labelClassName, gt, region):
                    print(f"Leakage: {labelClassName}")
                    # if labelClassName == "other":
                    #     print("")
                ### 關切區外leakage
                else:
                    print(f"Leakage out of region: {labelClassName}")

        ### 畫圖
        for labelClass in classNames:
            if labelClass in okClassList:
                cv2.imwrite(os.path.join(outputFolderPath, "TP", labelClass, imgName + ".jpg"), img)
            if labelClass in leakageClassList:
                cv2.imwrite(os.path.join(outputFolderPath, "Leakage", labelClass, imgName + ".jpg"), img)

        cv2.rectangle(img, (region["x1"], region["y1"]), (region["x2"], region["y2"]), (0, 0, 0), 3, cv2.LINE_AA)
        cv2.imwrite(os.path.join(outputFolderPath, imgName + ".jpg"), img)
        # cv2.imshow("Analysis Result", img)
        # cv2.waitKey(0)

    gt, ok, fp, fn, tp = 0, 0, 0, 0, 0
    gtInRegion, okInRegion, fpInRegion, fnInRegion, tpInRegion = 0, 0, 0, 0, 0
    fn, gt = 0, 0
    for _class in classNames:
        fnDict[_class] = gtDict[_class] - tpDict[_class]
        fnInRegionDict[_class] = gtInRegionDict[_class] - tpInRegionDict[_class]
        fpDict[_class] = predictDict[_class] - tpDict[_class]
        fpInRegionDict[_class] = predictInRegionDict[_class] - tpInRegionDict[_class]
        gt += gtDict[_class]
        ok += okDict[_class]
        tp += tpDict[_class]
        gtInRegion += gtInRegionDict[_class]
        okInRegion += okInRegionDict[_class]
        tpInRegion += tpInRegionDict[_class]
        fnInRegion += fnInRegionDict[_class]
        try:
            precisionDict[_class] = round(tpDict[_class] / (tpDict[_class] + fpDict[_class]), 2)
        except:
            precisionDict[_class] = 1
        try:
            recallDict[_class] = round(tpDict[_class] / (tpDict[_class] + fnDict[_class]), 2)
        except:
            recallDict[_class] = 1
        try:
            precisionInRegionDict[_class] = round(
                tpInRegionDict[_class] / (tpInRegionDict[_class] + fpInRegionDict[_class]), 2
            )
        except:
            precisionInRegionDict[_class] = 1
        try:
            recallInRegionDict[_class] = round(
                tpInRegionDict[_class] / (tpInRegionDict[_class] + fnInRegionDict[_class]), 2
            )
        except:
            recallInRegionDict[_class] = 1

    print("\n")
    print("=" * 50 + "\n全區域計算")
    print(f"total label: {gt}, ok: {ok}")
    print("可判率: {:.3f}%".format((ok / gt) * 100))
    print("lable 分布: ", gtDict)
    print("tp 分布: ", tpDict)
    print("fn 分布: ", fnDict)
    print("fp 分布: ", fpDict)
    print("Precision: ", precisionDict)
    print("Recall: ", recallDict)

    print("=" * 50 + "\n依各瑕疵關切區計算")
    print(f"total labe: {gtInRegion}, ok: {okInRegion}")
    print("可判率: {:.3f}%".format((okInRegion / gtInRegion) * 100))
    print("lable 分布: ", gtInRegionDict)
    print("tp 分布: ", tpInRegionDict)
    print("fn 分布: ", fnInRegionDict)
    print("fp 分布: ", fpInRegionDict)
    print("Precision: ", precisionInRegionDict)
    print("Recall: ", recallInRegionDict)

    print("誤判分布: ", confusionDict)


if __name__ == "__main__":
    evaluate(
        modelResultPath=r"D:\UserShare\GitLab\kinsus-panel-tray-defect-detection\ResultBackup\v5.1_20230327\v5.1_test_NewTest_mask_review_by_0.1_0.01_0.2_fix\Test_result.csv",
        imgFolderPath=r"D:\UserShare\GitLab\kinsus-panel-tray-defect-detection\ResultBackup\v5.1_20230327\region\LV4_0302",
        labelFolderPath=r"D:\UserShare\GitLab\kinsus-panel-tray-defect-detection\Datasets\Experiment Data\20230317\20230321\OK\dataset\NewTest_mask_review\Annotation",
        outputFolderPath=r"D:\UserShare\GitLab\kinsus-panel-tray-defect-detection\ResultBackup\v5.1_20230327\region\AanlysisResult",
        classNames=["other", "broken", "scratch", "residue"],
        # classNames=["broken", "scratch", "other"],
        # classNames=["broken", "scratch"],
        scoreThres=0.1,
        iouThres=0.01,
        focusRegion=True,
    )
