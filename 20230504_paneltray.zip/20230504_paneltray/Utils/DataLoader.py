import os
import cv2
from pypylon import pylon
import threading
import time
import datetime


class ImageLodaer:
    def __init__(self, imgFolder):
        self.imgFolder = imgFolder
        self.imgFileList = os.listdir(self.imgFolder)
        self.frameIter = iter(self.imgFileList)
        self.index = 0

    def get_frame(self):
        ### 重複圖片迴圈
        if self.index == len(self.imgFileList):
            self.frameIter = iter(os.listdir(self.imgFolder))
            self.index = 0
        imgFileName = next(self.frameIter)
        imgName, extension = os.path.splitext(imgFileName)
        img = cv2.imread(os.path.join(self.imgFolder, imgFileName))
        self.index += 1
        return img, imgName


class CCDLoader:
    def __init__(self):
        self.camera = pylon.InstantCamera(pylon.TlFactory.GetInstance().CreateFirstDevice())

        # Grabing Continusely (video) with minimal delay
        self.camera.StartGrabbing(pylon.GrabStrategy_LatestImageOnly)
        self.converter = pylon.ImageFormatConverter()

        ### 設定相機參數
        self.camera.ExposureTime.SetValue(15000)
        self.camera.Gamma.SetValue(0.81987)

        # converting to opencv bgr format
        self.converter.OutputPixelFormat = pylon.PixelType_BGR8packed
        self.converter.OutputBitAlignment = pylon.OutputBitAlignment_MsbAligned

        self.frame = None
        self.camThread = threading.Thread(target=self.__cam_read)
        self.camThread.start()

    def __cam_read(self):
        while self.camera.IsGrabbing():
            grabResult = self.camera.RetrieveResult(5000, pylon.TimeoutHandling_ThrowException)

            if grabResult.GrabSucceeded():
                image = self.converter.Convert(grabResult)
                self.frame = image.GetArray()
                time.sleep(0.0001)
            grabResult.Release()
        # Releasing the resource
        self.camera.StopGrabbing()

    def get_frame(self):
        imgName = datetime.datetime.now().strftime("%Y_%m_%d_%H_%M_%S")
        return self.frame, imgName
