import requests
import json
from flask import Flask, Response, request, render_template
import time
import datetime
import threading
import cv2


class WebApi:
    def __init__(self, url, apiKey):
        self.url = url
        self.apiKey = apiKey
        self.num_detect, self.num_scrap = 0, 0
        self.uploadThread = threading.Thread(target=self.__upload_thread)
        self.uploadThread.start()

    def update_data(self, num_detect, num_scrap):
        self.num_detect, self.num_scrap = num_detect, num_scrap

    def __upload_thread(self):
        eqId, num_detect_pid, num_scrap_pid = 241, 9914, 9915  # 內網
        # eqId, num_detect_pid, num_scrap_pid = 5, 33, 34  # 外網
        while True:
            url = self.url + "/Data/UploadPollingRawData"
            headers = {"apikey": self.apiKey, "Content-Type": "application/json; charset=utf-8"}
            now = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
            body = {
                "eq_id": str(eqId),  # PT-0_1_1
                "raw_datas": [
                    {"p_id": str(num_detect_pid), "raw_value": str(self.num_detect), "run_date_time": now},  # 檢測片數
                    {"p_id": str(num_scrap_pid), "raw_value": str(self.num_scrap), "run_date_time": now},  # 報廢片數
                ],
            }
            r = requests.post(url, headers=headers, data=json.dumps(body))
            # print(r)
            time.sleep(0.5)


class WebServer:
    def __init__(self) -> None:
        self.recipeFormPath = r"data\web_display_img\recipe_form.jpg"

        self.streamImg, self.resDisplayImg, self.resForm = None, None, None
        self.app = Flask(__name__)
        self.__set_api()

    def update_streamImg(self, streamImg):
        self.streamImg = streamImg

    def update_result_img(self, resDisplayImg):
        self.resDisplayImg = resDisplayImg

    def update_result_form(self, resForm):
        self.resForm = resForm

    def start_server(self):
        self.app.run(host="0.0.0.0", port=5001, debug=False)

    def stream_cam_img(self, ccdLoader):
        self.streamThread = threading.Thread(target=self.__stream_cam_img_thread, args=(ccdLoader,))
        self.streamThread.start()

    def __stream_cam_img_thread(self, ccdLoader):
        while True:
            self.streamImg, _ = ccdLoader.get_frame()
            time.sleep(0.0001)

    def __set_api(self):
        @self.app.route("/stream")
        def get_frame():
            def stream_generator():
                while True:
                    if self.streamImg is not None:
                        encodedImage = self.__encoder(self.streamImg)
                        yield encodedImage

            return Response(stream_generator(), mimetype="multipart/x-mixed-replace; boundary=frame")

        @self.app.route("/resultImg")
        def get_result_img():
            def stream_generator():
                while True:
                    if self.resDisplayImg is not None:
                        encodedImage = self.__encoder(self.resDisplayImg)
                        yield encodedImage

            return Response(stream_generator(), mimetype="multipart/x-mixed-replace; boundary=frame")

        @self.app.route("/result_form")
        def get_result_form():
            def stream_generator():
                while True:
                    if self.resForm is not None:
                        encodedImage = self.__encoder(self.resForm)
                        yield encodedImage

            return Response(stream_generator(), mimetype="multipart/x-mixed-replace; boundary=frame")

        @self.app.route("/recipe_form")
        def get_recipe_form():
            with open(self.recipeFormPath, "rb") as f:
                image = f.read()
                resp = Response(image, mimetype="image/jpg")
                return resp

    def __encoder(self, img):
        (flag, encodedImage) = cv2.imencode(".jpg", img)  # 資料格式轉換為.jpg
        if flag:  # ensure the frame was successfully encoded
            encodedImage = b"--frame\r\n" b"Content-Type: image/jpeg\r\n\r\n" + bytearray(encodedImage) + b"\r\n"
        return encodedImage


if __name__ == "__main__":
    webServer = WebServer()
    webServer.start_server()
