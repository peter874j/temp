# Kinsus Panel Tray Defect Detection

## Edit Record

- 每次改版，請延續此表格紀錄修改內容

| Version | Status |      Branch Name       | Push Date  | Editor | Editor Server | Comment                              |
| :-----: | :----: | :--------------------: | :--------: | :----: | :-----------: | :----------------------------------- |
| v1.0.0  | Alpha  | v1.0.0_yjchou_20230419 | 2023/05/04 | YJChou |  tw100039394  | 1. 2023/04/27 於 Show Room Demo 版本 |
