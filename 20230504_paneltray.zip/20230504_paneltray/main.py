import threading

from core.core import core
from Server.Web import WebServer


### Note: Show Room Demo記得調整內網API, Web.py, crop.py, mask.py, result.py 中的參數
def main():
    webServer = WebServer()
    coreThread = threading.Thread(
        target=core,
        args=(
            r"data\detection_module_data\input\raw_img",
            r"data\detection_module_data\output\crop_img\Inference_result.csv",
            {
                "broken": 0.3,
                "scratch": 0.3,
                "residue": 0.3,
                "other": 0.3,
            },
            r"data\detection_module_data\output\raw_img",
            webServer,
            False,  ### 使用攝影機設為True
        ),
    )
    coreThread.start()
    webServer.start_server()


if __name__ == "__main__":
    main()
