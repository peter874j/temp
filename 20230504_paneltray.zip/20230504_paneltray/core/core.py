import os
import cv2
import pandas as pd


from packages.DetectionModule.mainConfig.MainDet import main as detectionModule
from Server.Web import WebServer, WebApi
from Utils.DataLoader import ImageLodaer, CCDLoader
from Utils.Crop import Crop
from Utils.Mask import Mask
from Utils.Result import Result
import time


def __pre_preocessing(img, imgName, crop: Crop, mask: Mask):
    """裁減成4小圖並加上遮罩

    Args:
        img (_type_): _description_
        imgName (_type_): _description_
    """

    crop.crop_one_img(img, imgName)
    mask.mask()


def __main_preocessing():
    """啟動瑕疵檢測模組"""
    detectionModule()


def __post_preocessing(img, resImgPath, result, webApi, webServer, videoMode):
    predictNumDict, resImg = result.cnt_predict_and_draw_bbox(img)
    cv2.imwrite(resImgPath, resImg)

    ### 更新網頁串流圖片
    if not videoMode:
        webServer.update_streamImg(img)

    ### 更新網頁數值
    resForm, num_detect, num_scrap = result.get_result_form(predictNumDict)
    webApi.update_data(num_detect, num_scrap)

    ### 更新網頁顯示圖片
    webServer.update_result_img(resImg)
    webServer.update_result_form(resForm)


def core(source, inferenceResultPath, scoreThresDict, resImgFolder, webServer, videoMode=False):
    ##############################################
    ##            初始化
    ##############################################
    cropImgFolder = r"data\detection_module_data\input\crop_img"
    maskImgFolder = r"data\detection_module_data\input\crop_img_mask"
    url = "http://tw100043939:8080/api"  # 內網
    # url = "http://192.168.0.100/api"  # 外網

    if not videoMode:
        dataLoader = ImageLodaer(source)
    else:
        dataLoader = CCDLoader()
        webServer.stream_cam_img(dataLoader)

    webApi = WebApi(url=url, apiKey="433576dd-1489-44e5-b19c-baa9c9463dec")
    result = Result(inferenceResultPath, scoreThresDict)
    crop = Crop(cropImgFolder)
    mask = Mask(cropImgFolder, maskImgFolder)

    while True:
        img, imgName = dataLoader.get_frame()
        if img is None:
            continue

        ### DEVELOP:
        # cv2.imwrite('tmp.jpg', img)

        ##############################################
        ##            pre_preocessing
        ##############################################
        __pre_preocessing(img, imgName, crop, mask)

        ##############################################
        ##            main_preocessing
        ##############################################
        __main_preocessing()

        ##############################################
        ##            post_preocessing
        ##############################################
        resImgPath = os.path.join(resImgFolder, f"{imgName}.jpg")
        __post_preocessing(img, resImgPath, result, webApi, webServer, videoMode)
