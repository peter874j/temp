# -*- coding: utf-8 -*-
import os

# os.environ["CUDA_VISIBLE_DEVICES"] = "2"

from main.MainDet import main

if __name__ == "__main__":
    main()
