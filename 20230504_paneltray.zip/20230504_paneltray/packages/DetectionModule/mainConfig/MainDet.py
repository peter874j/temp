# -*- coding: utf-8 -*-

"""
Created on Wed Jun 27 17:00:00 2022
"""
import sys

sys.path.append("./packages/DetectionModule")
from utils.AiResource.DatasetClean import SelectDatasetCleanMethod
from utils.AiResource.DatasetClean.ConfigDataClean import DataCleanPara
from utils.AiResource.Evaluation import SelectEvaluationMethod
from utils.AiResource.Evaluation.ConfigEvaluation import DetEvaluationPara
from utils.AiResource.ModelService.PytorchDetectionModel import MainProcess
from utils.AiResource.ModelService.PytorchDetectionModel.ConfigModelService import (
    LearningRatePara,
    OptimizerPara,
    ScalerPara,
    SchedulerPara,
)
from utils.AiResource.ModelService.PytorchDetectionModel.ConfigPostprocess import PostprcessPara
from utils.AiResource.ModelService.PytorchDetectionModel.ConfigPytorchModel import ModelPara, PathPara, ServicePara
from utils.AiResource.ResultStorage import SelectStorageMethod
from utils.AiResource.ResultStorage.ConfigResultStorage import DetResultStoragePara

from mainConfig.ConfigLoader import load_json_config

from .Config import DetBasicSettingPara, PrivateSettingPara

from utils.AiResource.ModelService.PytorchDetectionModel import video_detect

import threading
import time


def train(configDict: dict):
    """
    Call training module
    """
    print("Step 0: Create config object from dict.")
    basicSettingPara = DetBasicSettingPara.create_from_dict(configDict["Config"]["basicSettingPara"])
    privateSettingPara = PrivateSettingPara.create_from_dict(configDict["Config"]["privateSettingPara"])
    dataCleanPara = DataCleanPara.create_from_dict(configDict["ConfigDataClean"]["dataClean"])
    learningRatePara = LearningRatePara.create_from_dict(configDict["ConfigModelService"]["learningRatePara"])
    optimizerPara = OptimizerPara.create_from_dict(configDict["ConfigModelService"]["optimizerPara"])
    schedulerPara = SchedulerPara.create_from_dict(configDict["ConfigModelService"]["schedulerPara"])
    scalerPara = ScalerPara.create_from_dict(configDict["ConfigModelService"]["scalerPara"])
    servicePara = ServicePara.create_from_dict(configDict["ConfigPytorchModel"]["servicePara"])
    pathPara = PathPara.create_from_dict(configDict["ConfigPytorchModel"]["pathPara"])
    modelPara = ModelPara.create_from_dict(configDict["ConfigPytorchModel"]["modelPara"])
    evaluationPara = DetEvaluationPara.create_from_dict(configDict["ConfigEvaluation"]["evaluationPara"])
    resultStorage = DetResultStoragePara.create_from_dict(configDict["ConfigResultStorage"]["resultStorage"])

    print("Step 1: Split dataset")
    SelectDatasetCleanMethod.det_select_dataset_clean(dataCleanPara, pathPara)
    # exit()
    print("Step 2: AI model Training")
    MainProcess.train(
        basicSettingPara,
        privateSettingPara,
        evaluationPara,
        learningRatePara,
        optimizerPara,
        schedulerPara,
        scalerPara,
        servicePara,
        pathPara,
        modelPara,
        resultStorage,
    )


def test(configDict):
    """
    Call testing module
    """
    print("Step 0: Create config object from dict.")
    basicSettingPara = DetBasicSettingPara.create_from_dict(configDict["Config"]["basicSettingPara"])
    privateSettingPara = PrivateSettingPara.create_from_dict(configDict["Config"]["privateSettingPara"])
    servicePara = ServicePara.create_from_dict(configDict["ConfigPytorchModel"]["servicePara"])
    evaluationPara = DetEvaluationPara.create_from_dict(configDict["ConfigEvaluation"]["evaluationPara"])
    pathPara = PathPara.create_from_dict(configDict["ConfigPytorchModel"]["pathPara"])
    modelPara = ModelPara.create_from_dict(configDict["ConfigPytorchModel"]["modelPara"])
    resultStoragePara = DetResultStoragePara.create_from_dict(configDict["ConfigResultStorage"]["resultStorage"])
    postProcessPara = PostprcessPara.create_from_dict(configDict["ConfigPostprocess"]["postProcessPara"])

    print("Step 1: AI model Testing")
    resultList, cocoEval = MainProcess.test(
        basicSettingPara, servicePara, pathPara, modelPara, postProcessPara, resultStoragePara
    )
    classLabelhasBg = resultList[-1]["classLabelhasBg"]
    print("Step 2: Post-processing")

    print("Step 3: Evaluating")
    SelectEvaluationMethod.det_select_evaluation(
        evaluationPara, "Test", classLabelhasBg, privateSettingPara.outputPath, resultList, cocoEval
    )

    print("Step 4: Result Saveing")
    SelectStorageMethod.det_save_result(
        resultStoragePara, "Test", classLabelhasBg, privateSettingPara.outputPath, resultList
    )


def inference(configDict):
    """
    Call inference module
    """
    print("Step 0: Create config object from dict.")
    basicSettingPara = DetBasicSettingPara.create_from_dict(configDict["Config"]["basicSettingPara"])
    privateSettingPara = PrivateSettingPara.create_from_dict(configDict["Config"]["privateSettingPara"])
    servicePara = ServicePara.create_from_dict(configDict["ConfigPytorchModel"]["servicePara"])
    pathPara = PathPara.create_from_dict(configDict["ConfigPytorchModel"]["pathPara"])
    modelPara = ModelPara.create_from_dict(configDict["ConfigPytorchModel"]["modelPara"])
    resultStoragePara = DetResultStoragePara.create_from_dict(configDict["ConfigResultStorage"]["resultStorage"])
    postProcessPara = PostprcessPara.create_from_dict(configDict["ConfigPostprocess"]["postProcessPara"])

    print("Step 1: AI model Inference")
    resultList = MainProcess.inference(
        basicSettingPara,
        servicePara,
        pathPara,
        modelPara,
        postProcessPara,
    )
    classLabelhasBg = resultList[-1]["classLabelhasBg"]
    print("Step 2: Post-processing")

    print("Step 3: Result Saveing")
    SelectStorageMethod.det_save_result(
        resultStoragePara, "Inference", classLabelhasBg, privateSettingPara.outputPath, resultList
    )


def transfer_annotation(configDict: dict) -> None:
    print("Step 0: Create dataCleanPara object")
    dataCleanPara = DataCleanPara.create_from_dict(configDict["ConfigDataClean"]["dataClean"])
    print("Step 1: Annotation transfer")
    SelectDatasetCleanMethod.select_anntation_trainsfer(dataCleanPara)


def inference_video(configDict):
    basicSettingPara = DetBasicSettingPara.create_from_dict(configDict["Config"]["basicSettingPara"])
    privateSettingPara = PrivateSettingPara.create_from_dict(configDict["Config"]["privateSettingPara"])
    servicePara = ServicePara.create_from_dict(configDict["ConfigPytorchModel"]["servicePara"])
    pathPara = PathPara.create_from_dict(configDict["ConfigPytorchModel"]["pathPara"])
    modelPara = ModelPara.create_from_dict(configDict["ConfigPytorchModel"]["modelPara"])
    resultStoragePara = DetResultStoragePara.create_from_dict(configDict["ConfigResultStorage"]["resultStorage"])
    postProcessPara = PostprcessPara.create_from_dict(configDict["ConfigPostprocess"]["postProcessPara"])

    # load model
    model, classLabelHasBg, cudaDevice = video_detect.laod_model(basicSettingPara, servicePara, pathPara, modelPara)

    # load webcam Detect
    # video_detect.Detect_video("./input/Data/2022_10_07_11_43_2_cam2.avi", model, classLabelHasBg, postProcessPara, resultStoragePara, cudaDevice, save_video_path='./input/Data/2022_10_07_11_43_2_cam2111.avi', show=False)

    # 建立存放執行序的list(存放thread)
    threads = []

    # 放入執行序
    t = threading.Thread(
        target=video_detect.Detect_video,
        args=(
            "./input/Data/2022_10_17_01_39_3_cam6.avi",
            model,
            classLabelHasBg,
            postProcessPara,
            resultStoragePara,
            cudaDevice,
            "./input/Data/2022_10_17_01_39_3_cam6111.avi",
            False,
        ),
    )  #
    threads.append(t)  # 將程序放入threads

    # 放入執行序
    t = threading.Thread(
        target=video_detect.Detect_video,
        args=(
            "./input/Data/2022_10_17_01_47_1_cam5.avi",
            model,
            classLabelHasBg,
            postProcessPara,
            resultStoragePara,
            cudaDevice,
            "./input/Data/2022_10_17_01_47_1_cam5111.avi",
            False,
        ),
    )  #
    threads.append(t)  # 將程序放入threads

    # 開始
    for t in threads:
        t.start()

    # 等待所有子執行緒結束
    for t in threads:
        t.join()


def inference_PanelTray(configDict):
    """
    Call inference module
    """
    print("Step 0: Create config object from dict.")
    basicSettingPara = DetBasicSettingPara.create_from_dict(configDict["Config"]["basicSettingPara"])
    privateSettingPara = PrivateSettingPara.create_from_dict(configDict["Config"]["privateSettingPara"])
    servicePara = ServicePara.create_from_dict(configDict["ConfigPytorchModel"]["servicePara"])
    pathPara = PathPara.create_from_dict(configDict["ConfigPytorchModel"]["pathPara"])
    modelPara = ModelPara.create_from_dict(configDict["ConfigPytorchModel"]["modelPara"])
    resultStoragePara = DetResultStoragePara.create_from_dict(configDict["ConfigResultStorage"]["resultStorage"])
    postProcessPara = PostprcessPara.create_from_dict(configDict["ConfigPostprocess"]["postProcessPara"])

    print("Step 1: AI model Inference")
    resultList = MainProcess.inference_PanelTray(
        basicSettingPara,
        servicePara,
        pathPara,
        modelPara,
        postProcessPara,
    )
    classLabelhasBg = resultList[-1]["classLabelhasBg"]
    print("Step 2: Post-processing")

    print("Step 3: Result Saveing")
    SelectStorageMethod.det_save_result(
        resultStoragePara, "Inference", classLabelhasBg, privateSettingPara.outputPath, resultList
    )


def main():
    """
    根據config中的task, 選擇對應程式執行
    """
    configDict = load_json_config()
    basicSettingPara = DetBasicSettingPara.create_from_dict(configDict["Config"]["basicSettingPara"])
    print(
        f"......... Project: {basicSettingPara.projectID}, Experiment: {basicSettingPara.experimentID}, Mode: {basicSettingPara.task} ........."
    )
    if basicSettingPara.task == "Train":
        train(configDict)
    elif basicSettingPara.task == "Test":
        test(configDict)
    elif basicSettingPara.task == "Inference":
        inference(configDict)
    elif basicSettingPara.task == "AnnotationTransfer":
        transfer_annotation(configDict)
    elif basicSettingPara.task == "InferenceVideo":
        inference_video(configDict)
    elif basicSettingPara.task == "InferencePanelTray":
        inference_PanelTray(configDict)
    else:
        raise BaseException("Please set up the correct task mode in config/ConfigDet.py.")
