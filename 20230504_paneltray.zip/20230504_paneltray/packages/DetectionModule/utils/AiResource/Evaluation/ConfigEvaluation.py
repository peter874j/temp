# -*- coding: utf-8 -*-

"""
Created on Mon Jun 15 17:00:00 2022
"""

class EvaluationPara:
    def __init__(self, 
        drawConfusionMatrix: dict,
        ) -> None:
        """
            ##### Draw confusion matrix for test task
            drawConfusionMatrix (dict): {
                "switch"     (int): 0: enable, 1: disable
                "showNumber" (int): 0: enable, 1: disable, show data amount of each cell
            }
        """
        self.drawConfusionMatrix = drawConfusionMatrix
        pass


class DetEvaluationPara(EvaluationPara):
    def __init__(self, 
            drawConfusionMatrix: dict,
            saveMapTxt: dict,
        ) -> None:
        """
        Args:
            saveMapTxt (dict): {
                "switch" (int) : 0: enable, 1: disable
                "mode"   (list): ['Train', 'Valid', 'Test'] 'Train', 'Valid' or 'Test'
            }    
        """
        super().__init__(drawConfusionMatrix)
        self.saveMapTxt = saveMapTxt
        pass 
       
    @classmethod
    def create_from_dict(cls, evaluationPara: dict):
        """
        Args:
            evaluationPara["drawConfusionMatrix"] (dict): {
                "switch"     (int): 0: enable, 1: disable
                "showNumber" (int): 0: enable, 1: disable, show data amount of each cell
            }

            evaluationPara["saveMapTxt"] (dict): {
                "switch" (int) : 0: enable, 1: disable
                "mode"   (list): ['Train', 'Valid', 'Test'] 'Train', 'Valid' or 'Test'
            }
            
        """
        return cls(**evaluationPara)
