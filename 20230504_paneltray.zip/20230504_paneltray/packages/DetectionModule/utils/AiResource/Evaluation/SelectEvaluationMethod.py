import numpy as np
from numpy import ndarray
from .ModuleEvaluation.Det import SaveConfusionMatrix, SaveMapTxt
from .ConfigEvaluation import DetEvaluationPara


def det_select_evaluation(
    evaluationPara: DetEvaluationPara,
    task:str, 
    classLabel:dict, 
    outputPath:str,
    result:list=None, 
    cocoEval:ndarray=None, 
    epochRecord:str=None, 
    ):
    """
    record for detection evalutaion 

    Args:
        evaluationPara (DetEvaluationPara): Parameters include all evaluation methods
        task (str): "Train" / "Valid" / "Test" / "Inference" 
        classLabel (dict): number corresponds to category include background
        outputPath (str): output path
        result (list, optional): result every item 
            [
            "matrix"  (ndarray) : confusionMatrix.matrix
            ] Defaults to None.
        cocoEval (ndarray, optional): evaluate result for coco data form. Defaults to None.
        epochRecord (str, optional): record epoch. Defaults to None.
    """
    if task in evaluationPara.saveMapTxt["mode"] and evaluationPara.saveMapTxt["switch"]:
        SaveMapTxt.write_mAP_txt(outputPath, task, cocoEval, epochRecord)  
        
    
    if task == 'Test' and evaluationPara.drawConfusionMatrix["switch"] and result != None:
        SaveConfusionMatrix.draw_confusion_matrix(result, classLabel, outputPath, showNumber=True)