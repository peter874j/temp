import os

import torch
import torch.functional
import torch.nn as nn

from .ModuleResultStorage.Det.drawBox import draw_box
from .ModuleResultStorage.Det.SaveDetResult import DetResultSaver
from ..ModelService.PytorchDetectionModel.ConfigPytorchModel import ServicePara
from .ConfigResultStorage import DetResultStoragePara

def create_folder(folderPath:str) -> None:
    """
    Create storaged folder

    Args:
        folderPath: the path wants to create
    """
    if not os.path.isdir(folderPath):
        os.makedirs(folderPath)


def save_weight(model:nn.Module, weightName:str, storagedPath:str) -> None:
    """
    Save the Model parameters in DictPth.

    Args:
        model: the entire model
        weightName: the saved weight file name
        storagedPath: the path to save weight file
    Output:
        xxx.pth: the weight file of model
    """
    create_folder(storagedPath)
    torch.save(model.state_dict(), f'{storagedPath}/{weightName}.pth')


def save_model_optimizer(
    epoch:int,
    model:nn.Module,
    optimizer:torch.functional,
    weightName:str,
    storagedPath:str
) -> None:
    """
    Save epoch, model and optimizer parameters for avoiding unexpected interruption.

    Args:
        epoch: current epoch number
        model: the entire model
        optimizer: the entire optimizer
        weightName: the saved weight file name
        storagedPath: the path to save weight file
    Output:
        checkpoint.pth: include "epoch", "model", "optimizer" parameters
    """
    create_folder(storagedPath)  
    torch.save({
                "epoch": epoch,
                "model": model.state_dict(),
                "optimizer": optimizer.state_dict()
                }, f'{storagedPath}/{weightName}.pth')


def save_script_model(model:nn.Module, weightName:str, storagedPath:str) -> None:
    """
    Save the whole Model in ScriptPth which include parameters and structure.

    Args:
        model: the entire model
        weightName: the saved weight file name
        storagedPath: the path to save weight file
    Output:
        FinetuneModel.pth: pth file with TorchScript model
    """
    create_folder(storagedPath)
    model_scripted = torch.jit.script(model)
    model_scripted.save(f'{storagedPath}/{weightName}.pth')

def det_save_model(
    resultStorage: DetResultStoragePara,
    servicePara: ServicePara,
    outputPath:str,
    task: str,
    model:nn.Module,
    optimizer:torch.functional,
    bestmAP:float,
    currentmAP:float,
    epoch:int,
    modelType:str = None,
) -> float:

    if bestmAP <= currentmAP:
        bestmAP = currentmAP
        if resultStorage.saveBestDictPth["switch"]:
            if modelType is not 'CustomModel':
                save_weight(model, 'BestDictPth', outputPath)
            else:
                print('Warning: CustomModel(ScriptPth) is not supported DictPth model saving')
        # For retrain situation with script model as initial model
        if resultStorage.saveBestScriptPth["switch"] and task == 'Retrain':
            save_script_model(model, 'BestScriptPth', outputPath)

    if resultStorage.saveCheckpoint["switch"] and (epoch + 1) % resultStorage.saveCheckpoint["saveIter"] == 0:
        save_model_optimizer(epoch, model, optimizer, 'CheckPoint', outputPath)

    if epoch + 1 == servicePara.epochs:
        if resultStorage.saveFinalDictPth["switch"]:
            if modelType is not 'CustomModel':
                save_weight(model, 'FinalDictPth', outputPath)
            else:
                print('Warning: CustomModel(ScriptPth) is not supported DictPth model saving')
        if resultStorage.saveFinalScriptPth["switch"]:
            save_script_model(model, 'FinalScriptPth', outputPath)
        
    return bestmAP

def det_save_result(
    resultStorage: DetResultStoragePara,
    task:str, 
    classLabel:dict,
    outputPath:str, 
    resultList:list, 
    ):
    """
    save detection result 

    Args:
        resultStorage (DetResultStoragePara): Parameters include all result Storaged methods
        task (str): "Test" / "Inference" 
        classLabel (dict): number corresponds to category include background
        outputPath (str): output path
        result (list): result every item 
            [
            "image"       (PIL) : image
            "boxes"   (ndarray) : predict the coordinates of box
            "labels"  (ndarray) : predict box of category
            "scores"  (ndarray) : predict box confidence score
            "imageName"   (str) : image name
            "iou"         (str) : iou for every predict box
            ]
    """
        
    if task in ['Test', 'Inference'] and resultStorage.saveResultCsv["switch"]:
        resultSaver = DetResultSaver(outputPath, 'result', task, classLabel)
        resultSaver.write_result_csv(resultList, resultStorage.scoreThreshold, resultStorage.iouTreshold)
    
    if task in ['Test', 'Inference'] and resultStorage.drawResultImage["switch"]:
        draw_box(resultList, 
            os.path.join(outputPath, f"{task}ImageResult"), 
            classLabel, 
            resultStorage.scoreThreshold, 
            resultStorage.drawResultImage["lineThickness"])

