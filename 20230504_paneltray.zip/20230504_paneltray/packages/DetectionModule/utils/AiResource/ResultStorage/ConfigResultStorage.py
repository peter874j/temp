# -*- coding: utf-8 -*-

"""
Created on Mon Jun 15 17:00:00 2022
"""

### Choose result storage method ###
class ResultStoragePara:
    def __init__(self,
        saveFinalDictPth:dict,
        saveFinalScriptPth:dict,
        saveBestDictPth:dict,
        saveBestScriptPth:dict,
        saveCheckpoint:dict,
    ) -> None:
    
        """
            saveFinalDictPth (dict):{
                    "switch": (int) 0: enable, 1: disable
                }
            saveFinalScriptPth (dict): {
                    "switch": (int) 0: enable, 1: disable
                }
            saveBestDictPth (dict): {
                    "switch": (int) 0: enable, 1: disable
                }
            saveBestScriptPth (dict): {
                    "switch": (int) 0: enable, 1: disable
                }
            saveCheckpoint (dict): {
                    "switch": (int) 0: enable, 1: disable
                    "saveIter": (int) save checkpoint weight for every 'saveIter' epochs
                }
        """
        self.saveFinalDictPth    = saveFinalDictPth
        self.saveFinalScriptPth  = saveFinalScriptPth
        self.saveBestDictPth     = saveBestDictPth
        self.saveBestScriptPth   = saveBestScriptPth
        self.saveCheckpoint      = saveCheckpoint


class DetResultStoragePara(ResultStoragePara):
    def __init__(self, saveFinalDictPth:dict, saveFinalScriptPth:dict, saveBestDictPth:dict,
                       saveBestScriptPth:dict, saveCheckpoint:dict, scoreThreshold:float,
                       iouTreshold:float,  saveResultCsv:dict, drawResultImage:dict ) -> None:
        """
            scoreThreshold (float): confidence socre threshold
            iouTreshold (float):  prediction and solution area of interscetion union ratio
            saveResultCsv (dict):{
                    "switch"  : (int) 0: enable, 1: disable
                }
            drawResultImage (dict): {
                    "switch"  : (int) 0: enable, 1: disable
                }
        """
        super().__init__(saveFinalDictPth, saveFinalScriptPth, 
                        saveBestDictPth, saveBestScriptPth, 
                        saveCheckpoint)
       
        self.scoreThreshold      = scoreThreshold
        self.iouTreshold         = iouTreshold
        self.saveResultCsv       = saveResultCsv
        self.drawResultImage     = drawResultImage
        pass
    
    @classmethod
    def create_from_dict(cls, resultStorage:dict) -> None:
        """
        # Save final weight (.pth)
        resultStorage["saveFinalDictPth"]: (dict) {
            "switch": (int) 0: enable, 1: disable
        }

        # Save final model in torch script (.pth)
        resultStorage["saveFinalScriptPth"]: (dict) {
            "switch": (int) 0: enable, 1: disable
        }

        # Save best weight (.pth)
        resultStorage["saveBestDictPth"]: (dict) {
            "switch": (int) 0: enable, 1: disable
        }

        # Save best model into torch script (.pth)
        resultStorage["saveBestScriptPth"]: (dcit) {
            "switch": (int) 0: enable, 1: disable
        }

        # Save checkpoint weight for every 'saveIter' epochs
        resultStorage["saveCheckpoint"]: (dict) {
            "switch"  : (int) 0: enable, 1: disable
            "saveIter": (int) save checkpoint weight for every 'saveIter' epochs
        }

        resultStorage["scoreThreshold"]: (float) confidence socre threshold
        resultStorage["iouTreshold"]   : (float) prediction and solution area of interscetion union ratio

        # Save detection result to csv file
        resultStorage["saveResultCsv"]: (dict) {
            "switch"  : (int) 0: enable, 1: disable
        }
        # Plot the result on th image
        resultStorage["drawResultImage"]: (dict){
            "switch" : (int) 0: enable, 1: disable
        }
        """
        return cls(**resultStorage)
       
    

