# -*- coding: utf-8 -*-

import os
import shutil
from distutils.dir_util import copy_tree

from PIL import Image


def get_specific_files_list(filePath:str, fileType:str) -> list:
    """
    Returns a list of file names that match a specific extension or file type under the specified path

    Args:
        filePath (str): Specify the path
        fileType (str): Specify the data format. like: 'image', '.txt'
    
    Return:
        finalList (list): list of file names
    """
    finalList = []
    if fileType == 'image':
        for name in os.listdir(filePath):
            try:
                Image.open(os.path.join(filePath, name))
                finalList.append(name)
            except:
                continue
    else:
        for file in os.listdir(filePath):
            if file.endswith(fileType):
                finalList.append(file)
    return finalList

def copy_files_in_list(imageList:list, dataPath:str, folderName:str) -> None:
    """
    According to the given file name list, copy the data to the destination path

    Args:
        imageList  (list): [fileName(str), ....] filename list
        dataPath   (str) : data source folder
        folderName (str) : destination path
    """

    create_empty_folder(folderName)
    
    for imgName in imageList:
        shutil.copy(os.path.join(dataPath, imgName), folderName)

def copy_all_files(origPath:str, outputPath:str) -> None:
    """
    Copy everything under the source folder to the target location, 
    if the target location already exists, it will be completely replaced.

    Args:
        origPath   (str): Source folder (must be a folder)
        outputPath (str): target location path
    """
    resultPath = os.path.join(outputPath, origPath.split('/')[-1])
    create_empty_folder(resultPath)

    if os.path.isfile(origPath):
        raise BaseException("(State error) Please place the file in to a folder.")
        # shutil.copy(origPath, outputPath)

    elif os.path.isdir(origPath):
        copy_tree(origPath, resultPath)

def delete_files(filePath:str) -> None:
    """
    Delete the file or folder in the specified path

    Args:
        filePath (str): file or folder path
    """
    if os.path.isdir(filePath): shutil.rmtree(filePath)
    elif os.path.isfile(filePath): os.remove(filePath)
    else: pass


def create_empty_folder(folderPath:str) -> None:
    """
    Create the specified empty folder. 
    If a folder path is already exists, the old one will be deleted and created a new one.

    Args:
        folderPath (str): Create folder path
    """
    if os.path.isdir(folderPath): shutil.rmtree(folderPath)
    os.makedirs(folderPath)

def create_folder(folderPath:str) -> None:
    """
    Create storaged folder

    Args:
        folderPath (str): the path wants to create
    """
    if not os.path.isdir(folderPath):
        os.makedirs(folderPath)    