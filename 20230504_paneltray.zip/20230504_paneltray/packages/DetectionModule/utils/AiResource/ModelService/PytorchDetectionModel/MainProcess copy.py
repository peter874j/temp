import os
import time
# from turtle import shape
# os.environ["CUDA_VISIBLE_DEVICES"] = '2'
import torch
import torchvision
from main.Config import DetBasicSettingPara, PrivateSettingPara
from torch.utils.data import DataLoader
from ...Evaluation.ConfigEvaluation import DetEvaluationPara
from utils.AiResource.ModelService.PytorchDetectionModel.ConfigModelService import (
    LearningRatePara, OptimizerPara, ScalerPara, SchedulerPara)
from utils.AiResource.ModelService.PytorchDetectionModel.ConfigPostprocess import \
    PostprcessPara
from utils.AiResource.ModelService.PytorchDetectionModel.ConfigPytorchModel import (
    ServicePara, ModelPara, PathPara)
from utils.AiResource.ModelService.PytorchDetectionModel.SelectScaler import \
    select_scaler
from utils.AiResource.ResultStorage.ConfigResultStorage import \
    DetResultStoragePara
from ...Evaluation.ModuleEvaluation.Det.SaveConfusionMatrix import ConfusionMatrix
from ...Evaluation.ModuleEvaluation.Det.coco_eval import CocoEvaluator
from ...Evaluation.ModuleEvaluation.Det.coco_utils import get_coco_api_from_dataset
from ...Evaluation.SelectEvaluationMethod import det_select_evaluation
from .CustomDataset import DetectionDataset, create_sample_batch
from .package.utils import MetricLogger
from .package.engine import apply_nms, evaluate, train_one_epoch
from .package.presets import get_transform

from .SelectDetectionModel import select_model
from .SelectOptimizer import select_optimizer
from .SelectScheduler import select_scheduler
from ...ResultStorage.SelectStorageMethod import det_save_model

# ------------------- paneltray
# from pypylon import pylon
import cv2
import datetime
from torchvision import transforms
# -------------------

os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
### REPRODUCIBILITY
torch.manual_seed(0)
torch.backends.cudnn.deterministic = True
torch.backends.cudnn.benchmark = False

def train(
    basicSettingPara: DetBasicSettingPara,
    privateSettingPara: PrivateSettingPara,
    evaluationPara: DetEvaluationPara,
    learningRatePara: LearningRatePara,
    optimizerPara: OptimizerPara,
    schedulerPara: SchedulerPara,
    scalerPara: ScalerPara,
    servicePara: ServicePara,
    pathPara: PathPara,
    modelPara: ModelPara,
    resultStorage: DetResultStoragePara) -> None:
    """
    Training procedure: Use training data for model training, and record epoch mAP, best weight.
    Args:
        basicSettingPara    : record task attribute
        privateSettingPara  : record output path
        evaluationPara      : Parameters include all evaluation methods
        learningRatePara    : attribute learningRate: float
        optimizerPara       : Parameters include all optimizers
        schedulerPara       : Parameters include all schedulers
        scalerPara          : Parameters include all scaler
        servicePara         : Parameters include cudaDevice, batch size, total epochs, printEporchFreq and sample batch
        pathPara            : Include valid, train, test, inference data Path
        modelPara           : Parameters include one stage, two stage, torchvision model
        resultStorage       : Parameters include all result Storaged methods
    Return:
        weight.pth          : for saving weight
        Train_mAP.txt, Valid_mAP.txt
    """
    ##### Define GPU #####
    cudaDevice = torch.device('cuda:{}'.format(servicePara.cudaDevice) if torch.cuda.is_available() else 'cpu')

    # Data loading code
    print("Loading data")
    hasNotBackground = basicSettingPara.classNameDict.__contains__(0)
    classLabelHasBg = {k+1 : v for k, v in basicSettingPara.classNameDict.items()} if hasNotBackground else basicSettingPara.classNameDict
    numClasses = classLabelHasBg.__len__() + 1 if hasNotBackground else classLabelHasBg.__len__()

    print(f'class has background number is {numClasses}')
    trainSet = DetectionDataset(pathPara.trainPath, transform=get_transform(False, 'ssdlite'), hasNotBackground=hasNotBackground)
    validSet = DetectionDataset(pathPara.validPath, transform=get_transform(False, ''), hasNotBackground=hasNotBackground)

    print("Creating data loaders")
    if servicePara.sampleBatch["switch"]:
        trainBatch = {'batch_sampler': create_sample_batch(trainSet, servicePara.batchSize, isTrainData=True, aspectRatioGroupFactor=servicePara.sampleBatch["trainAspectGroup"])}
        validBatch = {'batch_size': servicePara.batchSize, 'sampler': create_sample_batch(validSet, servicePara.batchSize)}
    else:
        trainBatch = {'batch_size': servicePara.batchSize, 'shuffle': True}
        validBatch = {'batch_size': servicePara.batchSize, 'shuffle': False}

    trainLoader = DataLoader(
        trainSet, num_workers=0, collate_fn=trainSet.collate_fn, **trainBatch)

    validLoader = DataLoader(
        validSet, num_workers=0, collate_fn=validSet.collate_fn, **validBatch)

    print("select model")
    model = select_model(modelPara, pathPara, basicSettingPara.task, numClasses)
    model = model.to(cudaDevice)

    parameters = [p for p in model.parameters() if p.requires_grad]    # requires_grad 紀錄的值
    optimizer = select_optimizer(optimizerPara, learningRatePara.learningRate, parameters)
    scheduler = select_scheduler(schedulerPara, optimizer)
    scaler = select_scaler(scalerPara)

    print("Start training")
    bestmAP = 0
    for epoch in range(servicePara.epochs):
        localtime = time.asctime(time.localtime(time.time()))
        lineLength = len(f'Epoch: {epoch + 1}/{servicePara.epochs} --- < Starting Time : {localtime} >')
        singleLine = '-' * (int(lineLength/2) - 3)
        print('=' * lineLength)
        print(f'{singleLine} train {singleLine}')
        print(f'Epoch: {epoch + 1}/{servicePara.epochs} --- < Starting Time : {localtime} >')

        train_one_epoch(model, optimizer, trainLoader, cudaDevice, epoch, servicePara.printEpochFreq, scaler)
        scheduler.step()

        # evaluate after every epoch
        coco_evaluator_train = evaluate(model, trainLoader, device=cudaDevice)

        print(f'{singleLine} valid {singleLine}')
        coco_evaluator_val = evaluate(model, validLoader, device=cudaDevice)

        # gather the stats from all processes
        trainmAP = coco_evaluator_train.coco_eval["bbox"].stats[0]
        validmAP = coco_evaluator_val.coco_eval["bbox"].stats[0]
        print('train mAP is {}'.format(trainmAP))
        print('validation mAP is {}'.format(validmAP))
        print('best mAP is {}'.format(bestmAP))

        det_select_evaluation(evaluationPara, "Train", classLabelHasBg, privateSettingPara.outputPath, cocoEval=coco_evaluator_train.coco_eval["bbox"].stats, epochRecord=f"{epoch+1}/{servicePara.epochs}" )
        det_select_evaluation(evaluationPara, "Valid", classLabelHasBg, privateSettingPara.outputPath, cocoEval=coco_evaluator_val.coco_eval["bbox"].stats, epochRecord=f"{epoch+1}/{servicePara.epochs}" )
        ##### Save weight #####
        bestmAP = det_save_model(resultStorage, servicePara, privateSettingPara.outputPath, basicSettingPara.task, model, optimizer, bestmAP, validmAP, epoch)

def test(
    basicSettingPara: DetBasicSettingPara,
    servicePara: ServicePara,
    pathPara: PathPara,
    modelPara: ModelPara,
    postProcessPara: PostprcessPara,
    resultStoragePara: DetResultStoragePara,
):
    """
    Testing procedure: Use test data for model verification, and output the predicted result csv and confusion matrix.
    Args:
        basicSettingPara    : record task attribute
        servicePara         : Parameters include cudaDevice, batch size, total epochs, printEporchFreq and sample batch
        pathPara            : Include valid, train, test, inference data Path
        modelPara           : Parameters include one stage, two stage, torchvision model
        postProcessPara     : Parameters include all postprocee methods
        resultStoragePara       : Parameters include all result Storaged methods
    """
    ##### Define GPU #####
    cudaDevice = torch.device('cuda:{}'.format(servicePara.cudaDevice) if torch.cuda.is_available() else 'cpu')
    hasNotBackground = basicSettingPara.classNameDict.__contains__(0)
    classLabelHasBg = {k+1 : v for k, v in basicSettingPara.classNameDict.items()} if hasNotBackground else basicSettingPara.classNameDict
    numClasses = classLabelHasBg.__len__() + 1 if hasNotBackground else classLabelHasBg.__len__()

    print("Loading data")
    testSet = DetectionDataset(pathPara.testPath,
                            transform=get_transform(False, ''),
                            hasNotBackground=hasNotBackground)
    print("Creating data loaders")

    if servicePara.sampleBatch["switch"]:
        testBatch = {'batch_size': servicePara.batchSize, 'sampler': create_sample_batch(testSet, servicePara.batchSize)}
    else:
        testBatch = {'batch_size': 1}

    testLoader = DataLoader(
        testSet, num_workers=1, collate_fn=testSet.collate_fn, **testBatch)

    print("select model")
    model = select_model(modelPara, pathPara, basicSettingPara.task, numClasses)
    model = model.to(cudaDevice)
    model.eval()


    coco = get_coco_api_from_dataset(testLoader.dataset)
    cocoEvaluator = CocoEvaluator(coco, ["bbox"])

    metricLogger = MetricLogger(delimiter="  ")
    header = "Test:"

    confusionMatrix = ConfusionMatrix(classLabelHasBg, resultStoragePara.scoreThreshold, resultStoragePara.iouTreshold)
    with torch.no_grad():
        resultList = []
        for images, targets in metricLogger.log_every(testLoader, servicePara.printEpochFreq, header):
            images = list(img.to(cudaDevice) for img in images)
            prediction = model(images)[0]
            prediction = apply_nms(prediction, postProcessPara.nms['iouTreshold']) if postProcessPara.nms['order'] else prediction
            confusionMatrix.process(prediction, targets[0])
            predDict = {
                "image"          : torchvision.transforms.ToPILImage(mode='RGB')(images[0]),
                "boxes"          : prediction["boxes"].cpu().numpy(),
                "labels"         : prediction["labels"].cpu().numpy(),
                "scores"         : prediction["scores"].cpu().numpy(),
                "imageName"      : targets[0]['imageName'],
                "iou"            : ConfusionMatrix.box_iou(targets[0]['boxes'].cpu(), prediction['boxes'].cpu()),
                "matrix"         : confusionMatrix.matrix,
                "classLabelhasBg": classLabelHasBg,

            }
            
            resultList.append(predDict)
            
            if len(predDict["boxes"]) == 0:
                print("No target detected!")

            outputs = [{k: v.cpu() for k, v in prediction.items()}]
            res = {target["image_id"].item(): output for target, output in zip(targets, outputs)}
            cocoEvaluator.update(res)
        cocoEvaluator.synchronize_between_processes()
        # accumulate predictions from all images
        cocoEvaluator.accumulate()
        cocoEvaluator.summarize()
        cocoEval = cocoEvaluator.coco_eval["bbox"].stats

    testmAP = cocoEvaluator.coco_eval["bbox"].stats[0]
    print(f'test mAP is : {testmAP}')

    return resultList, cocoEval

def inference(
    basicSettingPara: DetBasicSettingPara,
    servicePara: ServicePara,
    pathPara: PathPara,
    modelPara: ModelPara,
    postProcessPara: PostprcessPara,
):
    """
    Inference procedure: Use trained model for detection inference data, and output the result csv.
    Args:
        basicSettingPara    : record task attribute
        servicePara         : Parameters include cudaDevice, batch size, total epochs, printEporchFreq and sample batch
        pathPara            : Include valid, train, test, inference data Path
        modelPara           : Parameters include one stage, two stage, torchvision model
        postProcessPara     : Parameters include all postprocee methods
    """
    ##### Define GPU #####
    cudaDevice = torch.device('cuda:{}'.format(servicePara.cudaDevice) if torch.cuda.is_available() else 'cpu')

    hasNotBackground = basicSettingPara.classNameDict.__contains__(0)
    classLabelHasBg = {k+1 : v for k, v in basicSettingPara.classNameDict.items()} if hasNotBackground else basicSettingPara.classNameDict
    numClasses = classLabelHasBg.__len__()+1 if hasNotBackground else classLabelHasBg.__len__()

    print("Loading data")
    inferenceSet = DetectionDataset(pathPara.inferencePath,
                                transform=get_transform(False, ''),
                                hasNotBackground=hasNotBackground,
                                isInference=True)

    print("Creating data loaders")
    if servicePara.sampleBatch["switch"]:
        inferenceBatch  = {'batch_size': servicePara.batchSize, 'sampler': create_sample_batch(inferenceSet, servicePara.batchSize)}
    else:
        inferenceBatch = {'batch_size': 1}

    inferenceLoader = DataLoader(
        inferenceSet, shuffle=False, num_workers=1, collate_fn=inferenceSet.collate_fn, **inferenceBatch)

    print("select model")
    model = select_model(modelPara, pathPara, basicSettingPara.task, numClasses)
    model = model.to(cudaDevice)
    model.eval()
    resultList = []
    with torch.no_grad():
        for images, targets in inferenceLoader:
            images = list(img.to(cudaDevice) for img in images)
            # print(images[0].shape)
            prediction = model(images)[0]
            prediction = apply_nms(prediction, postProcessPara.nms['iouTreshold']) if postProcessPara.nms['order'] else prediction
            predDict = {
                "image"          : torchvision.transforms.ToPILImage(mode='RGB')(images[0]),
                "boxes"          : prediction["boxes"].cpu().numpy(),
                "labels"         : prediction["labels"].cpu().numpy(),
                "scores"         : prediction["scores"].cpu().numpy(),
                "imageName"      : targets[0]["imageName"],
                "classLabelhasBg": classLabelHasBg
            }
            if len(predDict["boxes"]) == 0:
                print("No target detected!")
            resultList.append(predDict)

    return resultList


def inference_PanelTray(
    basicSettingPara: DetBasicSettingPara,
    servicePara: ServicePara,
    pathPara: PathPara,
    modelPara: ModelPara,
    postProcessPara: PostprcessPara,
):
    """
    Inference procedure: Use trained model for detection inference data, and output the result csv.
    Args:
        basicSettingPara    : record task attribute
        servicePara         : Parameters include cudaDevice, batch size, total epochs, printEporchFreq and sample batch
        pathPara            : Include valid, train, test, inference data Path
        modelPara           : Parameters include one stage, two stage, torchvision model
        postProcessPara     : Parameters include all postprocee methods
    """
    ##### Define GPU #####
    cudaDevice = torch.device('cuda:{}'.format(servicePara.cudaDevice) if torch.cuda.is_available() else 'cpu')

    hasNotBackground = basicSettingPara.classNameDict.__contains__(0)
    classLabelHasBg = {k+1 : v for k, v in basicSettingPara.classNameDict.items()} if hasNotBackground else basicSettingPara.classNameDict
    numClasses = classLabelHasBg.__len__()+1 if hasNotBackground else classLabelHasBg.__len__()

    print("Loading data")
    # # 讀相機
    # # conecting to the first available camera
    # camera = pylon.InstantCamera(pylon.TlFactory.GetInstance().CreateFirstDevice())
        
    # # Grabing Continusely (video) with minimal delay
    # camera.StartGrabbing(pylon.GrabStrategy_LatestImageOnly)
    # converter = pylon.ImageFormatConverter()
        
    # # converting to opencv bgr format
    # converter.OutputPixelFormat = pylon.PixelType_BGR8packed
    # converter.OutputBitAlignment = pylon.OutputBitAlignment_MsbAligned

    # # 曝光時間設定 ExposureTime
    # camera.ExposureTime.SetValue(120000)

    # while camera.IsGrabbing():
    #     grabResult = camera.RetrieveResult(1000, pylon.TimeoutHandling_ThrowException)

    #     if grabResult.GrabSucceeded():
    #         # Access the image data
    #         image = converter.Convert(grabResult)
    #         img = image.GetArray()

    #         # 觸發條件 --> 影像方法、PLC串接、sensor 等等，待確認

    ImgCrop_list = []
    for file in os.listdir(r"inference/"):
        img = cv2.imread(os.path.join(r"inference/", file))

        # crop
        ImgCrop_list += PenalTray_ImgCrop(img, file)


    print("select model")
    model = select_model(modelPara, pathPara, basicSettingPara.task, numClasses)
    model = model.to(cudaDevice)
    model.eval()
    resultList = []
    with torch.no_grad():
        for images, targets in ImgCrop_list:
            convert_tensor = transforms.ToTensor()
            images = [convert_tensor(images).to(cudaDevice)]
            prediction = model(images)[0]
            prediction = apply_nms(prediction, postProcessPara.nms['iouTreshold']) if postProcessPara.nms['order'] else prediction
            predDict = {
                "image"          : torchvision.transforms.ToPILImage(mode='RGB')(images[0]),
                "boxes"          : prediction["boxes"].cpu().numpy(),
                "labels"         : prediction["labels"].cpu().numpy(),
                "scores"         : prediction["scores"].cpu().numpy(),
                "imageName"      : targets,
                "classLabelhasBg": classLabelHasBg
            }
            if len(predDict["boxes"]) == 0:
                print("No target detected!")
            resultList.append(predDict)

    return resultList


def PenalTray_ImgCrop(img, file):
    # 檔名
    loc_dt = datetime.datetime.today()
    loc_dt_format = loc_dt.strftime("%Y_%m_%d_%H_%M_%S")

    crop_img_list = []

    # 裁切區域的 x 與 y 座標（左上角）
    x = 90
    y = 15

    # 裁切區域的長度與寬度
    w = 2271
    h = 1955

    # 裁切圖片
    crop_img = img[y:y+h, x:x+w]

    # crop 1
    # 裁切區域的 x 與 y 座標（左上角）
    x = 0
    y = 0

    # 裁切區域的長度與寬度
    w = 1230
    h = 1075
    crop_img_1 = crop_img[y:y+h, x:x+w]
    img_info = []
    img_info.append(crop_img_1)
    # img_info.append(loc_dt_format + '_1.jpg')
    img_info.append(file.split('.')[0] + '_1.jpg')
    crop_img_list.append(img_info)

    # crop 2
    # 裁切區域的 x 與 y 座標（左上角）
    x = 2271-1230
    y = 0

    # 裁切區域的長度與寬度
    w = 1230
    h = 1075
    crop_img_2 = crop_img[y:y+h, x:x+w]
    img_info = []
    img_info.append(crop_img_2)
    # img_info.append(loc_dt_format + '_2.jpg')
    img_info.append(file.split('.')[0] + '_2.jpg')
    crop_img_list.append(img_info)

    # crop 3
    # 裁切區域的 x 與 y 座標（左上角）
    x = 0
    y = 1955-1075

    # 裁切區域的長度與寬度
    w = 1230
    h = 1075
    crop_img_3 = crop_img[y:y+h, x:x+w]
    img_info = []
    img_info.append(crop_img_3)
    # img_info.append(loc_dt_format + '_3.jpg')
    img_info.append(file.split('.')[0] + '_3.jpg')
    crop_img_list.append(img_info)

    # crop 4
    # 裁切區域的 x 與 y 座標（左上角）
    x = 2271-1230
    y = 1955-1075

    # 裁切區域的長度與寬度
    w = 1230
    h = 1075
    crop_img_4 = crop_img[y:y+h, x:x+w]
    img_info = []
    img_info.append(crop_img_4)
    # img_info.append(loc_dt_format + '_4.jpg')
    img_info.append(file.split('.')[0] + '_4.jpg')
    crop_img_list.append(img_info)

    return crop_img_list
