# from msilib import type_nullable
import os
import time

import cv2
import numpy as np
from PIL import Image
import PIL
import PIL.ImageDraw as ImageDraw
import PIL.ImageFont as ImageFont
import collections

import torch
import torchvision
from torchvision import transforms
from mainConfig.Config import DetBasicSettingPara, PrivateSettingPara
from torch.utils.data import DataLoader
from ...Evaluation.ConfigEvaluation import DetEvaluationPara
from utils.AiResource.ModelService.PytorchDetectionModel.ConfigModelService import (
    LearningRatePara,
    OptimizerPara,
    ScalerPara,
    SchedulerPara,
)
from utils.AiResource.ModelService.PytorchDetectionModel.ConfigPostprocess import PostprcessPara
from utils.AiResource.ModelService.PytorchDetectionModel.ConfigPytorchModel import ServicePara, ModelPara, PathPara
from utils.AiResource.ModelService.PytorchDetectionModel.SelectScaler import select_scaler
from utils.AiResource.ResultStorage.ConfigResultStorage import DetResultStoragePara
from ...Evaluation.ModuleEvaluation.Det.SaveConfusionMatrix import ConfusionMatrix
from ...Evaluation.ModuleEvaluation.Det.coco_eval import CocoEvaluator
from ...Evaluation.ModuleEvaluation.Det.coco_utils import get_coco_api_from_dataset
from ...Evaluation.SelectEvaluationMethod import det_select_evaluation
from .CustomDataset import DetectionDataset, create_sample_batch
from .package.utils import MetricLogger
from .package.engine import apply_nms, evaluate, train_one_epoch
from .package.presets import get_transform

from .SelectDetectionModel import select_model
from .SelectOptimizer import select_optimizer
from .SelectScheduler import select_scheduler
from ...ResultStorage.SelectStorageMethod import det_save_model

os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
### REPRODUCIBILITY
torch.manual_seed(0)
torch.backends.cudnn.deterministic = True
torch.backends.cudnn.benchmark = False


def laod_model(
    basicSettingPara: DetBasicSettingPara,
    servicePara: ServicePara,
    pathPara: PathPara,
    modelPara: ModelPara,
):
    ##### Define GPU #####
    cudaDevice = torch.device("cuda:{}".format(servicePara.cudaDevice) if torch.cuda.is_available() else "cpu")

    hasNotBackground = basicSettingPara.classNameDict.__contains__(0)
    classLabelHasBg = (
        {k + 1: v for k, v in basicSettingPara.classNameDict.items()}
        if hasNotBackground
        else basicSettingPara.classNameDict
    )
    numClasses = classLabelHasBg.__len__() + 1 if hasNotBackground else classLabelHasBg.__len__()

    print("select model")
    model = select_model(modelPara, pathPara, basicSettingPara.task, numClasses)
    model = model.to(cudaDevice)
    model.eval()

    return model, classLabelHasBg, cudaDevice


def prediction_result(model, classLabelHasBg, image, postProcessPara: PostprcessPara, cudaDevice):
    resultList = []
    with torch.no_grad():
        convert_tensor = transforms.ToTensor()
        images = [convert_tensor(image).to(cudaDevice)]
        # print(image.shape)
        prediction = model(images)[0]
        prediction = (
            apply_nms(prediction, postProcessPara.nms["iouTreshold"]) if postProcessPara.nms["order"] else prediction
        )
        predDict = {
            "image": torchvision.transforms.ToPILImage(mode="RGB")(images[0]),
            "boxes": prediction["boxes"].cpu().numpy(),
            "labels": prediction["labels"].cpu().numpy(),
            "scores": prediction["scores"].cpu().numpy(),
            "imageName": "",
            "classLabelhasBg": classLabelHasBg,
        }
        if len(predDict["boxes"]) == 0:
            print("No target detected!")
        resultList.append(predDict)

    return resultList, classLabelHasBg


# -------------------------------------- drawBox --------------------------------------
STANDARD_COLORS = [
    "AliceBlue",
    "Chartreuse",
    "Aqua",
    "Aquamarine",
    "Azure",
    "Beige",
    "Bisque",
    "BlanchedAlmond",
    "BlueViolet",
    "BurlyWood",
    "CadetBlue",
    "AntiqueWhite",
    "Chocolate",
    "Coral",
    "CornflowerBlue",
    "Cornsilk",
    "Crimson",
    "Cyan",
    "DarkCyan",
    "DarkGoldenRod",
    "DarkGrey",
    "DarkKhaki",
    "DarkOrange",
    "DarkOrchid",
    "DarkSalmon",
    "DarkSeaGreen",
    "DarkTurquoise",
    "DarkViolet",
    "DeepPink",
    "DeepSkyBlue",
    "DodgerBlue",
    "FireBrick",
    "FloralWhite",
    "ForestGreen",
    "Fuchsia",
    "Gainsboro",
    "GhostWhite",
    "Gold",
    "GoldenRod",
    "Salmon",
    "Tan",
    "HoneyDew",
    "HotPink",
    "IndianRed",
    "Ivory",
    "Khaki",
    "Lavender",
    "LavenderBlush",
    "LawnGreen",
    "LemonChiffon",
    "LightBlue",
    "LightCoral",
    "LightCyan",
    "LightGoldenRodYellow",
    "LightGray",
    "LightGrey",
    "LightGreen",
    "LightPink",
    "LightSalmon",
    "LightSeaGreen",
    "LightSkyBlue",
    "LightSlateGray",
    "LightSlateGrey",
    "LightSteelBlue",
    "LightYellow",
    "Lime",
    "LimeGreen",
    "Linen",
    "Magenta",
    "MediumAquaMarine",
    "MediumOrchid",
    "MediumPurple",
    "MediumSeaGreen",
    "MediumSlateBlue",
    "MediumSpringGreen",
    "MediumTurquoise",
    "MediumVioletRed",
    "MintCream",
    "MistyRose",
    "Moccasin",
    "NavajoWhite",
    "OldLace",
    "Olive",
    "OliveDrab",
    "Orange",
    "OrangeRed",
    "Orchid",
    "PaleGoldenRod",
    "PaleGreen",
    "PaleTurquoise",
    "PaleVioletRed",
    "PapayaWhip",
    "PeachPuff",
    "Peru",
    "Pink",
    "Plum",
    "PowderBlue",
    "Purple",
    "Red",
    "RosyBrown",
    "RoyalBlue",
    "SaddleBrown",
    "Green",
    "SandyBrown",
    "SeaGreen",
    "SeaShell",
    "Sienna",
    "Silver",
    "SkyBlue",
    "SlateBlue",
    "SlateGray",
    "SlateGrey",
    "Snow",
    "SpringGreen",
    "SteelBlue",
    "GreenYellow",
    "Teal",
    "Thistle",
    "Tomato",
    "Turquoise",
    "Violet",
    "Wheat",
    "White",
    "WhiteSmoke",
    "Yellow",
    "YellowGreen",
]


def filter_low_thresh(
    predDict: dict, classLabel: dict, threshold: float, boxToDisplayStrMap: dict, boxToColorMap: dict
):
    """
    Filter out confidence scores below the lower threshold, and record display dict
    Args:
        predDict (dict): [
                "boxes"   (ndarray) : predict the coordinates of box
                "labels"  (ndarray) : predict box of category
                "scores"  (ndarray) : predict box confidence score
            ]
        classLabel (dict): number corresponds to category
        threshold (float): confidence socre threshold. Defaults to 0.5.
        boxToDisplayStrMap (dict): box item for display record
        boxToColorMap (dict): class name item for color record
    """
    boxes = predDict["boxes"]
    classes = predDict["labels"]
    scores = predDict["scores"]

    for i in range(boxes.shape[0]):
        if scores[i] > threshold:
            box = tuple(boxes[i].tolist())
            if classes[i] in classLabel.keys():
                labelName = classLabel[classes[i]]
            else:
                labelName = "N/A"
            displayStr = str(labelName)
            displayStr = "{}: {}%".format(displayStr, int(100 * scores[i]))
            boxToDisplayStrMap[box].append(displayStr)
            boxToColorMap[box] = STANDARD_COLORS[classes[i] % len(STANDARD_COLORS)]
        else:
            break


def draw_text(draw: ImageDraw, boxToDisplayStrMap: dict, box: list, color: str):
    """
    box class txt drawn on image

    Args:
        draw (ImageDraw): image can drawing type
        boxToDisplayStrMap (dict): box item for display record
        box (list): x1, y1, x2, y2
        color (str): color name in [STANDARD_COLORS]
    """
    try:
        # font = ImageFont.truetype('arial.ttf', 24)
        font = ImageFont.truetype("./calibril.ttf", 15)
    except IOError:
        font = ImageFont.load_default()

    left, top, right, bottom = box

    displayStrHeights = [font.getsize(ds)[1] for ds in boxToDisplayStrMap[box]]
    totalDisplayStrHeight = (1 + 2 * 0.05) * sum(displayStrHeights)

    if top > totalDisplayStrHeight:
        textBottom = top
    else:
        textBottom = bottom + totalDisplayStrHeight
    # Reverse list and print from bottom to top.
    for displayStr in boxToDisplayStrMap[box][::-1]:
        textWidth, textHeight = font.getsize(displayStr)
        margin = np.ceil(0.05 * textHeight)
        draw.rectangle([(left, textBottom - textHeight - 2 * margin), (left + textWidth, textBottom)], fill=color)
        draw.text((left + margin, textBottom - textHeight - margin), displayStr, fill="black", font=font)
        textBottom -= textHeight - 2 * margin


def draw_box_tool(predDict: dict, classLabel: dict, threshold: float = 0.5, lineThickness: int = 8) -> PIL:
    """
    draw box to image tool

    Args:
        predDict (dict):
            [
                "image"       (PIL) : image
                "boxes"   (ndarray) : predict the coordinates of box
                "labels"  (ndarray) : predict box of category
                "scores"  (ndarray) : predict box confidence score
                "imageName"   (str) : image name
            ]
        classLabel (dict):  number corresponds to category
        threshold (float, optional): confidence socre threshold. Defaults to 0.5.
        lineThickness (int, optional): The thickness of the box drawn on the image. Defaults to 8.

    Returns:
        after drawn on the image (PIL)
    """
    # collections.defaultdict　: can build dict without key and value
    boxToDisplayStrMap = collections.defaultdict(list)
    boxToColorMap = collections.defaultdict(str)

    filter_low_thresh(predDict, classLabel, threshold, boxToDisplayStrMap, boxToColorMap)

    # Draw all boxes onto image.
    imageResult = predDict["image"].copy()
    drawImage = ImageDraw.Draw(imageResult)
    for box, color in boxToColorMap.items():
        drawImage.rectangle(xy=box, width=lineThickness, outline=color)
        draw_text(drawImage, boxToDisplayStrMap, box, color)
    # return draw
    return imageResult


def draw_box(predDictList: list, classLabel: dict, threshold: float = 0.5, lineThickness: int = 8):
    """
    draw predict box to image

    Args:
        predDictList (list): for every item
        [
            "image"       (PIL) : image
            "boxes"   (ndarray) : predict the coordinates of box
            "labels"  (ndarray) : predict box of category
            "scores"  (ndarray) : predict box confidence score
            "imageName"   (str) : image name
        ]
        outputPath (str): output path
        classLabel (dict): number corresponds to category
        threshold (float, optional): confidence socre threshold. Defaults to 0.5.
        lineThickness (int, optional): The thickness of the box drawn on the image. Defaults to 8.
    """
    for predDict in predDictList:
        drawImage = draw_box_tool(predDict, classLabel, threshold, lineThickness)
        # drawImage.save(os.path.join(outputPath, predDict["imageName"]))
        return drawImage


# ------------------------------------------------------------------------------------------


@torch.no_grad()
def Detect_video(
    video_path, model, classLabelHasBg, postProcessPara, resultStoragePara, cudaDevice, save_video_path=None, show=True
):
    cap = cv2.VideoCapture(video_path)
    fourcc = cv2.VideoWriter_fourcc(*"MJPG")
    weight = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    if save_video_path:
        out = cv2.VideoWriter(save_video_path, fourcc, cap.get(5), (weight, height))
    while cap.isOpened():
        ret, frame = cap.read()
        if ret == True:
            image = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
            # image.save("./input/Data/2022_10_07_11_59_0_cam7.jpg")

            resultList, classLabelHasBg = prediction_result(model, classLabelHasBg, image, postProcessPara, cudaDevice)

            image = draw_box(
                resultList,
                classLabelHasBg,
                resultStoragePara.scoreThreshold,
                resultStoragePara.drawResultImage["lineThickness"],
            )

            frame = cv2.cvtColor(np.asarray(image), cv2.COLOR_RGB2BGR)
            out.write(frame)
            if show:
                cv2.imshow("frame", frame)
            if save_video_path:
                out.write(frame)
            if cv2.waitKey(1) & 0xFF == ord("q"):
                break
        else:
            break
    cap.release()
    if save_video_path:
        out.release()
    cv2.destroyAllWindows()
    return True
