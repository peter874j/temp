import torch
from torch import nn
import torch.optim as OptimizerMethod
from distutils.version import LooseVersion
from .ConfigModelService import OptimizerPara

def select_optimizer(
    optimizerPara: OptimizerPara,
    lr: float,
    modelPara:nn.parameter
) -> torch.functional:
    """
    According to configs in ConfigModelService, select and set up optimizer.
    Optimizer: SGD
    Args:
        optimizerPara   (OptimizerPara): Parameters include all optimizers
        lr                      (float): learning rate
        modelPara        (nn.parameter):
    Return:
        optimizer (torch.functional)
    """
    if optimizerPara.SGD["switch"]:
        method = getattr(OptimizerMethod, 'SGD')
        optimizer = method(params=modelPara, 
                           lr=lr,
                           momentum=optimizerPara.SGD["momentum"],
                           dampening=optimizerPara.SGD["dampening"],
                           weight_decay=optimizerPara.SGD["weightDecay"],
                           nesterov=optimizerPara.SGD["nesterov"],
                           )
    return optimizer