import torch.optim.lr_scheduler as SchedulerMethod
import torch
from .ConfigModelService import SchedulerPara

def select_scheduler(schedulerPara: SchedulerPara, optimizer: torch.functional) -> torch.functional:
    """
    According to configs in ConfigModelService, select scheduler to adjust learning rate of optimizer.
    Args:
        schedulerPara  (SchedulerPara): Parameters include all schedulers
        optimizer   (torch.functional): optimizer

    Return:
        scheduler
    """
    
    if schedulerPara.multiStepLR["switch"]:
        method = getattr(SchedulerMethod, 'MultiStepLR')
        scheduler = method(optimizer=optimizer,
                           milestones=schedulerPara.multiStepLR["milestones"],
                           gamma=schedulerPara.multiStepLR["gamma"],
                           )   

    return scheduler