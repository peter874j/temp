# -*- coding: utf-8 -*-

"""
Created on Mon Jun 15 17:00:00 2022
"""
class BasicSettingPara:
    def __init__(self, projectID: int, experimentID: int, task: str) -> None:
        """
        Args:
            projectID    (int): project ID
            experimentID (int): Experiment ID
            task         (str): 'Train', 'Test', 'Inference', 'Retrain', 'AnnotationTransfer'
        """
        self.projectID     = projectID
        self.experimentID  = experimentID
        self.task          = task
        pass

class ClsBasicSettingPara(BasicSettingPara):
    def __init__(self, projectID: int, experimentID: int, task: str, classNameList: list) -> None:
        """
        classNameList (list): give class list in 'Inference' task
        """
        super().__init__(projectID, experimentID, task)
        self.classNameList = classNameList
    
    @classmethod
    def create_from_dict(cls, basicSettingPara: dict):
        """
        basicSettingPara (dict): {
            projectID     (int) : project ID
            experimentID  (int) : Experiment ID
            task          (str) : 'Train', 'Test', 'Inference', 'Retrain', 'AnnotationTrans'
            classNameList (list): give class list in 'Inference' task
        }
        """
        return cls(**basicSettingPara)


class DetBasicSettingPara(BasicSettingPara):
    def __init__(self, projectID:int, experimentID:int, task:str, classNameDict:dict) -> None:
        """
        Args:
            classNameDict (dict): Corresponding index and label name to class labels
        """
        super().__init__(projectID, experimentID, task)
        self.classNameDict = {int(key):value for key, value in classNameDict.items()}
        pass

    @classmethod
    def create_from_dict(cls, basicSettingPara:dict):
        """
        basicSettingPara["projectID"]     (int) : project ID
        basicSettingPara["experimentID"]  (int) : Experiment ID
        basicSettingPara["task"]          (str) : 'Train', 'Test', 'Inference', 'Retrain', 'AnnotationTrans'
        basicSettingPara["classNameDict"] (dict): Corresponding index and label name to class labels
        """
        return cls(**basicSettingPara)


class PrivateSettingPara:
    def __init__(self, outputPath: str) -> None:
        """
        outputPath (str): The path that all result place.
        """
        self.outputPath = outputPath

    @classmethod
    def create_from_dict(cls, privateSettingPara: dict):
        """
        privateSettingPara (dict): {
            outputPath (str): The path that all result place.
        }
        """
        return cls(**privateSettingPara)