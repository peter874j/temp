# -*- coding: utf-8 -*-

"""
Created on Wed Jun 27 17:00:00 2022
"""
from utils.AiResource.DatasetClean import SelectDatasetCleanMethod
from utils.AiResource.DatasetClean.ConfigDataClean import DataCleanPara
from utils.AiResource.Evaluation import SelectEvaluationMethod
from utils.AiResource.Evaluation.ConfigEvaluation import DetEvaluationPara
from utils.AiResource.ModelService.PytorchDetectionModel import MainProcess
from utils.AiResource.ModelService.PytorchDetectionModel.ConfigModelService import (
    LearningRatePara, OptimizerPara, ScalerPara, SchedulerPara)
from utils.AiResource.ModelService.PytorchDetectionModel.ConfigPostprocess import \
    PostprcessPara
from utils.AiResource.ModelService.PytorchDetectionModel.ConfigPytorchModel import (
    ModelPara, PathPara, ServicePara)
from utils.AiResource.ResultStorage import SelectStorageMethod
from utils.AiResource.ResultStorage.ConfigResultStorage import \
    DetResultStoragePara

from main.ConfigLoader import load_json_config

from .Config import DetBasicSettingPara, PrivateSettingPara


def train(configDict:dict):
    '''
    Call training module
    '''
    print("Step 0: Create config object from dict.")
    basicSettingPara = DetBasicSettingPara.create_from_dict(configDict["Config"]["basicSettingPara"])
    privateSettingPara = PrivateSettingPara.create_from_dict(configDict["Config"]["privateSettingPara"])
    dataCleanPara = DataCleanPara.create_from_dict(configDict["ConfigDataClean"]["dataClean"])
    learningRatePara = LearningRatePara.create_from_dict(configDict["ConfigModelService"]["learningRatePara"])
    optimizerPara = OptimizerPara.create_from_dict(configDict["ConfigModelService"]["optimizerPara"])
    schedulerPara = SchedulerPara.create_from_dict(configDict["ConfigModelService"]["schedulerPara"])
    scalerPara = ScalerPara.create_from_dict(configDict["ConfigModelService"]["scalerPara"])
    servicePara = ServicePara.create_from_dict(configDict["ConfigPytorchModel"]["servicePara"])
    pathPara = PathPara.create_from_dict(configDict["ConfigPytorchModel"]["pathPara"])
    modelPara = ModelPara.create_from_dict(configDict["ConfigPytorchModel"]["modelPara"])
    evaluationPara = DetEvaluationPara.create_from_dict(configDict["ConfigEvaluation"]["evaluationPara"])
    resultStorage = DetResultStoragePara.create_from_dict(configDict["ConfigResultStorage"]["resultStorage"])

    print("Step 1: Split dataset")
    SelectDatasetCleanMethod.det_select_dataset_clean(dataCleanPara, pathPara)

    print("Step 2: AI model Training")
    MainProcess.train(
        basicSettingPara,
        privateSettingPara,
        evaluationPara,
        learningRatePara,
        optimizerPara,
        schedulerPara,
        scalerPara,
        servicePara,
        pathPara,
        modelPara,
        resultStorage,
    )


def test(configDict):
    '''
    Call testing module
    '''
    print("Step 0: Create config object from dict.")
    basicSettingPara = DetBasicSettingPara.create_from_dict(configDict["Config"]["basicSettingPara"])
    privateSettingPara = PrivateSettingPara.create_from_dict(configDict["Config"]["privateSettingPara"])
    servicePara = ServicePara.create_from_dict(configDict["ConfigPytorchModel"]["servicePara"])
    evaluationPara = DetEvaluationPara.create_from_dict(configDict["ConfigEvaluation"]["evaluationPara"])
    pathPara = PathPara.create_from_dict(configDict["ConfigPytorchModel"]["pathPara"])
    modelPara = ModelPara.create_from_dict(configDict["ConfigPytorchModel"]["modelPara"])
    resultStoragePara = DetResultStoragePara.create_from_dict(configDict["ConfigResultStorage"]["resultStorage"])
    postProcessPara = PostprcessPara.create_from_dict(configDict["ConfigPostprocess"]["postProcessPara"])

    print("Step 1: AI model Testing")
    resultList, cocoEval = MainProcess.test(
        basicSettingPara,
        servicePara,
        pathPara,
        modelPara,
        postProcessPara,
        resultStoragePara
    )

    classLabelhasBg = resultList[-1]["classLabelhasBg"]
    print("Step 2: Post-processing")

    print("Step 3: Evaluating")
    SelectEvaluationMethod.det_select_evaluation(
        evaluationPara,
        "Test",
        classLabelhasBg,
        privateSettingPara.outputPath,
        resultList,
        cocoEval
    )

    print("Step 4: Result Saveing")
    SelectStorageMethod.det_save_result(
        resultStoragePara,
        "Test",
        classLabelhasBg,
        privateSettingPara.outputPath,
        resultList
    )


def inference(configDict):
    '''
    Call inference module
    '''
    print("Step 0: Create config object from dict.")
    basicSettingPara = DetBasicSettingPara.create_from_dict(configDict["Config"]["basicSettingPara"])
    privateSettingPara = PrivateSettingPara.create_from_dict(configDict["Config"]["privateSettingPara"])
    servicePara = ServicePara.create_from_dict(configDict["ConfigPytorchModel"]["servicePara"])
    pathPara = PathPara.create_from_dict(configDict["ConfigPytorchModel"]["pathPara"])
    modelPara = ModelPara.create_from_dict(configDict["ConfigPytorchModel"]["modelPara"])
    resultStoragePara = DetResultStoragePara.create_from_dict(configDict["ConfigResultStorage"]["resultStorage"])
    postProcessPara = PostprcessPara.create_from_dict(configDict["ConfigPostprocess"]["postProcessPara"])

    print("Step 1: AI model Inference")
    resultList = MainProcess.inference(
        basicSettingPara,
        servicePara,
        pathPara,
        modelPara,
        postProcessPara,
    )
    classLabelhasBg = resultList[-1]["classLabelhasBg"]
    print("Step 2: Post-processing")

    print("Step 3: Result Saveing")
    SelectStorageMethod.det_save_result(
        resultStoragePara,
        "Inference",
        classLabelhasBg,
        privateSettingPara.outputPath,
        resultList
    )

def transfer_annotation(configDict: dict) -> None:
    print("Step 0: Create dataCleanPara object")
    dataCleanPara = DataCleanPara.create_from_dict(configDict["ConfigDataClean"]["dataClean"])
    print("Step 1: Annotation transfer")
    SelectDatasetCleanMethod.select_annotation_transfer(dataCleanPara)

def main():
    '''
    根據config中的task, 選擇對應程式執行
    '''
    configDict = load_json_config()
    basicSettingPara = DetBasicSettingPara.create_from_dict(configDict["Config"]["basicSettingPara"])
    print(f"......... Project: {basicSettingPara.projectID}, Experiment: {basicSettingPara.experimentID}, Mode: {basicSettingPara.task} .........")
    if basicSettingPara.task == 'Train':
        train(configDict)
    elif basicSettingPara.task == 'Test':
        test(configDict)
    elif basicSettingPara.task == 'Inference':
        inference(configDict)
    elif basicSettingPara.task == 'AnnotationTransfer':
        transfer_annotation(configDict)
    else:
        raise BaseException("Please set up the correct task mode in config/ConfigDet.py.")
