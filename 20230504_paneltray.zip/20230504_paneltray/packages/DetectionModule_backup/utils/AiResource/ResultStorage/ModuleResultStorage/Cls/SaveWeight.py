import os

import torch
import torch.functional
import torch.nn as nn


def create_folder(folderPath:str) -> None:
    """
    Create storaged folder

    Args:
        folderPath: the path wants to create
    """
    if not os.path.isdir(folderPath):
        os.makedirs(folderPath)


def save_weight(model:nn.Module, weightName:str, storagedPath:str) -> None:
    """
    Save the Model parameters in DictPth.

    Args:
        model: the entire model
        weightName: the saved weight file name
        storagedPath: the path to save weight file
    Output:
        xxx.pth: the weight file of model
    """
    create_folder(storagedPath)
    torch.save(model.state_dict(), f'{storagedPath}/{weightName}.pth')


def save_model_optimizer(
    epoch:int,
    model:nn.Module,
    optimizer:torch.functional,
    weightName:str,
    storagedPath:str
) -> None:
    """
    Save epoch, model and optimizer parameters for avoiding unexpected interruption.

    Args:
        epoch: current epoch number
        model: the entire model
        optimizer: the entire optimizer
        weightName: the saved weight file name
        storagedPath: the path to save weight file
    Output:
        checkpoint.pth: include "epoch", "model", "optimizer" parameters
    """
    create_folder(storagedPath)  
    torch.save({
                "epoch": epoch,
                "model": model.state_dict(),
                "optimizer": optimizer.state_dict()
                }, f'{storagedPath}/{weightName}.pth')


def save_script_model(model:nn.Module, weightName:str, storagedPath:str) -> None:
    """
    Save the whole Model in ScriptPth which include parameters and structure.

    Args:
        model: the entire model
        weightName: the saved weight file name
        storagedPath: the path to save weight file
    Output:
        FinetuneModel.pth: pth file with TorchScript model
    """
    create_folder(storagedPath)
    model_scripted = torch.jit.script(model)
    model_scripted.save(f'{storagedPath}/{weightName}.pth')


def pack_onnx(
    model:nn.Module,
    cudaDevice:torch.device,
    packageName:str,
    storagedPath:str,
    inputSize:list,
    inputChannel:int=3
) -> None:
    """
    Pack pytorch model into onnx model under the cuda state and save onnx file.

    Args:
        model: whole pytorch model including structure and weighted parameter
        cudaDevice: cuda deveice that used for training
        packageName: saved onnx model name
        storagedPath: the path to save weight file
        inputSize: image size that input to model
        inputChannel: number of image channel
    Return:
        .onnx file: onnx model file
    """
    model = model.to(cudaDevice)
    model.eval()
    
    dummyInput = torch.randn(1, inputChannel, inputSize[0], inputSize[1]).to(cudaDevice)
    packagePath = os.path.join(storagedPath, f'{packageName}.onnx')
    inputNames = ["input"]
    outputNames = ["output"]

    torch.onnx.export(
        model,                    # 要打包的模型
        dummyInput,               # 模型輸入大小
        packagePath,              # 輸出的打包檔名稱
        input_names=inputNames,   # 輸入層的名稱，驗證時要對應相同的input_names
        output_names=outputNames, # 輸出層的名稱
        export_params=True,       # 連參數權重一併打包輸出
    )

