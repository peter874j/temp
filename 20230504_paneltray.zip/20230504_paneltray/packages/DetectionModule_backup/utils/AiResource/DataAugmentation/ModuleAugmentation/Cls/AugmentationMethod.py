import torchvision.transforms as TF
from PIL import Image


class RandomHorizontalFlip(TF.RandomHorizontalFlip):
    """
    inherit RandomHorizontalFlip in transforms and process the parameters
    """
    def __init__(self, probability, **kwarg):
        super().__init__(p=probability, **kwarg)

class RandomVerticalFlip(TF.RandomVerticalFlip):
    """
    inherit RandomVerticalFlip in transforms and process the parameters
    """
    def __init__(self, probability, **kwarg):
        super().__init__(p=probability, **kwarg)

class RandomRotation(TF.RandomAffine):
    """
    inherit RandomRotation in transforms and process the parameters
    """
    def __init__(self, fill, **kwarg):
        super().__init__(fillcolor=tuple(fill), **kwarg)

class RandomTranslate(TF.RandomAffine):
    """
    inherit RandomTranslate in transforms and process the parameters
    """
    def __init__(self, fill, **kwarg):
        super().__init__(degrees=0, fillcolor=tuple(fill), **kwarg)

class RandomScale(TF.RandomAffine):
    """
    inherit RandomScale in transforms and process the parameters
    """
    def __init__(self, fill, **kwarg):
        super().__init__(degrees=0, fillcolor=tuple(fill), **kwarg)

class RandomShear(TF.RandomAffine):
    """
    inherit RandomShear in transforms and process the parameters
    """
    def __init__(self, fill, **kwarg):
        super().__init__(degrees=0, fillcolor=tuple(fill), **kwarg)

class RandomGrayscale(TF.RandomGrayscale):
    """
    inherit RandomGrayscale in transforms and process the parameters
    """
    def __init__(self, probability, **kwarg):
        super().__init__(p=probability, **kwarg)

class RandomBrightness(TF.ColorJitter):
    """
    inherit RandomBrightness in transforms and process the parameters
    """
    def __init__(self, **kwarg):
        super().__init__(**kwarg)

class RandomContrast(TF.ColorJitter):
    """
    inherit RandomContrast in transforms and process the parameters
    """
    def __init__(self, **kwarg):
        super().__init__(**kwarg)

class RandomSaturation(TF.ColorJitter):
    """
    inherit RandomSaturation in transforms and process the parameters
    """
    def __init__(self, **kwarg):
        super().__init__(**kwarg)

class RandomHue(TF.ColorJitter):
    """
    inherit RandomHue in transforms and process the parameters
    """
    def __init__(self, **kwarg):
        super().__init__(**kwarg)

class RandomPerspective(TF.RandomPerspective):
    """
    inherit RandomPerspective in transforms and process the parameters
    """
    def __init__(self, distortion, probability, interpolation, fill, **kwarg):
        super().__init__(distortion_scale=distortion, p=probability, fill=tuple(fill), **kwarg)
        self.interpolation = getattr(Image, interpolation)

class RandomErasing(TF.RandomErasing):
    """
    inherit RandomErasing in transforms and process the parameters
    """
    def __init__(self, probability, value, **kwarg):
        valueRGB = [x / 255 for x in value]
        super().__init__(p=probability, value=valueRGB, **kwarg)



################# Support in torch=0.10.0 #################
# class RandomPosterize(TF.RandomPosterize):
#     def __init__(self, probability, **kwarg):
#         super().__init__(p=probability, **kwarg)

# class RandomSolarize(TF.RandomSolarize):
#     def __init__(self, probability, **kwarg):
#         super().__init__(p=probability, **kwarg)

# class RandomAdjustSharpness(TF.RandomAdjustSharpness):
#     def __init__(self, probability, sharpness, **kwarg):
#         super().__init__(p=probability, sharpness_factor=sharpness, **kwarg)

# class RandomAutocontrast(TF.RandomAutocontrast):
#     def __init__(self, probability, **kwarg):
#         super().__init__(p=probability, **kwarg)