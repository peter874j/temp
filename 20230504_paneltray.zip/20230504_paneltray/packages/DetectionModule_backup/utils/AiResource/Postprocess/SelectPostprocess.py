# -*- coding: utf-8 -*-

"""
Created on Jun Tue 14 22:00:00 2022
"""
from .ConfigPostprocess import PostProcessPara
from .ModulePostprocess.Cls.ConfidenceFilter import confidence_filter
from .ModulePostprocess.Cls.UnknownFilter import unknown_filter


def cls_select_postprocess(resultList:list, postProcessPara:PostProcessPara) -> list:
    """
    According to configs in ConfigPostprocess, select the post processing method.

    Args:
        resultList: result list form model
        postProcessPara: include all post process filters parameters
    Return:
        resultList: after post-processing
    """
    if postProcessPara.confidenceFilter["order"]:
        resultList = confidence_filter(resultList, **postProcessPara.confidenceFilter["parameters"])
    if postProcessPara.unknownFilter["order"]:
        resultList = unknown_filter(resultList, **postProcessPara.unknownFilter["parameters"])

    return resultList
