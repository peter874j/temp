import os, json, shutil

def write_json(jsonFile:dict, fileName:str, outputPath:str):
    """write json file

    Args:
        jsonFile (dict): the dictionary you want to save
        fileName (str): json file name you want to save
        outputPath (str): output path to save json file to
    """
    with open(f'{outputPath}/{fileName}.json', "w") as outfile:
        json.dump(jsonFile, outfile)    


def create_folder(folderPath:str) -> None:
    """
    Create storaged folder

    Args:
        folderPath (str): the path wants to create
    """
    if not os.path.isdir(folderPath):
        os.makedirs(folderPath) 


def delete_folder(path:str):
    """you want to delete folder path

    Args:
        path (str): you want to delete folder path
    """
    try:
        shutil.rmtree(path)
    except OSError as e:
        print("Error: %s : %s" % (path, e.strerror))

def delete_under_folder_file(path:str):
    """The path where you want to delete all files under the folder

    Args:
        path (str): The path where you want to delete all files under the folder
    """
    for i in os.listdir(path):
        try:
            os.remove(os.path.join(path, i))
        except OSError as e:
            print("Error: %s : %s" % (os.path.join(path, i), e.strerror))
