from utils.sampleInference import inference

if __name__ == '__main__':
    resultList = inference()
    for i, finalResult in enumerate(resultList):
        print("FileName: {:15s}  Prediction: {:15s}  Confidence: {}".format(finalResult['filename'], finalResult['predict'], finalResult['confidence']))