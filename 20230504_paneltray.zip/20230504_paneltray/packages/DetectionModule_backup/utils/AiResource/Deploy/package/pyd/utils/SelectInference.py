import collections
from torchvision import transforms
from .ConfigSetting import PreprocessPara, ClsPostProcessPara
from . import PreprocessMethod
from . import PostprocessMethod
from . import SaveResultMethod
import os
from PIL import Image
from torch.utils.data import Dataset

#### tools ####
def sort_dict_by_value(sortDict: dict) -> dict:
    """
    Sort Dict according to value["order"], the order should be non-negative integer
    1. value["order"] is 0, meaning not used.
    2. value["order"] must be greater than 0
    3. value["order"] must be integer
    4. value["order"] can not be repeated

    Args:
        sortDict (dict): {key: {"order": num}, ...}
    
    return:
        resultDict (dict): sorted dict
    """
    resultDict = collections.OrderedDict()
    _recordOrder = []
    for key, value in sortDict.items():
        # 1. unused
        if value["order"] == 0:
            continue
        
        # 2&3. check if value["order"] is non-negative integer
        if value["order"] < 0 or not isinstance(value["order"], int):
            raise ValueError(f'The order of "{key}" in main/ConfigCls.json should be a non-negative integer.')
        
        # 4. check value["order"] is not repeated
        if value["order"] not in _recordOrder:
            _recordOrder.append(value["order"])
        else:
            raise ValueError(f'The order of "{[k for k, v in sortDict.items() if v["order"] == value["order"]]}" in main/ConfigCls.json is the same as other operation.')
        
        # keep used dict
        resultDict[key] = value
    resultDict = dict(sorted(resultDict.items(), key=lambda item: item[1]["order"]))
    return resultDict


#### preprocess ####
def cls_set_preprocess_transform(prePara: dict) -> list:
    """
    set preprocess transform: according to preprocessPara, setting transform module.
    
    Args:
        preprocessPara: a dict that include selected preprocess setting
    Return:
        preTransformList: preprocess transform list
    """
    preTransformList = []
    for method, config in prePara.items():
        if  method != 'Normalize':
            transformsMethod = getattr(PreprocessMethod, method)(**config["parameters"])
            preTransformList.append(transformsMethod)
    return preTransformList

def cls_select_transform(
    prePara: PreprocessPara,
) -> transforms.Compose:
    """
    Set test or inference transform: according to preprocessPara, setting transform module.

    Args:
        prePara: including all preprocess setting
        normalizedValue: {"mean": list, "std": list}
    Return:
        dataTransforms: test or inference transform
    """
    preprocessDict = sort_dict_by_value(prePara)
    transformList = cls_set_preprocess_transform(preprocessDict)
    transformList.append(transforms.ToTensor())
    if prePara["Normalize"]["order"] > 0 and isinstance(prePara["Normalize"]["order"], int):
        transformList.append(
            transforms.Normalize(
                prePara["Normalize"]["parameters"]["mean"], 
                prePara["Normalize"]["parameters"]["std"])
            )

    dataTransforms = transforms.Compose(transformList)
    return dataTransforms

#### postprocess ####
def cls_select_postprocess(resultList:list, postProcessPara:ClsPostProcessPara) -> list:
    """
    According to configs in ConfigPostprocess, select the post processing method.

    Args:
        resultList: result list form model
        postProcessPara: include all post process filters parameters
    Return:
        resultList: after post-processing
    """
    # postProcessPara = sort_dict_by_value(postProcessPara)
    # for method, config in postProcessPara.items():
    #     resultList = getattr(PostprocessMethod, method)(**config["parameters"])
    if postProcessPara.confidenceFilter["order"]:
        resultList = PostprocessMethod.confidence_filter(resultList, **postProcessPara.confidenceFilter["parameters"])
    if postProcessPara.unknownFilter["order"]:
        resultList = PostprocessMethod.unknown_filter(resultList, **postProcessPara.unknownFilter["parameters"])

    return resultList

#### result saving ####
def cls_save_result(
    resultList:list,
    classNameList:list,
    outputPath:str,
    csvSave:dict
) -> None:
    """
    output prediction for 3 types as csv file which include unknownFilter, normal prediction, and wrong file.

    Args:
        resultList: output result of model or result after postprocess (if selected)
        [{
            'filename': 'BUMP_184_TOP_ok_70_31.bmp',
            'label': 'OK',
            'predict': 'OK',
            'confidence': 0.9999998807907104
            'output': {
                'NG': 8.45041796537771e-08,
                'OK': 0.9999998807907104
                }
        }, {...}
        ]
        classNameList: including all classes name
        outputPath: the output path of csv files
    """
    if csvSave["switch"]:
        classNameList.sort()
        classNameList.sort(key=lambda x:x)
        for count, result in enumerate(resultList):
            SaveResultMethod.ResultCsv(result, count, outputPath, classNameList).write_result(f'{csvSave["name"]}.csv')

#### dataset ####
class InferenceDataset(Dataset):
    """
    Custom Dataset of ImageDataset, which is used for inference
    In this dataset, the label is all 0, cause inference data has no label.
    """
    def __init__(self, rootDir, transform=None):
        self.rootDir = rootDir
        self.x = []
        self.filename = []
        self.transform = transform
        for name in os.listdir(rootDir):
            try:
                Image.open(os.path.join(rootDir, name)).convert('RGB')
                self.filename.append(name)
                self.x.append(os.path.join(rootDir, name))
            except:
                continue
    
    def __len__(self):
        return len(self.filename)

    def __getitem__(self, index):
        image = Image.open(self.x[index]).convert('RGB')
        if self.transform:
            image = self.transform(image)
        # Inference has no label
        label = 0
        return image, label
