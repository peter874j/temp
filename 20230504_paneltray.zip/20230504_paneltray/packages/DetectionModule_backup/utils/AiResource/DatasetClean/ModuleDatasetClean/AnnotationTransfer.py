import os, csv
import pathlib
import xml.etree.ElementTree as ET
from math import ceil
from xml.dom.minidom import Document
import matplotlib.pyplot as plt
from utils.AiResource.DatasetClean.ModuleDatasetClean.BasicFileProcess import *
from typing import Tuple

class AnnotationTransferTools():
    """Annotation conversion tools"""

    @staticmethod
    def check_annotation_type(labelPath:str) -> str:
        """
        Check if the annotation type is 'bbox_xml', 'yolo_txt', 'bbox_txt' or 'bbox_csv'

        Args:
            labelPath      (str): annotation path

        Returns:
            annotationType (str): your annotation type
        """
        annotationType = None
        if len(get_specific_files_list(labelPath, ".xml")) > 0:
            fileNameList = get_specific_files_list(labelPath, ".xml")
            annotationType = "bbox_xml"
        elif len(get_specific_files_list(labelPath, ".csv")) > 0:
            annotationType = "bbox_csv"
        elif len(get_specific_files_list(labelPath, ".txt")) > 0:
            fileNameList = get_specific_files_list(labelPath, ".txt")
            with open(os.path.join(labelPath, fileNameList[0]), 'r', newline='') as Txt: 
                data = Txt.readlines()
                _, _, _, w, h = data[0].strip().split(' ')
                if float(w) < 1 and float(h) < 1:
                    annotationType = "yolo_txt"
                elif float(w) > 1 and float(h) > 1:
                    annotationType = "bbox_txt"

        if annotationType != None:
            return  annotationType
        else:
            raise BaseException(f"Annotation is not yolo or bbox or xml, please confirm your annotation data format")


    @staticmethod
    def image_shape(inputImagePath:str, fileName:str) -> Tuple[str, list]:
        """
        get image information

        Args:
            inputImagePath (str): input image path
            fileName       (str): file name

        Raises:
            BaseException: do not have any image name is "fileName" in "inputImagePath" path

        Returns:
            imageName       (str) : image name
            list(img.shape) (list): image shape
        """
        fileName = pathlib.Path(fileName).stem
        for imageName in os.listdir(inputImagePath):
            if imageName.startswith(fileName):
                img = plt.imread(os.path.join(inputImagePath, imageName))
                return imageName, list(img.shape)

        raise BaseException(f'do not have any image name is {fileName} in {inputImagePath} path')

    @staticmethod
    def __writing_bbox_txt(result:list, imageName:str, outputPath:str, mode:str='w') -> None:
        """
        Write bbox or yolo format to txt file

        Args:
            result     (2d list)      : [[classId(int), a, b, c, d], ....]
                Each sublist is a bbox, which record class id and box information(a, b, c, d)
                a, b, c, d can be bbox format with int dtype or yolo format with float type
            imageName  (str)          : image name
            outputPath (str)          : Save annotation output path
            mode       (str, optional): Saving txt mode type. Defaults to 'w'.
        """
        annotationFileName = imageName.replace(pathlib.Path(imageName).suffix, '.txt')
        with open(os.path.join(outputPath, annotationFileName), mode, newline='') as bboxTxt:  
            for i in result:
                word = f"{i[0]} {i[1]} {i[2]} {i[3]} {i[4]}\n"
                bboxTxt.write(word)
        pass
    
    @staticmethod
    def __writing_bbox_xml(result:list, imageName:str, imagePath:str, imageShape:list, outputPath:str) -> None:
        """
        Write bounding box using xml format

        Args:
            result  (2d list): [[className(str), xmin(int), ymin(int), xmax(int), ymax(int)], ....]
                Each sublist is a bbox, which record class label and box information(xmin, ymin, xmax, ymax) in bbox format
            imageName  (str) : image name
            imagePath  (str) : Image file path
            imageShape (list): [wight(int), height(int), channel(int)] image relative size
            outputPath (str) : Save annotation output path
        """

        xmlBuilder = Document()
        annotation = xmlBuilder.createElement("annotation")
        xmlBuilder.appendChild(annotation)
        
        for index, value in enumerate(result):
            if index == 0:
                folder = xmlBuilder.createElement("folder")
                folderContent = xmlBuilder.createTextNode(os.path.basename(imagePath))
                folder.appendChild(folderContent)
                annotation.appendChild(folder)

                filename = xmlBuilder.createElement("filename")
                filenameContent = xmlBuilder.createTextNode(imageName)
                filename.appendChild(filenameContent)
                annotation.appendChild(filename)

                path = xmlBuilder.createElement("path")
                pathContent = xmlBuilder.createTextNode(os.path.join(imagePath, imageName))
                # pathContent = xmlBuilder.createTextNode(os.path.dirname(imagePath))
                path.appendChild(pathContent)
                annotation.appendChild(path)

                source = xmlBuilder.createElement("source")
                database = xmlBuilder.createElement("database")
                databaseContent = xmlBuilder.createTextNode("AUO MAMC DataBase")
                database.appendChild(databaseContent)
                source.appendChild(database)
                annotation.appendChild(source)

                size = xmlBuilder.createElement("size")
                width = xmlBuilder.createElement("width")
                widthContent = xmlBuilder.createTextNode(str(imageShape[0]))
                width.appendChild(widthContent)
                height = xmlBuilder.createElement("height")
                heightContent = xmlBuilder.createTextNode(str(imageShape[1]))
                height.appendChild(heightContent)
                depth = xmlBuilder.createElement("depth")
                depthContent = xmlBuilder.createTextNode(str(imageShape[2]))
                depth.appendChild(depthContent)
                size.appendChild(width)
                size.appendChild(height)
                size.appendChild(depth)
                annotation.appendChild(size)

                segmented = xmlBuilder.createElement("segmented")
                segmentedContent = xmlBuilder.createTextNode("0")
                segmented.appendChild(segmentedContent)
                annotation.appendChild(segmented)

            objectTag = xmlBuilder.createElement("object")
            labelName = xmlBuilder.createElement("name")
            nameContent = xmlBuilder.createTextNode(value[0])
            labelName.appendChild(nameContent)
            objectTag.appendChild(labelName)

            pose = xmlBuilder.createElement("pose")
            poseContent = xmlBuilder.createTextNode("Unspecified")
            pose.appendChild(poseContent)
            objectTag.appendChild(pose)

            truncated = xmlBuilder.createElement("truncated")
            truncatedContent = xmlBuilder.createTextNode("0")
            truncated.appendChild(truncatedContent)
            objectTag.appendChild(truncated)

            difficult = xmlBuilder.createElement("difficult")
            difficultContent = xmlBuilder.createTextNode("0")
            difficult.appendChild(difficultContent)
            objectTag.appendChild(difficult) 

            occluded = xmlBuilder.createElement("occluded")
            occludedContent = xmlBuilder.createTextNode("0")
            occluded.appendChild(occludedContent)
            objectTag.appendChild(occluded)

            bndbox = xmlBuilder.createElement("bndbox")
            xmin = xmlBuilder.createElement("xmin")
            xminContent = xmlBuilder.createTextNode(str(value[1]))
            xmin.appendChild(xminContent)
            bndbox.appendChild(xmin)
            ymin = xmlBuilder.createElement("ymin")
            yminContent = xmlBuilder.createTextNode(str(value[2]))
            ymin.appendChild(yminContent)
            bndbox.appendChild(ymin)
            xmax = xmlBuilder.createElement("xmax")
            xmaxContent = xmlBuilder.createTextNode(str(value[3]))
            xmax.appendChild(xmaxContent)
            bndbox.appendChild(xmax)
            ymax = xmlBuilder.createElement("ymax")
            ymaxContent = xmlBuilder.createTextNode(str(value[4]))
            ymax.appendChild(ymaxContent)
            bndbox.appendChild(ymax)
            objectTag.appendChild(bndbox)

            annotation.appendChild(objectTag)

        annotationFileName = imageName.replace(pathlib.Path(imageName).suffix, '.xml')

        with open(os.path.join(outputPath, annotationFileName), "w") as xmlfile:
            xmlBuilder.writexml(xmlfile, indent='\t', newl='\n', addindent='\t', encoding='utf-8')
        pass

    @staticmethod
    def __yolo_to_bbox(imageShape:list, yoloBox:list) -> list:
        """
        Convert yolo data format to bounding box data format

        Args:
            imageShape (list): [wight(int), height(int), channel(int)] image relative size
            yoloBox    (list): [X_center(float), Y_center(float), W_rate(float), H_rate(float)]: list of yolo data format

        Returns:
            [x_min(int), y_min(int), x_max(int), y_max(int)] (list): list of bbox data format
        """
        imageW, imageH, _ = imageShape
        xmin = ceil((float(yoloBox[0]) - float(yoloBox[2]) / 2) * imageW)
        ymin = ceil((float(yoloBox[1]) - float(yoloBox[3]) / 2) * imageH)
        xmax = ceil((float(yoloBox[0]) + float(yoloBox[2]) / 2) * imageW)
        ymax = ceil((float(yoloBox[1]) + float(yoloBox[3]) / 2) * imageH)
        return [xmin, ymin, xmax, ymax]

    @staticmethod
    def __bbox_to_yolo(imageShape:list, bBox:list) -> list:
        """
        Convert bbox data format to yolo data format

        Args:
            imageShape (list): [wight(int), height(int), channel(int)] image relative size
            bBox       (list): [x_min(int), y_min(int), x_max(int), y_max(int)] list of bounding box data format

        Returns:
            [X_center(float), Y_center(float), W_rate(float), H_rate(float)] (list): list of yolo data format
        """
        imageW, imageH, _ = imageShape
        xcenter = (float(bBox[2]) + float(bBox[0])) / 2 / imageW
        ycenter = (float(bBox[3]) + float(bBox[1])) / 2 / imageH
        width = (float(bBox[2]) - float(bBox[0])) / imageW
        height = (float(bBox[3]) - float(bBox[1])) / imageH
        return [xcenter, ycenter, width, height]


    @classmethod
    def bbox_xml_to_bbox_txt(cls, inputLabelPath:str, outputPath:str, fileName:str, 
                             inputImagePath:str, classNameDict:dict) -> None:
        """
        Convert bbox xml format to bbox txt format

        Args:
            inputLabelPath (str) : input Label path
            outputPath     (str) : output path
            fileName       (str) : file name
            inputImagePath (str) : input image path, defaults to None.
            classNameDict  (dict): {classNumber(int): className(str), ....} the class name corresponding to the number. Defaults to None.
        """
        imageName, imageShape = cls.image_shape(inputImagePath, fileName)
        xmlTree = ET.parse(os.path.join(inputLabelPath, fileName))
        classNameRevers = dict(zip(classNameDict.values(), classNameDict.keys()))  # {str, int}
        xmlRoot = xmlTree.getroot()
        result = []
        for xmlObj in xmlRoot.findall('object'):
            labelName = xmlObj.find('name').text
            bndbox = xmlObj.find('bndbox')
            xmin = bndbox.find('xmin').text
            ymin = bndbox.find('ymin').text
            xmax = bndbox.find('xmax').text
            ymax = bndbox.find('ymax').text
            if labelName in classNameDict.values():
                result.append([classNameRevers[labelName], xmin, ymin, xmax, ymax])
        cls.__writing_bbox_txt(result, imageName, outputPath)
        pass

    @classmethod
    def bbox_xml_to_yolo_txt(cls, inputLabelPath:str, outputPath:str, fileName:str, 
                             inputImagePath:str, classNameDict:dict) -> None:
        """
        Convert bbox xml format to yolo txt format

        Args:
            inputLabelPath (str) : input Label path
            outputPath     (str) : output path
            fileName       (str) : file name
            inputImagePath (str) : input image path, defaults to None.
            classNameDict  (dict): {classNumber(int): className(str), ....} the class name corresponding to the number. Defaults to None.
        """
        imageName, imageShape = cls.image_shape(inputImagePath, fileName)
        xmlTree = ET.parse(os.path.join(inputLabelPath, fileName))
        classNameRevers = dict(zip(classNameDict.values(), classNameDict.keys()))  # {str, int}
        xmlRoot = xmlTree.getroot()
        result = []
        for xmlObj in xmlRoot.findall('object'):
            labelName = xmlObj.find('name').text
            bndbox = xmlObj.find('bndbox')
            xmin = bndbox.find('xmin').text
            ymin = bndbox.find('ymin').text
            xmax = bndbox.find('xmax').text
            ymax = bndbox.find('ymax').text
            yoloBbox = cls.__bbox_to_yolo(imageShape, [xmin, ymin, xmax, ymax])
            if labelName in classNameDict.values():
                result.append([classNameRevers[labelName], *yoloBbox])
        cls.__writing_bbox_txt(result, imageName, outputPath)
        pass


    @classmethod
    def yolo_txt_to_bbox_txt(cls, inputLabelPath:str, outputPath:str, fileName:str, 
                             inputImagePath:str, classNameDict:dict) -> None:
        """
        Convert yolo txt format to bbox txt format

        Args:
            inputLabelPath (str) : input Label path
            outputPath     (str) : output path
            fileName       (str) : file name
            inputImagePath (str) : input image path, defaults to None.
            classNameDict  (dict): {classNumber(int): className(str), ....} the class name corresponding to the number. Defaults to None.
        """   
        imageName, imageShape = cls.image_shape(inputImagePath, fileName)     
        result = []
        with open(os.path.join(inputLabelPath, fileName), 'r', newline='') as yoloTxt: 
            data = yoloTxt.readlines()
            for i in data:
                classId, x, y, w, h = i.split(' ')
                bbox = cls.__yolo_to_bbox(imageShape, [x, y, w, h])
                if int(classId) in classNameDict:
                    result.append([classId, *bbox])
        cls.__writing_bbox_txt(result, imageName, outputPath)
        pass

    @classmethod
    def yolo_txt_to_bbox_xml(cls, inputLabelPath:str, outputPath:str, fileName:str, 
                             inputImagePath:str, classNameDict:dict) -> None:
        """
        Convert yolo txt format to bbox xml format

        Args:
            inputLabelPath (str) : input Label path
            outputPath     (str) : output path
            fileName       (str) : file name
            inputImagePath (str) : input image path, defaults to None.
            classNameDict  (dict): {classNumber(int): className(str), ....} the class name corresponding to the number. Defaults to None.
        """
        imageName, imageShape = cls.image_shape(inputImagePath, fileName)
        result = []
        with open(os.path.join(inputLabelPath, fileName), 'r', newline='') as yoloTxt: 
            data = yoloTxt.readlines()
            for i in data:
                classId, x, y, w, h = i.split(' ')
                bbox = cls.__yolo_to_bbox(imageShape, [x, y, w, h])
                if int(classId) in classNameDict.keys():
                    result.append([classNameDict[int(classId)], *bbox])

        cls.__writing_bbox_xml(result, imageName, inputImagePath, imageShape, outputPath)
        pass


    @classmethod
    def bbox_txt_to_yolo_txt(cls, inputLabelPath:str, outputPath:str, fileName:str, 
                             inputImagePath:str, classNameDict:dict) -> None:
        """
        Convert bbox txt format to yolo txt format

        Args:
            inputLabelPath (str) : input Label path
            outputPath     (str) : output path
            fileName       (str) : file name
            inputImagePath (str) : input image path, defaults to None.
            classNameDict  (dict): {classNumber(int): className(str), ....} the class name corresponding to the number. Defaults to None.
        """
        result = []
        with open(os.path.join(inputLabelPath, fileName), 'r', newline='') as yoloTxt: 
            data = yoloTxt.readlines()
            imageName, imageShape = cls.image_shape(inputImagePath, fileName)
            for i in data:
                classId, x1, y1, x2, y2 = i.split(' ')
                bbox = cls.__bbox_to_yolo(imageShape, [x1, y1, x2, y2])
                if int(classId) in classNameDict.keys():
                    result.append([classId, *bbox])
        cls.__writing_bbox_txt(result, imageName, outputPath)
        pass   
    
    @classmethod
    def bbox_txt_to_bbox_xml(cls, inputLabelPath:str, outputPath:str, fileName:str, 
                             inputImagePath:str, classNameDict:dict) -> None:
        """
        Convert bbox txt format to bbox xml format

        Args:
            inputLabelPath (str) :  input Label path
            outputPath     (int) :  output path
            fileName       (str) :  file name
            inputImagePath (str) :  input image path, defaults to None.
            classNameDict  (dict):  {classNumber(int): className(str), ....} the class name corresponding to the number. Defaults to None.
        """
        imageName, imageShape = cls.image_shape(inputImagePath, fileName)
        result = []
        with open(os.path.join(inputLabelPath, fileName), 'r', newline='') as yoloTxt: 
            data = yoloTxt.readlines()
            for i in data:
                classId, x1, y1, x2, y2 = i.strip().split(' ')
                if int(classId) in classNameDict.keys():
                    result.append([classNameDict[int(classId)], x1, y1, x2, y2])
                
        cls.__writing_bbox_xml(result, imageName, inputImagePath, imageShape, outputPath)
        pass

    @classmethod
    def bbox_csv_to_bbox_txt(cls, inputLabelPath:str, outputPath:str, fileName:str, 
                             inputImagePath:list, classNameDict:dict) -> None:
        """
        Convert bbox csv format to bbox txt format

        Args:
            inputLabelPath (str) : input Label path
            outputPath     (str) : output path
            fileName       (str) : file name
            inputImagePath (str) : input image path, defaults to None.
            classNameDict  (dict): {classNumber(int): className(str), ....} the class name corresponding to the number. Defaults to None.
        """
        classNameRevers = dict(zip(classNameDict.values(), classNameDict.keys()))  # {str, int}
        with open(os.path.join(inputLabelPath, fileName), 'r') as file:
            fileList = list(csv.reader(file))
            imageName = ''
            for fileItem in fileList:
                labelName = fileItem[-1]
                box = fileItem[1:5]
                if imageName != fileItem[0].split("/")[-1]:
                    imageName = fileItem[0].split("/")[-1]
                    result = [[classNameRevers[labelName], *box]]
                    cls.__writing_bbox_txt(result, imageName, outputPath)
                else:
                    if labelName in classNameDict.values():
                        result.append([classNameRevers[labelName], *box])
                    cls.__writing_bbox_txt(result, imageName, outputPath)
        pass

### not yet
    # @classmethod
    # def coco_to_bbox_txt(cls, fileName:str, inputLabelPath:str, outputPath:str):
    #     data = json.load(open(os.path.join(inputLabelPath, fileName)))
    #     _annotataionKey = 'annotations'
    #     _imageId = 'image_id'
    #     _catId = 'category_id'
    #     _bbox = 'bbox'

    #     for i in range(len(data[_annotataionKey])):
    #         # Get required data
    #         imageInfoIter = data[_annotataionKey][i]
    #         result = [imageInfoIter[_catId], 
    #                 imageInfoIter[_bbox][0],
    #                 imageInfoIter[_bbox][1],
    #                 imageInfoIter[_bbox][2] + imageInfoIter[_bbox][0],
    #                 imageInfoIter[_bbox][3] + imageInfoIter[_bbox][1],
    #                     ]
    #         cls.__writing_bbox_txt(result, imageInfoIter[_imageId], outputPath)
    #     pass



class AnnotationTransfer(AnnotationTransferTools):
    def __init__(self, inputLabelPath:str, outputPath:str, classNameDict:dict=None, 
                inputImagePath:str=None, transToType:str="bbox_txt", **argv) -> None:
        """
        Annotation conversion 

        Args:
            inputLabelPath (str)       : input Label path
            outputPath     (str)       : output path
            classNameDict  (dict, None): {classNumber(str): className(str), ....} the class name corresponding to the number. Defaults to None.
            inputImagePath (str)       : input image path, defaults to None.
            transToType    (str)       : target format to convert. Defaults is "bbox_txt". "bbox_txt", "yolo_txt", "bbox_xml" can be selected
        """
        super().__init__()
        classNameDict = {int(key): value for key, value in classNameDict.items()}
        orgLabelType = self.check_annotation_type(inputLabelPath)
        self.outputPath  = outputPath
        if orgLabelType == transToType:
            print(f' - your annotation type "{orgLabelType}" and want to transfer type "{transToType}" is the same, no need to transfer.')
            self.outputPath = inputLabelPath
        elif orgLabelType not in ["bbox_txt", "yolo_txt", "bbox_xml", "bbox_csv"]:
            raise BaseException(f' - your annotation type "{orgLabelType}" is not in [bbox_xml, yolo_txt, bbox_txt], please confirm what your annotation type')
        elif transToType not in ["bbox_txt", "yolo_txt", "bbox_xml"]:
            raise BaseException(f' - transfer type "{transToType}" is not in [bbox_xml, yolo_txt, bbox_txt], please confirm what type you what to transfer')
        else:
            create_empty_folder(self.outputPath)
            usingFunc = getattr(super(), f'{orgLabelType}_to_{transToType}')
            print(f'your annotation type "{orgLabelType}" convert to "{transToType}"')
            for fileName in get_specific_files_list(inputLabelPath, f'.{orgLabelType.split("_")[1]}'):
                usingFunc(inputLabelPath, self.outputPath, fileName, inputImagePath, classNameDict)
       
        print(f" - Annotation transfer is done !!")
