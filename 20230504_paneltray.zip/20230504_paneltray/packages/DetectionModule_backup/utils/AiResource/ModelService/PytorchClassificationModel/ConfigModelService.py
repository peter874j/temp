# -*- coding: utf-8 -*-

"""
Created on Mon Jun 15 17:00:00 2022
"""

class LossFunctionPara:
    def __init__(self, lossFunction: str) -> None:
        """
        lossFunction: including 'CrossEntropyLoss', 'NLLLoss', 'MultiMarginLoss'
        """
        self.lossFunction = lossFunction

    @classmethod
    def create_from_dict(cls, lossFunctionPara: dict):
        """
        lossFunctionPara: {
            "lossFunction": (str) including 'CrossEntropyLoss', 'NLLLoss', 'MultiMarginLoss'
        }
        """
        return cls(**lossFunctionPara)

class LearningRatePara:
    def __init__(self, learningRate: float) -> None:
        """
        learningRate: learning rate value
        """
        self.learningRate = learningRate

    @classmethod
    def create_from_dict(cls, learningRatePara: dict):
        """
        learningRatePara: {
            "learningRate": (float) learning rate value
        }
        """
        return cls(**learningRatePara)


class OptimizerPara:
    def __init__(self, SGD: dict, Adam: dict, Adadelta: dict, AdamW: dict, NAdam: dict) -> None:
        """
        SGD, Adam, Adadelta, AdamW, (NAdam: torch=1.10.0+)
        SGD: {
            "switch"       : (int) 0: disable, 1: enable
            "momentum"     : (float) 動量, 範圍[0, 1]
            "dampening"    : (float) 動量阻尼, 範圍[0, 1]
            "weightDecay"  : (float) 衰減係數, 範圍[0, 1]
            "nesterov"     : (int) 0: disable, 1: enable 是否啟用Nesterov accelerated gradient, 啟用nesterov時, dampening需為0
        }
        Adam: {
            "switch"       : (int) 0: disable, 1: enable
            "betas"        : (list) [m(float), s(float)] 計算梯度的平均與平方係數, m, s 範圍[0, 1]
            "eps"          : (float) 提高數值穩度性之分母項, 範圍[0, 1]
            "weightDecay"  : (float) 衰減係數, 範圍[0, 1]
            "amsgrad"      : (int) 0: disable, 1: enable 是否啟用AMSGrad演算法
        }
        Adadelta: {
            "switch"       : (int) 0: disable, 1: enable
            "rho"          : (float) 計算平方梯度的平均值係數, 範圍[0, 1]
            "eps"          : (float) 提高數值穩度性之分母項, 範圍[0, 1]
            "weightDecay"  : (float) 衰減係數, 範圍[0, 1]
        }
        AdamW: {
            "switch"       : (int) 0: disable, 1: enable
            "betas"        : (list) [m(float), s(float)] 計算梯度的平均與平方係數, m, s 範圍[0, 1]
            "eps"          : (float) 提高數值穩度性之分母項, 範圍[0, 1]
            "weightDecay"  : (float) 衰減係數, 範圍[0, 1]
            "amsgrad"      : (int) 0: disable, 1: enable 是否啟用AMSGrad演算法
        }
        NAdam: {
            "switch"       : (int) 0: disable, 1: enable
            "betas"        : (list) [m(float), s(float)] 計算梯度的平均與平方係數, m, s 範圍[0, 1]
            "eps"          : (float) 提高數值穩度性之分母項, 範圍[0, 1]
            "weightDecay"  : (float) 衰減係數, 範圍[0, 1]
            "momentumDecay": (float) 動量衰減係數, 範圍[0, 1]
        }
        """
        self.SGD      = SGD
        self.Adam     = Adam
        self.Adadelta = Adadelta
        self.AdamW    = AdamW
        self.NAdam    = NAdam

    @classmethod
    def create_from_dict(cls, optimizerPara: dict):
        """
        Include SGD, Adam, Adadelta, AdamW, (NAdam: torch=1.10.0+) setting
        optimizerPara: {
            "SGD": (dict) {
                "switch"       : (int) 0: disable, 1: enable
                "momentum"     : (float) 動量, 範圍[0, 1]
                "dampening"    : (float) 動量阻尼, 範圍[0, 1]
                "weightDecay"  : (float) 衰減係數, 範圍[0, 1]
                "nesterov"     : (int) 0: disable, 1: enable 是否啟用Nesterov accelerated gradient, 啟用nesterov時, dampening需為0
            }
            "Adam": (dict) {
                "switch"       : (int) 0: disable, 1: enable
                "betas"        : (list) [m(float), s(float)] 計算梯度的平均與平方係數, m, s 範圍[0, 1]
                "eps"          : (float) 提高數值穩度性之分母項, 範圍[0, 1]
                "weightDecay"  : (float) 衰減係數, 範圍[0, 1]
                "amsgrad"      : (int) 0: disable, 1: enable 是否啟用AMSGrad演算法
            }
            "Adadelta": (dict) {
                "switch"       : (int) 0: disable, 1: enable
                "rho"          : (float) 計算平方梯度的平均值係數, 範圍[0, 1]
                "eps"          : (float) 提高數值穩度性之分母項, 範圍[0, 1]
                "weightDecay"  : (float) 衰減係數, 範圍[0, 1]
            }
            "AdamW": (dict) {
                "switch"       : (int) 0: disable, 1: enable
                "betas"        : (list) [m(float), s(float)] 計算梯度的平均與平方係數, m, s 範圍[0, 1]
                "eps"          : (float) 提高數值穩度性之分母項, 範圍[0, 1]
                "weightDecay"  : (float) 衰減係數, 範圍[0, 1]
                "amsgrad"      : (int) 0: disable, 1: enable 是否啟用AMSGrad演算法
            }
            "NAdam": (dict) {
                "switch"       : (int) 0: disable, 1: enable
                "betas"        : (list) [m(float), s(float)] 計算梯度的平均與平方係數, m, s 範圍[0, 1]
                "eps"          : (float) 提高數值穩度性之分母項, 範圍[0, 1]
                "weightDecay"  : (float) 衰減係數, 範圍[0, 1]
                "momentumDecay": (float) 動量衰減係數, 範圍[0, 1]
            }
        }
        """
        return cls(**optimizerPara)


class SchedulerPara:
    def __init__(self, stepLR: dict, cosineAnnealingLR: dict) -> None:
        """
        stepLR: {
            "switch"  : (int) 0: disable, 1: enable,
            "stepSize": (int) 學習率下降間隔數, 範圍[0, 總epochs數)
            "gamma"   : (float) 學習率調整倍率, 範圍[(-2)**127, 2**127, 即 float 所記錄的範圍
        }
        cosineAnnealingLR {
            "switch"  : (int) 0: disable, 1: enable,
            "tMax"    : (int) 學習率降至 etaMin 的間隔數, 範圍[0, 總epochs數]
            "etaMin"  : (float) 學習率可下降到的最小值
        }
        """
        self.stepLR = stepLR
        self.cosineAnnealingLR = cosineAnnealingLR


    @classmethod
    def create_from_dict(cls, schedulerPara: dict):
        """
        schedulerPara: {
            "stepLR": (dict) {
                "switch"  : (int) 0: disable, 1: enable,
                "stepSize": (int) 學習率下降間隔數, 範圍[0, 總epochs數)
                "gamma"   : (float) 學習率調整倍率, 範圍[(-2)**127, 2**127, 即 float 所記錄的範圍
            }
            "cosineAnnealingLR": (dict) {
                "switch"  : (int) 0: disable, 1: enable,
                "tMax"    : (int) 學習率降至 etaMin 的間隔數, 範圍[0, 總epochs數]
                "etaMin"  : (float) 學習率可下降到的最小值
            }
        }
        """
        return cls(**schedulerPara)



   
