# -*- coding: utf-8 -*-
"""
Created on Mon Jun 15 17:00:00 2022
"""

### Select your model ###
class ModelPara:
    def __init__(self, model: dict) -> None:
        """
        model: {
            "structure" : (str) model structure name
            "pretrained": (int) 0: disable, 1: enable
        }
        
        1. The model structure including: CustomModel(ScriptPth), alexnet, vgg16_bn, resnet50, resnext50_32x4d, se_resnet50,
                                          cbam_resnet50, csp_resnet50, se_cbam_resnet50, csp_se_resnet50, csp_cbam_resnet50,
                                          csp_se_cbam_resnet50, csp_resnet18, densenet121, efficientnet_b0, regnet_y_400mf,
                                          shufflenet_v2_x0_5, mnasnet0_5, mobilenet_v3_small,
        2. Please check out each code in ./utils/AiModel package for the detail structure name.
        3. CustomModel(ScriptPth) can used for 'Test', 'Inference', 'Retrain' task.
        """
        self.model = model
    
    @classmethod
    def create_from_dict(cls, selectedModelPara: dict):
        """
        selectedModelPara: {
            "model": (dict) {
                "structure" : (str) model structure name
                "pretrained": (int) 0: disable, 1: enable
            }
        }
        """
        return cls(**selectedModelPara)


### Set up model parameters  ###
class ServicePara:
    def __init__(self, cudaDevice: int, batchSize: int, epochs: int) -> None:
        """
        cudaDevice: GPU device used for running program
        batchSize: Number of data use for training at the same time
        epochs: The iteration number of training
        """
        self.cudaDevice = cudaDevice
        self.batchSize  = batchSize
        self.epochs     = epochs

    @classmethod
    def create_from_dict(cls, clsModelPara: dict):
        """
        clsModelPara: {
            "cudaDevice": (int) GPU device used for running program
            "batchSize" : (int) Number of data use for training at the same time
            "epochs"    : (int) The iteration number of training
        }
        """
        return cls(**clsModelPara)


### Set up path  ###
class PathPara:
    def __init__(self, trainPath: str, validPath: str, testPath: str,
                       inferencePath: str, weightPath: dict) -> None:
        """
        # Data path:
            trainPath: Train data path 
            validPath: Validation data path
            testPath: Test data path
            inferencePath: Inference data path
        
        # Model weight path:
            weightPath: {
                "pretrainedWeight": (str) Model weight for training
                "evaluatedWeight" : (str) Model weight for test and inference
                "customModel"     : (str) Model weight for retrain and fine-tune
            }
        """
        self.trainPath     = trainPath
        self.validPath     = validPath
        self.testPath      = testPath
        self.inferencePath = inferencePath
        self.weightPath    = weightPath

    @classmethod
    def create_from_dict(cls, clsPathPara: dict):
        """
        clsPathPara: {
            # Data path
            "trainPath"    : (str) Train data path 
            "validPath"    : (str) Validation data path
            "testPath"     : (str) Test data path
            "inferencePath": (str) Inference data path
            
            # Model weight path
            "weightPath": (dict) {
                "pretrainedWeight": (str) Model weight for training
                "evaluatedWeight" : (str) Model weight for test and inference
                "customModel"     : (str) Model weight for retrain and fine-tune
            }

        }
        """
        return cls(**clsPathPara)