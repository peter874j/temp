import torch.functional
import torch.optim.lr_scheduler as SchedulerMethod

from .ConfigModelService import SchedulerPara


def cls_select_scheduler(schedulerPara: SchedulerPara, optimizer: torch.functional) -> torch.functional:
    """
    According to configs in ConfigModelService, select scheduler to adjust learning rate of optimizer.
    
    Args:
        schedulerPara: point out the selected scheduler and its correspond setting
        optimizer: the optimizer that wants to adjust
    Return:
        scheduler
    """
    if schedulerPara.stepLR["switch"]:
        method = getattr(SchedulerMethod, 'StepLR')
        scheduler = method(optimizer=optimizer, 
                           step_size=schedulerPara.stepLR["stepSize"],
                           gamma=schedulerPara.stepLR["gamma"]
                           )
        
    elif schedulerPara.cosineAnnealingLR["switch"]:
        method = getattr(SchedulerMethod, 'CosineAnnealingLR')
        scheduler = method(optimizer=optimizer,
                           T_max=schedulerPara.cosineAnnealingLR["tMax"],
                           eta_min=schedulerPara.cosineAnnealingLR["etaMin"],
                           )
    return scheduler
