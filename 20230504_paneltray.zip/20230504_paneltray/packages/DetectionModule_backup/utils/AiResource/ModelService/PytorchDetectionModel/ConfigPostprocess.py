# -*- coding: utf-8 -*-

"""
Created on Thur July 28 10:00:00 2022
"""


class PostprcessPara:
    def __init__(self, nms:dict) -> None:
        """
            nms :(dict)
                "switch"      : (int)   0: disable, 1: enable
                "iouTreshold" : (float) The threshold value of iou is set

        """
        self.nms = nms

    @classmethod
    def create_from_dict(cls, postprceePara:dict):
        return cls(**postprceePara)