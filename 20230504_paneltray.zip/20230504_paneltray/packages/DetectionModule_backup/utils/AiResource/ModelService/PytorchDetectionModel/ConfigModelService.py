# -*- coding: utf-8 -*-

"""
Created on Thur July 28 10:00:00 2022
"""
class LearningRatePara:
    def __init__(self, learningRate:float) -> None:
        """
        learningRate: (float) learning rate value
        """
        self.learningRate = learningRate

    @classmethod
    def create_from_dict(cls, learningRatePara:dict) -> None:
        """
        learningRatePara["learningRate"]: (float) learning rate value
        """
        return cls(learningRatePara["learningRate"])


class OptimizerPara:
    def __init__(self,
        SGD:dict
    ) -> None:
        """
        SGD: (dict) {
            "switch"       : (int) 0: disable, 1: enable
            "momentum"     : (float) 動量, 範圍[0, 1]
            "dampening"    : (float) 動量阻尼, 範圍[0, 1]
            "weightDecay"  : (float) 衰減係數, 範圍[0, 1]
            "nesterov"     : (int) 0: disable, 1: enable 是否啟用Nesterov accelerated gradient, 啟用nesterov時, dampening需為0
        }
        """
        self.SGD      = SGD


    @classmethod
    def create_from_dict(cls, optimizerPara:dict) -> None:
        """
        SGD
        optimizerPara["SGD"]: (dict) {
            "switch"       : (int) 0: disable, 1: enable
            "momentum"     : (float) 動量, 範圍[0, 1]
            "dampening"    : (float) 動量阻尼, 範圍[0, 1]
            "weightDecay"  : (float) 衰減係數, 範圍[0, 1]
            "nesterov"     : (int) 0: disable, 1: enable 是否啟用Nesterov accelerated gradient, 啟用nesterov時, dampening需為0
        }
        """
        return cls(**optimizerPara)


class SchedulerPara:
    def __init__(self,
        multiStepLR:dict,
        ):
        """
            multiStepLR : (dict){
                "switch"        : (int) 0: disable, 1: enable
                "milestones"    : (list[int, int]) List of epoch indices. Must be increasing.
                "gamma"         : (float) 學習率調整倍率, 範圍[(-2)**127, 2**127, 即 float 所記錄的範圍
            }
        """
        self.multiStepLR = multiStepLR

    @classmethod
    def create_from_dict(cls, schedulerPara:dict):
        """
            schedulerPara["multiStepLR"] : (dict){
                "switch"        : (int) 0: disable, 1: enable
                "milestones"    : (list[int, int]) List of epoch indices. Must be increasing.
                "gamma"         : (float) 學習率調整倍率, 範圍[(-2)**127, 2**127, 即 float 所記錄的範圍
            }
        """
        return cls(**schedulerPara)


class ScalerPara:
    def __init__(self, amp:dict) -> None:
        """
            amp : (dict) {
                "switch"  : (int) 0: disable, 1: enable,
            }
        """
        self.amp = amp

    @classmethod
    def create_from_dict(cls, scalerPara:dict):
        """
            scalerPara["amp"] : (dict) {
                "switch"  : (int) 0: disable, 1: enable,
            }
        """
        return cls(**scalerPara)
