import torch
import torchvision.models.detection.mask_rcnn
from torch import nn, tensor
from . import utils
from ....Evaluation.ModuleEvaluation.Det.coco_eval import CocoEvaluator
from ....Evaluation.ModuleEvaluation.Det.coco_utils import get_coco_api_from_dataset
from torch.utils.data import DataLoader

def train_one_epoch(
    model:nn.modules, 
    optimizer:torch.functional, 
    dataLoader:DataLoader, 
    device:torch.device, 
    epoch:int, 
    printFreq:int, 
    scaler:torch.cuda=None
):
    """
    training for one epoch
    Args:
        model (nn.modules): training model
        optimizer (torch.functional): optimizer
        dataLoader (DataLoader): training data loader
        device (torch.device): cuda device 
        epoch (int): Which epoch to 
        printFreq (int): Print freq of training loss 
        scaler (torch.cuda, optional): scaler. Defaults to None.

    """
    model.train()
    metricLogger = utils.MetricLogger(delimiter="  ")
    metricLogger.add_meter("lr", utils.SmoothedValue(window_size=1, fmt="{value:.6f}"))
    header = f"Epoch: [{epoch}]"

    scheduler = None
    if epoch == 0:
        warmup_factor = 1.0 / 1000
        warmup_iters = min(1000, len(dataLoader) - 1)
        scheduler = torch.optim.lr_scheduler.LinearLR(
            optimizer, start_factor=warmup_factor, total_iters=warmup_iters
        )

    for images, targets in metricLogger.log_every(dataLoader, printFreq, header):
        images = list(image.to(device) for image in images)
        targets = [{k: v.to(device) for k, v in t.items() if k != "imageName"} for t in targets]
        with torch.cuda.amp.autocast(enabled=scaler is not None):
            loss_dict = model(images, targets)
            losses = sum(loss for loss in loss_dict.values())

        # reduce losses over all GPUs for logging purposes
        loss_dict_reduced = utils.reduce_dict(loss_dict)
        losses_reduced = sum(loss for loss in loss_dict_reduced.values())
        loss_value = losses_reduced.item()

        # if not math.isfinite(loss_value):
        #     print(f"Loss is {loss_value}, stopping training")
        #     print(loss_dict_reduced)
        #     sys.exit(1)

        optimizer.zero_grad()
        if scaler is not None:
            scaler.scale(losses).backward()  # 先將梯度放大, 防止梯度消失
            scaler.step(optimizer)           # 把梯度的值unscale回來
            scaler.update()                  # 查看是否需要增大scale
        else:
            losses.backward()
            optimizer.step()

        if scheduler is not None:
            scheduler.step()

        metricLogger.update(loss=losses_reduced, **loss_dict_reduced)
        metricLogger.update(lr=optimizer.param_groups[0]["lr"])

    return metricLogger


def _get_iou_types(model:nn.modules)->list:
    """
    check what type iou used

    Args:
        model (nn.modules): model

    Returns:
        iou_types   (list): iou type
    """
    model_without_ddp = model
    if isinstance(model, torch.nn.parallel.DistributedDataParallel):
        model_without_ddp = model.module
    iou_types = ["bbox"]
    if isinstance(model_without_ddp, torchvision.models.detection.MaskRCNN):
        iou_types.append("segm")
    if isinstance(model_without_ddp, torchvision.models.detection.KeypointRCNN):
        iou_types.append("keypoints")
    return iou_types


def evaluate(model:nn.modules, dataLoader:DataLoader, device:torch.device):
    """
    Evaluate model result

    Args:
        model (nn.modules): model
        dataLoader (DataLoader): data loader
        device (torch.device): cuda device 

    Returns:
        cocoEvaluator
    """
    n_threads = torch.get_num_threads()
    # FIXME remove this and make paste_masks_in_image run on the GPU
    torch.set_num_threads(1)
    model.eval()

    coco = get_coco_api_from_dataset(dataLoader.dataset)
    cocoEvaluator = CocoEvaluator(coco, _get_iou_types(model)) # _get_iou_types(model) = ['bbox']
    with torch.no_grad():
        for images, targets in dataLoader:
            images = list(img.to(device) for img in images)

            if torch.cuda.is_available():
                torch.cuda.synchronize()
            outputs = model(images)
            outputs = [{k: v.cpu() for k, v in t.items()} for t in outputs]

            res = {target["image_id"].item(): output for target, output in zip(targets, outputs)}
            cocoEvaluator.update(res)

    # gather the stats from all processes
    cocoEvaluator.synchronize_between_processes() 

    # accumulate predictions from all images
    cocoEvaluator.accumulate()
    cocoEvaluator.summarize()
    torch.set_num_threads(n_threads)
    return cocoEvaluator


def apply_nms(prediction:tensor, threshold:float):
    """
    Using nms for prediction

    Args:
        prediction (tensor): model predict result
        threshold (float): confidence socre threshold

    Returns:
        predictionNms (tensor): after nms predict result
    """

    # torchvision returns the indices of the boxes to keep
    keep = torchvision.ops.nms(prediction['boxes'], prediction['scores'], threshold)
    
    predictionNms = prediction
    predictionNms['boxes'] = predictionNms['boxes'][keep]
    predictionNms['scores'] = predictionNms['scores'][keep]
    predictionNms['labels'] = predictionNms['labels'][keep]
    
    return predictionNms