import cv2
import os

def crop(save_path, yourPath):
    allFileList = os.listdir(yourPath)
        
    for file in allFileList:
        img_list = []
        # 讀取圖檔
        img = cv2.imread(os.path.join(yourPath, file))

        # 裁切區域的 x 與 y 座標（左上角）
        x = 90
        y = 15

        # 裁切區域的長度與寬度
        w = 2271
        h = 1955

        # 裁切圖片
        crop_img = img[y:y+h, x:x+w]
        # cv2.imwrite(os.path.join(save_path, file), crop_img)

        # crop 1
        # 裁切區域的 x 與 y 座標（左上角）
        x = 0
        y = 0

        # 裁切區域的長度與寬度
        w = 1230
        h = 1075
        crop_img_1 = crop_img[y:y+h, x:x+w]
        cv2.imwrite(os.path.join(save_path, file.split('.')[0] + '_1.jpg'), crop_img_1)

        # crop 2
        # 裁切區域的 x 與 y 座標（左上角）
        x = 2271-1230
        y = 0

        # 裁切區域的長度與寬度
        w = 1230
        h = 1075
        crop_img_2 = crop_img[y:y+h, x:x+w]
        cv2.imwrite(os.path.join(save_path, file.split('.')[0] + '_2.jpg'), crop_img_2)

        # crop 3
        # 裁切區域的 x 與 y 座標（左上角）
        x = 0
        y = 1955-1075

        # 裁切區域的長度與寬度
        w = 1230
        h = 1075
        crop_img_3 = crop_img[y:y+h, x:x+w]
        cv2.imwrite(os.path.join(save_path, file.split('.')[0] + '_3.jpg'), crop_img_3)

        # crop 4
        # 裁切區域的 x 與 y 座標（左上角）
        x = 2271-1230
        y = 1955-1075

        # 裁切區域的長度與寬度
        w = 1230
        h = 1075
        crop_img_4 = crop_img[y:y+h, x:x+w]
        cv2.imwrite(os.path.join(save_path, file.split('.')[0] + '_4.jpg'), crop_img_4)


if __name__ == "__main__":

    # 儲存位置
    # save_path = r"online_sampling\test"
    save_path = input("請輸入切割後儲存路徑:")
    # 檔案位置
    # yourPath = r"online_sampling\test"
    yourPath = input("請輸入取樣影像資料夾路徑:")
    
    crop(save_path, yourPath)


    

    