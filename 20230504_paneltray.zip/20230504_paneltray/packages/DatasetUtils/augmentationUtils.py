### label 需依照 xyxy 格式
import cv2
import os
import random
import numpy as np
import torch
import shutil
import math

import sys

sys.path.append("./")
from LabelUtils import yolo2bbox, bbox2yolo


def show_label_on_img(img, labels, name="img"):
    for label in labels:
        _class, x1, y1, x2, y2 = label
        cv2.rectangle(
            img,
            (x1, y1),
            (x2, y2),
            (0, 0, 255),
            1,
            cv2.LINE_AA,
        )
    cv2.imshow(name, img)
    cv2.waitKey(0)
    cv2.destroyAllWindows()


### 儲存擴增後的圖片和標註
def save_img_label(outputImgFolder, outputLabelFolder, newImgName, newimg, newLabels):
    ### 已經做過相同擴增
    if os.path.isfile(os.path.join(outputImgFolder, newImgName + ".jpg")):
        return False

    cv2.imwrite(os.path.join(outputImgFolder, newImgName + ".jpg"), newimg)
    outputFile = open(os.path.join(outputLabelFolder, newImgName + ".txt"), "wt")
    for label in newLabels:
        _class, x1, y1, x2, y2 = label
        outputFile.write(f"{_class} {x1} {y1} {x2} {y2}\n")
    outputFile.close()
    return True


### 水平翻轉
def horizontal_flip(img, labels):
    img = cv2.flip(img, 1)
    newLabels = []
    width, height = img.shape[1], img.shape[0]
    for label in labels:
        _class, x1, y1, x2, y2 = label
        newLabels.append([_class, width - x2, y1, width - x1, y2])
    return img, newLabels


### 垂直翻轉
def vertical_flip(img, labels):
    img = cv2.flip(img, 0)
    newLabels = []
    width, height = img.shape[1], img.shape[0]
    for label in labels:
        _class, x1, y1, x2, y2 = label
        newLabels.append([_class, x1, height - y2, x2, height - y1])
    return img, newLabels


### 垂直水平翻轉
def vertical_horizontal_flip(img, labels):
    newimg, newLabels = horizontal_flip(img, labels)
    newimg, newLabels = vertical_flip(newimg, newLabels)
    return newimg, newLabels


### 隨機旋轉
def rotate(img, labels):
    ### 隨機旋轉角度
    randomDegree = 0
    while randomDegree == 0:
        randomDegree = random.randint(-90, 90)
    ### 隨機尺度變換
    randomScale = random.uniform(0.5, 1)

    # FIXME:
    if True:
        randomDegree, randomScale = randomDegree, 1

    w, h = img.shape[1], img.shape[0]
    # 角度变弧度
    rangle = np.deg2rad(randomDegree)
    # 计算新图像的宽度和高度，分别为最高点和最低点的垂直距离
    nw = (abs(np.sin(rangle) * h) + abs(np.cos(rangle) * w)) * randomScale
    nh = (abs(np.cos(rangle) * h) + abs(np.sin(rangle) * w)) * randomScale
    rot_mat = cv2.getRotationMatrix2D((nw * 0.5, nh * 0.5), randomDegree, randomScale)  # 返回 2x3 矩阵
    # 新中心点与旧中心点之间的位置
    rot_move = np.dot(rot_mat, np.array([(nw - w) * 0.5, (nh - h) * 0.5, 0]))
    # the move only affects the translation, so update the translation
    # part of the transform
    rot_mat[0, 2] += rot_move[0]
    rot_mat[1, 2] += rot_move[1]
    # 仿射变换
    rot_img = cv2.warpAffine(
        img, rot_mat, (int(math.ceil(nw)), int(math.ceil(nh))), flags=cv2.INTER_LANCZOS4
    )  # ceil向上取整

    # ---------------------- 矫正boundingbox ----------------------
    # rot_mat是最终的旋转矩阵
    # 获取原始bbox的四个中点，然后将这四个点转换到旋转后的坐标系下
    rot_bboxes = list()
    for label in labels:
        _class, x_min, y_min, x_max, y_max = label

        point1 = np.dot(rot_mat, np.array([(x_min + x_max) / 2, y_min, 1]))
        point2 = np.dot(rot_mat, np.array([x_max, (y_min + y_max) / 2, 1]))
        point3 = np.dot(rot_mat, np.array([(x_min + x_max) / 2, y_max, 1]))
        point4 = np.dot(rot_mat, np.array([x_min, (y_min + y_max) / 2, 1]))

        # 合并np.array
        concat = np.vstack((point1, point2, point3, point4))  # 在竖直方向上堆叠
        # 改变array类型
        concat = concat.astype(np.int32)
        # 得到旋转后的坐标
        rx, ry, rw, rh = cv2.boundingRect(concat)
        rx_min = rx
        ry_min = ry
        rx_max = rx + rw
        ry_max = ry + rh
        # 加入list中
        rot_bboxes.append([_class, rx_min, ry_min, rx_max, ry_max])

    return rot_img, rot_bboxes, randomDegree, randomScale


### 裁剪
def crop(img, labels):
    w = img.shape[1]
    h = img.shape[0]
    newimg = np.zeros((h, w, 3), np.uint8)

    x_min = w
    x_max = 0
    y_min = h
    y_max = 0

    for label in labels:
        _class, x1, y1, x2, y2 = label
        x_min = min(x_min, x1)
        y_min = min(y_min, y1)
        x_max = max(x_max, x2)
        y_max = max(x_max, y2)

    # 包含所有目标框的最小框到各个边的距离
    d_to_left = x_min
    d_to_right = w - x_max
    d_to_top = y_min
    d_to_bottom = h - y_max

    # 随机扩展这个最小范围
    crop_x_min = int(x_min - random.uniform(0, d_to_left))
    crop_y_min = int(y_min - random.uniform(0, d_to_top))
    crop_x_max = int(x_max + random.uniform(0, d_to_right))
    crop_y_max = int(y_max + random.uniform(0, d_to_bottom))

    # 确保不出界
    crop_x_min = max(0, crop_x_min)
    crop_y_min = max(0, crop_y_min)
    crop_x_max = min(w, crop_x_max)
    crop_y_max = min(h, crop_y_max)

    crop_img = img[crop_y_min:crop_y_max, crop_x_min:crop_x_max]

    # ------------------ 裁剪bounding boxes ------------------
    crop_bboxes = list()
    for label in labels:
        _class, x1, y1, x2, y2 = label
        crop_bboxes.append([_class, x1 - crop_x_min, y1 - crop_y_min, x2 - crop_x_min, y2 - crop_y_min])

    newimg[: crop_img.shape[0], : crop_img.shape[1]] = crop_img

    return newimg, crop_bboxes


### 平移
def shift(img, labels):
    w = img.shape[1]
    h = img.shape[0]

    x_min = w
    x_max = 0
    y_min = h
    y_max = 0
    for label in labels:
        _class, x1, y1, x2, y2 = label
        x_min = min(x_min, x1)
        y_min = min(y_min, y1)
        x_max = max(x_max, x2)
        y_max = max(x_max, y2)

    # 包含所有目标框的最小框到各个边的距离，即每个方向的最大移动距离
    d_to_left = x_min
    d_to_right = w - x_max
    d_to_top = y_min
    d_to_bottom = h - y_max

    # 在矩阵第一行中表示的是[1,0,x],其中x表示图像将向左或向右移动的距离，如果x是正值，则表示向右移动，如果是负值的话，则表示向左移动。
    # 在矩阵第二行表示的是[0,1,y],其中y表示图像将向上或向下移动的距离，如果y是正值的话，则向下移动，如果是负值的话，则向上移动。
    x = int(random.uniform(-(d_to_left / 3), d_to_right / 3))
    y = int(random.uniform(-(d_to_top / 3), d_to_bottom / 3))
    M = np.float32([[1, 0, x], [0, 1, y]])

    # 仿射变换
    shift_img = cv2.warpAffine(img, M, (img.shape[1], img.shape[0]))  # 第一个参数表示我们希望进行变换的图片，第二个参数是我们的平移矩阵，第三个希望展示的结果图片的大小

    # ------------------ 平移boundingbox ------------------
    shift_bboxes = list()
    for label in labels:
        _class, x1, y1, x2, y2 = label
        shift_bboxes.append([_class, x1 + x, y1 + y, x2 + x, y2 + y])

    return shift_img, shift_bboxes


### 調整對比度和亮度
def contract_brightness(img, contrast, brightness):
    newimg = img * (contrast / 127 + 1) - contrast + brightness  # 轉換公式
    newimg = np.clip(newimg, 0, 255)
    newimg = np.uint8(newimg)
    return newimg


### 馬賽克前裁瑕疵小圖
def crop_defect(cropTempFolder, img, labels, cropSize=(100, 100)):
    os.makedirs(cropTempFolder, exist_ok=True)
    ### bbox距離太近不擴增
    delIdxList = []
    for i, label in enumerate(labels):
        _class, x1, y1, x2, y2 = label
        centerX1, centerY1 = int((x1 + x2) / 2), int((y1 + y2) / 2)
        for j in range(i + 1, len(labels)):
            otherLabel = labels[j]
            _class, x1, y1, x2, y2 = otherLabel
            centerX2, centerY2 = int((x1 + x2) / 2), int((y1 + y2) / 2)
            ### bbox距離太近
            if abs(centerX1 - centerX2) < cropSize[0] or abs(centerY1 - centerY2) < cropSize[1]:
                if i not in delIdxList:
                    delIdxList.append(i)
                if j not in delIdxList:
                    delIdxList.append(j)
    indicateLabels = []
    for i in range(len(labels)):
        if i not in delIdxList:
            indicateLabels.append(labels[i])

    for label in indicateLabels:
        _class, x1, y1, x2, y2 = label
        centerX, centerY = int((x1 + x2) / 2), int((y1 + y2) / 2)
        defectW, defectH = x2 - x1, y2 - y1
        ### 瑕疵尺寸過大
        if defectW > cropSize[0] or defectH > cropSize[1]:
            continue
        ### 裁切小圖
        defectImg = img[
            centerY - int(cropSize[1] / 2) : centerY + int(cropSize[0] / 2),
            centerX - int(cropSize[0] / 2) : centerX + int(cropSize[1] / 2),
        ]
        if defectImg.shape[0] == cropSize[0] and defectImg.shape[1] == cropSize[1]:
            defectImgName = "_" + str(int(len(os.listdir(cropTempFolder)) / 2))
            x1 = x1 - (centerX - int(cropSize[0] / 2))
            y1 = y1 - (centerY - int(cropSize[1] / 2))
            x2 = x1 + defectW
            y2 = y1 + defectH
            defectLabels = [[_class, x1, y1, x2, y2]]
            ret = save_img_label(cropTempFolder, cropTempFolder, f"{defectImgName}", defectImg, defectLabels)
            # show_label_on_img(defectImg, defectLabels, name=defectImgName)


def mosaic(outputImgFolder, outputLabelFolder, outputImgSize, augNum, cropTempFolder, cropSize, save=True):
    ### 讀取瑕疵小圖
    cropImgNameList = []
    for fileName in os.listdir(cropTempFolder):
        if fileName.endswith(".jpg"):
            cropImgName = fileName
            cropImgNameList.append(cropImgName)

    ### 計算行列各放幾張小圖
    cropImg = cv2.imread(os.path.join(cropTempFolder, cropImgNameList[0]))
    cropSize = cropImg.shape[0:2]
    col, row = outputImgSize[0] // cropSize[0], outputImgSize[1] // cropSize[1]

    ### 合併小圖
    idx, imgCount = 0, 0
    while imgCount < augNum:
        newimg = np.zeros((outputImgSize[1], outputImgSize[0], 3), np.uint8)
        newLabels = []
        for r in range(row):
            for c in range(col):
                ### 隨機選擇小圖
                cropImgName = random.choice(cropImgNameList)
                ### 讀取小圖資訊
                cropImg = cv2.imread(os.path.join(cropTempFolder, cropImgName))
                cropLabelName = cropImgName[:-4] + ".txt"
                cropLabelFile = open(os.path.join(cropTempFolder, cropLabelName), "r")
                for line in cropLabelFile:
                    _class, x1, y1, x2, y2 = line.split(" ")
                    cropLabel = [[_class, int(x1), int(y1), int(x2), int(y2[:-1])]]
                cropLabelFile.close()

                ### 隨機翻轉小圖
                p = 0.5
                if torch.rand(1).item() < p:
                    randomFlip = random.randint(0, 2)
                    if randomFlip == 0:
                        cropImg, cropLabel = horizontal_flip(cropImg, cropLabel)
                    elif randomFlip == 1:
                        cropImg, cropLabel = vertical_flip(cropImg, cropLabel)
                    elif randomFlip == 2:
                        cropImg, cropLabel = vertical_horizontal_flip(cropImg, cropLabel)

                ### 拼入大圖
                newimg[cropSize[0] * r : cropSize[0] * (r + 1), cropSize[1] * c : cropSize[1] * (c + 1)] = cropImg
                _class, x1, y1, x2, y2 = cropLabel[0]
                x1, y1, x2, y2 = (
                    x1 + cropSize[1] * c,
                    y1 + cropSize[0] * r,
                    x2 + cropSize[1] * c,
                    y2 + cropSize[0] * r,
                )
                newLabels.append([_class, x1, y1, x2, y2])

                idx += 1

        imgCount += 1
        newImgName = "mosaic" + str(cropSize[0]) + "_" + str(imgCount)
        if save:
            ret = save_img_label(outputImgFolder, outputLabelFolder, newImgName, newimg, newLabels)
        else:
            show_label_on_img(newimg, newLabels, name=newImgName)

    ### 完成後刪除暫存資料夾
    shutil.rmtree(cropTempFolder)


def aug(augmentCount, labelName, imgFolder, labelFolder, outputImgFolder, outputLabelFolder, func, save):
    imgName = labelName[:-4] + ".jpg"
    img = cv2.imread(os.path.join(imgFolder, imgName))
    ### 讀取標註
    labels = []
    labelFile = open(os.path.join(labelFolder, labelName), "r")
    withBroken = False
    for line in labelFile:
        _class, x1, y1, x2, y2 = line.split(" ")
        labels.append([_class, int(x1), int(y1), int(x2), int(y2)])
        # if _class == "1":  # Broken
        #     withBroken = True
        if _class == "3":  # Residue
            withBroken = True
    # if save:
    #     save_img_label(outputImgFolder, outputLabelFolder, imgName[:-4], img, labels)
    # else:
    #     show_label_on_img(img, labels, name=imgName)

    ret = False
    ### 隨機選擇一個要用的擴增方式
    funcList = []
    for funcName, funcSwitch in func.items():
        if funcSwitch:
            funcList.append(funcName)
    funcChoice = random.choice(funcList)
    funcTemp = dict()
    for funcName, funcSwitch in func.items():
        if funcName == funcChoice and withBroken:  # 只針對包含破損的圖擴增:
            funcTemp[funcName] = True
        else:
            funcTemp[funcName] = False

    ### 水平翻轉
    if funcTemp["hFlip"]:
        newImgName = imgName[:-4] + "_hFlip"
        newimg, newLabels = horizontal_flip(img, labels)
        if save:
            ret = save_img_label(outputImgFolder, outputLabelFolder, newImgName, newimg, newLabels)
        else:
            show_label_on_img(newimg, newLabels, name=newImgName)

        if ret:
            augmentCount += 1

    ### 垂直翻轉
    if funcTemp["vFlip"]:
        newImgName = imgName[:-4] + "_vFlip"
        newimg, newLabels = vertical_flip(img, labels)
        if save:
            ret = save_img_label(outputImgFolder, outputLabelFolder, newImgName, newimg, newLabels)
        else:
            show_label_on_img(newimg, newLabels, name=newImgName)

        if ret:
            augmentCount += 1

    ### 水平垂直翻轉
    if funcTemp["vhFlip"]:
        newImgName = imgName[:-4] + "_vhFlip"
        newimg, newLabels = vertical_horizontal_flip(img, labels)
        if save:
            ret = save_img_label(outputImgFolder, outputLabelFolder, newImgName, newimg, newLabels)
        else:
            show_label_on_img(newimg, newLabels, name=newImgName)

        if ret:
            augmentCount += 1

    ### 旋轉
    if funcTemp["rotate"]:
        newimg, newLabels, degree, Scale = rotate(img, labels)
        newImgName = imgName[:-4] + f"_rotate{degree} {round(Scale, 1)}"
        if save:
            ret = save_img_label(outputImgFolder, outputLabelFolder, newImgName, newimg, newLabels)
        else:
            show_label_on_img(newimg, newLabels, name=newImgName)

        if ret:
            augmentCount += 1

    ### 平移
    if funcTemp["shift"]:
        newimg, newLabels = shift(img, labels)
        newImgName = imgName[:-4] + f"_shift"
        if save:
            ret = save_img_label(outputImgFolder, outputLabelFolder, newImgName, newimg, newLabels)
        else:
            show_label_on_img(newimg, newLabels, name=newImgName)

        if ret:
            augmentCount += 1

    ###
    if funcTemp["crop"]:
        newimg, newLabels = crop(img, labels)
        newImgName = imgName[:-4] + f"_crop"
        if save:
            ret = save_img_label(outputImgFolder, outputLabelFolder, newImgName, newimg, newLabels)
        else:
            show_label_on_img(newimg, newLabels, name=newImgName)

        if ret:
            augmentCount += 1

    ### 亮度調整
    if funcTemp["brightness"]:
        contrast = 0
        brightList = [20, -20]
        brightness = random.choice(brightList)
        newLabels = labels
        newimg = contract_brightness(img, contrast, brightness)
        newImgName = imgName[:-4] + f"_contract{int(contrast)}_bright{int(brightness)}"
        if save:
            ret = save_img_label(outputImgFolder, outputLabelFolder, newImgName, newimg, newLabels)
        else:
            show_label_on_img(newimg, newLabels, name=newImgName)

        if ret:
            augmentCount += 1

    return augmentCount


def main(augNum, imgFolder, labelFolder, outputImgFolder, outputLabelFolder, func, save=True, yoloFormat=False):
    os.makedirs(outputImgFolder, exist_ok=True)
    os.makedirs(outputLabelFolder, exist_ok=True)

    ### yolo 格式轉換成 bbox
    if yoloFormat:
        orgLabelFolder = labelFolder
        orgOutputLabelFolder = outputLabelFolder
        labelFolder = "_tmp_annotation_xyxy"
        outputLabelFolder = "_tmp_aug_annotation_xyxy"
        os.makedirs(labelFolder)
        os.makedirs(outputLabelFolder)
        yolo2bbox(imgFolder, inputFolder=orgLabelFolder, outputFolder=labelFolder)
        print("Done yolo format to bbox format.")

    augmentCount = 0
    allLabelList = os.listdir(labelFolder)

    while augmentCount < augNum:
        labelName = random.choice(allLabelList)
        if labelName.split(".")[0] == "classes" or not labelName.endswith(".txt"):
            continue
        augmentCount = aug(
            augmentCount, labelName, imgFolder, labelFolder, outputImgFolder, outputLabelFolder, func, save
        )

    ### 馬賽克擴增前裁切小圖
    for labelName in allLabelList:
        if labelName.split(".")[0] == "classes" or not labelName.endswith(".txt"):
            continue

        if func["mosaic"]:
            imgName = labelName[:-4] + ".jpg"
            img = cv2.imread(os.path.join(imgFolder, imgName))
            ### 讀取標註
            labels = []
            labelFile = open(os.path.join(labelFolder, labelName), "r")
            for line in labelFile:
                _class, x1, y1, x2, y2 = line.split(" ")
                labels.append([_class, int(x1), int(y1), int(x2), int(y2)])

            cropTempFolder = "./_crop_defect_temp/"
            cropSize = (100, 100)
            crop_defect(cropTempFolder, img, labels, cropSize=cropSize)

    if func["mosaic"]:
        mosaicNum = 1000
        outputImgSize = (1230, 1075)
        mosaic(outputImgFolder, outputLabelFolder, outputImgSize, mosaicNum, cropTempFolder, cropSize, save)
        augmentCount += mosaicNum

    if yoloFormat:
        bbox2yolo(outputImgFolder, inputFolder=outputLabelFolder, outputFolder=orgOutputLabelFolder)
        ### 完成後刪除暫存資料夾
        shutil.rmtree(outputLabelFolder)
        print("Done bbox format to yolo format.")

    print(f"共生成{augmentCount}張圖")


if __name__ == "__main__":
    # imgPath = r"D:\UserShare\GitLab\kinsus-panel-tray-defect-detection\Datasets\Experiment Data\2cdpyt0230109_yolo\original\Image\2022_12_11_14_47_20_5543_1.jpg"
    # random_equalize(imgPath)
    # random_autocontrast(imgPath)
    main(
        augNum=400,
        imgFolder=r"D:\UserShare\GitLab\kinsus-panel-tray-defect-detection\Datasets\Experiment Data\20230317\20230321\OK\dataset\Train_mask\Image",
        labelFolder=r"D:\UserShare\GitLab\kinsus-panel-tray-defect-detection\Datasets\Experiment Data\20230317\20230321\OK\dataset\Train_mask\Annotation",
        outputImgFolder=r"D:\UserShare\GitLab\kinsus-panel-tray-defect-detection\Datasets\Experiment Data\20230317\20230321\OK\dataset\Train_mask_aug\Image",
        outputLabelFolder=r"D:\UserShare\GitLab\kinsus-panel-tray-defect-detection\Datasets\Experiment Data\20230317\20230321\OK\dataset\Train_mask_aug\Annotation",
        func={
            "hFlip": True,
            "vFlip": True,
            "vhFlip": True,
            "rotate": False,
            "brightness": False,
            "mosaic": False,
            "shift": False,
            "crop": False,
        },
        save=True,
        yoloFormat=False,
    )

    # imgFolder = r"D:\UserShare\GitLab\kinsus-panel-tray-defect-detection\Datasets\Experiment Data\20230201\dataset\balance\Train_random_aug\Image"

    # labelFolder = r"D:\UserShare\GitLab\kinsus-panel-tray-defect-detection\Datasets\Experiment Data\20230201\dataset\balance\Train_random_aug\Annotation"

    # outputImgFolder = r"D:\UserShare\GitLab\kinsus-panel-tray-defect-detection\Datasets\Experiment Data\20230201\dataset\balance\Train_random_aug_scale1.5\Image"

    # outputLabelFolder = r"D:\UserShare\GitLab\kinsus-panel-tray-defect-detection\Datasets\Experiment Data\20230201\dataset\balance\Train_random_aug_scale1.5\Annotation"

    # save = True

    # os.makedirs(outputImgFolder, exist_ok=True)
    # os.makedirs(outputLabelFolder, exist_ok=True)
    # allLabelList = os.listdir(labelFolder)
    # for labelName in allLabelList:
    #     imgName = labelName[:-4] + ".jpg"
    #     img = cv2.imread(os.path.join(imgFolder, imgName))
    #     ### 讀取標註
    #     labels = []
    #     labelFile = open(os.path.join(labelFolder, labelName), "r")
    #     for line in labelFile:
    #         _class, x1, y1, x2, y2 = line.split(" ")
    #         labels.append([_class, int(x1), int(y1), int(x2), int(y2)])

    #     newimg, newLabels, degree, Scale = rotate(img, labels)
    #     newImgName = imgName[:-4] + f"_rotate{degree} {round(Scale, 1)}"
    #     if save:
    #         ret = save_img_label(outputImgFolder, outputLabelFolder, newImgName, newimg, newLabels)
    #     else:
    #         show_label_on_img(newimg, newLabels, name=newImgName)
