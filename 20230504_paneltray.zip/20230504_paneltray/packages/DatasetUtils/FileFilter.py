import os
import shutil


def find_and_copy_img():
    imgPath = r"D:\UserShare\GitLab\kinsus-panel-tray-defect-detection\Datasets\Experiment Data\20230317\20230321\OK\original\Image"
    outputImgPath = r"D:\UserShare\GitLab\kinsus-panel-tray-defect-detection\Datasets\Experiment Data\20230317\20230321\OK\dataset\Train\Image"

    labelFolderPath = r"D:\UserShare\GitLab\kinsus-panel-tray-defect-detection\Datasets\Experiment Data\20230317\20230321\OK\dataset\Train\Annotation_xywh"

    allFileList = os.listdir(labelFolderPath)

    for file in allFileList:
        print(file.split(".")[0])
        if file.split(".")[0] != "classes":
            try:
                shutil.copyfile(
                    os.path.join(imgPath, file.split(".")[0]) + ".jpg",
                    os.path.join(outputImgPath, file.split(".")[0]) + ".jpg",
                )
            except Exception as e:
                try:
                    shutil.copyfile(
                        os.path.join(imgPath, file.split(".")[0]) + ".png",
                        os.path.join(outputImgPath, file.split(".")[0]) + ".png",
                    )
                except Exception as e:
                    try:
                        shutil.copyfile(
                            os.path.join(imgPath, file.split(".")[0]) + ".bmp",
                            os.path.join(outputImgPath, file.split(".")[0]) + ".bmp",
                        )
                    except Exception as e:
                        print(e)


def find_and_copy_txt():
    srcLabel = r"D:\UserShare\GitLab\kinsus-panel-tray-defect-detection\Datasets\Experiment Data\20230317\20230321\OK\original\Annotation"
    outputLabel = r"D:\UserShare\GitLab\kinsus-panel-tray-defect-detection\Datasets\Experiment Data\20230317\20230321\OK\dataset\Train\Annotation_xywh"

    imgPath = (
        r"D:\UserShare\GitLab\kinsus-panel-tray-defect-detection\Datasets\Experiment Data\20230310\dataset\Train\Image"
    )

    allFileList = os.listdir(imgPath)

    for file in allFileList:
        try:
            shutil.copyfile(
                os.path.join(srcLabel, file.split(".")[0]) + ".txt",
                os.path.join(outputLabel, file.split(".")[0]) + ".txt",
            )
        except Exception as e:
            print(e)


if __name__ == "__main__":
    pass
    find_and_copy_img()
    # find_and_copy_txt()
