import os, shutil, random
from tqdm import tqdm

### 2023/02/02 code by Blackey
def main():
    # 定義資料集名稱
    sets = ["Valid", "Test", "Train"]
    # 驗證集佔整體資料集比例
    valid_percent = 0.1
    # 測試集佔整體資料集比例
    test_percent = 0.1
    # 訓練集佔整體資料集比例
    train_percent = 0.8
    # 原始資料集所在的路徑
    original_dataset_dir = r"D:\UserShare\GitLab\kinsus-panel-tray-defect-detection\Datasets\Experiment Data\20230308\dataset\tmp2TrainValNewTest"
    # 用來儲存新資料集的位置
    base_dir = r"D:\UserShare\GitLab\kinsus-panel-tray-defect-detection\Datasets\Experiment Data\20230308\dataset"

    test_final_percent = valid_percent / (valid_percent + train_percent)
    valid_final_percent = valid_percent
    train_final_percent = 1
    dataset_percent = [valid_final_percent, test_final_percent, train_final_percent]
    imgFolderPathLsit = [root for root, dirs, files in os.walk(original_dataset_dir)]
    folderNameLsit = [saveImgFolderPath[len(original_dataset_dir) + 1 :] for saveImgFolderPath in imgFolderPathLsit]

    for index, original_dataset_dir in enumerate(imgFolderPathLsit):
        # 分拆成訓練、驗證與測試資料夾
        switch = True
        for j in sets:
            set_path = os.path.join(base_dir, j)
            os.makedirs(set_path, exist_ok=True)
            # class_path = os.path.join(set_path, folderNameLsit[index])
            # os.makedirs(class_path, exist_ok=True)
            outputImagePath = os.path.join(set_path, "Image")
            outputlabelPath = os.path.join(set_path, "Annotation")
            os.makedirs(outputImagePath, exist_ok=True)
            os.makedirs(outputlabelPath, exist_ok=True)
            # 查詢單一種類樣本數量
            if switch:
                ### 將資料夾內的圖片路徑輸入到陣列內
                sample = img_folder_to_path_list(original_dataset_dir)
                switch = False
            if sample != []:
                if j == "test" and valid_percent == test_percent:
                    sample_number = sample_number
                else:
                    sample_number = round(len(sample) * dataset_percent[sets.index(j)])
                if sample_number == 0:
                    sample_number = 1
                # 從資料集隨機抽樣
                filePaths = random.sample(sample, sample_number)
                sample = set(sample) - set(filePaths)
                sample = list(sample)
                # 將圖片複製到指定之資料夾
                with tqdm(filePaths) as pbar:
                    for filePath in filePaths:
                        # 讀取文件名稱
                        fname = os.path.basename(filePath)
                        src = os.path.join(original_dataset_dir, fname)
                        dst = os.path.join(outputImagePath, fname)
                        # dst = os.path.join(class_path, fname)
                        shutil.copyfile(src, dst)
                        root, extension = os.path.splitext(fname)
                        fname = fname.replace(extension, ".txt")
                        src = os.path.join(original_dataset_dir, fname)
                        dst = os.path.join(outputlabelPath, fname)
                        # dst = os.path.join(class_path, fname)
                        shutil.copyfile(src, dst)
                        pbar.set_description(str(j) + "-" + str(folderNameLsit[index]))
                        pbar.update(1)


def img_folder_to_path_list(original_dataset_dir):
    """
    將所有待檢測之圖片路徑存成陣列

    Args:
        original_dataset_dir: 待檢測資料夾路徑

    Return:
        imgPathList: 待檢測圖片路徑之陣列
    """
    imgPathList = []
    img_names = os.listdir(original_dataset_dir)
    for img_name in img_names:
        if img_name.lower().endswith(
            (".bmp", ".dib", ".png", ".jpg", ".jpeg", ".pbm", ".pgm", ".ppm", ".tif", ".tiff")
        ):
            image_path = os.path.join(original_dataset_dir, img_name)
            imgPathList.append(image_path)
    return imgPathList


if __name__ == "__main__":
    main()


# ### 根據分好的資料集生成yolo訓練用的txt
# def create_txt_by_exist_dataset(existDatasetPath, dataset, saveBasePath):
#     trainFolder = os.path.join(existDatasetPath, dataset['Train'], 'Annotation')
#     valFolder = os.path.join(existDatasetPath, dataset['Valid'], 'Annotation')
#     testFolder = os.path.join(existDatasetPath, dataset['Test'], 'Annotation')
#     trainList = [ fileName[:-4] for fileName  in os.listdir(trainFolder)]
#     valList = [ fileName[:-4] for fileName  in os.listdir(valFolder)]
#     testList = [ fileName[:-4] for fileName  in os.listdir(testFolder)]
#     trainValList = trainList+valList

#     ftrain      = open(os.path.join(saveBasePath,'train.txt'), 'w')
#     fval        = open(os.path.join(saveBasePath,'val.txt'), 'w')
#     ftest       = open(os.path.join(saveBasePath,'test.txt'), 'w')
#     ftrainval   = open(os.path.join(saveBasePath,'trainval.txt'), 'w')

#     for name in trainList:
#         ftrain.write(name + '\n')
#     for name in valList:
#         fval.write(name + '\n')
#     for name in testList:
#         ftest.write(name + '\n')
#     for name in trainValList:
#         ftrainval.write(name + '\n')

#     ftrainval.close()
#     ftrain.close()
#     fval.close()
#     ftest.close()
#     print("Generate txt in ImageSets done.")

# ### 計算各類別瑕疵點數
# def count_label(labelFolder):
#     labelCountDict = dict() # 計算瑕疵點數

#     allFileList = os.listdir(labelFolder)
#     for fileName in allFileList:
#         if fileName == "classes.txt":
#             continue
#         f = open(os.path.join(labelFolder, fileName))
#         for line in f.readlines():
#             _class, x, y, w, h = line.split(" ")
#             if _class in labelCountDict.keys():
#                 labelCountDict[_class] += 1
#             else:
#                 labelCountDict[_class] = 1

#     for key, value in labelCountDict.items():
#         print(f'class {key}: {value}點')

#     return labelCountDict

# ### 依比例切分資料集
# def data_split(originalFolderPath, splitRate={'Train':0.9, 'Valid':0.1, 'Test':0.1}):
#     imageFolder = os.path.join(originalFolderPath, 'Image')
#     labelFolder = os.path.join(originalFolderPath, 'Annotation')
#     labelCountDict = count_label(labelFolder)

#     ### 要切分至資料集的各類別瑕疵點數
#     trainLabelNum, validLabelNum, testLabelNum = dict(), dict(), dict()
#     for key in labelCountDict.keys():
#         testLabelNum[key] = labelCountDict[key]*int(splitRate['Test'])
#         validLabelNum[key] = labelCountDict[key]*int(splitRate['Valid'])
#         trainLabelNum[key] =

# if __name__ == "__main__":
# ### dataset: 訓練, 驗證, 測試的資寮夾名稱
# create_txt_by_exist_dataset(existDatasetPath= r'D:\UserShare\GitLab\kinsus-panel-tray-defect-detection\Datasets\Experiment Data\20230116\dataset', dataset= {
#     'Train': 'Train',
#     'Valid': 'Valid',
#     'Test': 'Test'
# }, saveBasePath= r'D:\UserShare\GitLab\kinsus-panel-tray-defect-detection\Datasets\Experiment Data\20230120_yolo\ImageSets\Main')

# data_split(
#     originalFolderPath=r"D:\UserShare\GitLab\kinsus-panel-tray-defect-detection\Datasets\Experiment Data\20230116\original"
# )
