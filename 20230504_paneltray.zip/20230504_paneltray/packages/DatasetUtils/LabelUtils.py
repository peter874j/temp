import os
import shutil
import math
import cv2


def count_class(labelFilePath):
    """計算各類別數量"""
    class0 = 0
    class1 = 0
    class2 = 0
    class3 = 0
    picClass0 = 0
    picClass1 = 0
    picClass2 = 0
    picClass3 = 0

    allFileList = os.listdir(labelFilePath)

    for file in allFileList:
        flagClass0 = True
        flagClass1 = True
        flagClass2 = True
        flagClass3 = True
        if file.split(".")[0] != "classes":
            f = open(os.path.join(labelFilePath, file))
            for line in f.readlines():
                #                print(line.split(" ")[0])
                # x1 = line.split(" ")[1]
                # y1 = line.split(" ")[2]
                # x2 = line.split(" ")[3]
                # y2 = line.split(" ")[4][:-1]
                # print(x1, x2, y1, y2)
                # if x1 == x2 or y1 == y2:
                #     print(file)
                # print(line)
                if line.split(" ")[0] == "0":
                    class0 += 1
                    if flagClass0:
                        picClass0 += 1
                        flagClass0 = False
                elif line.split(" ")[0] == "1":
                    class1 += 1
                    if flagClass1:
                        picClass1 += 1
                        flagClass1 = False
                elif line.split(" ")[0] == "2":
                    class2 += 1
                    if flagClass2:
                        picClass2 += 1
                        flagClass2 = False
                elif line.split(" ")[0] == "3":
                    class3 += 1
                    if flagClass3:
                        picClass3 += 1
                        flagClass3 = False
            f.close()
    print(f"class 0: {class0}個, {picClass0}張圖")
    print(f"class 1: {class1}個, {picClass1}張圖")
    print(f"class 2: {class2}個, {picClass2}張圖")
    print(f"class 3: {class3}個, {picClass3}張圖")


def count_class_move():
    yourPath = r"D:\PanelTray\label/"
    yourPath_move = r"D:\PanelTray\cut_img\label\move/"

    allFileList = os.listdir(yourPath)

    for file in allFileList:
        if file.split(".")[0] != "classes":
            f = open(os.path.join(yourPath, file))
            class_list = f.readlines()
            print(class_list)
            if len(class_list) < 2:
                for line in class_list:
                    #                    if line != "":
                    print(line)
                    shutil.copyfile(
                        os.path.join(yourPath, file), os.path.join(yourPath_move + line.split(" ")[0] + "/", file)
                    )
            else:
                shutil.copyfile(os.path.join(yourPath, file), os.path.join(yourPath_move + "m/", file))

            f.close


def combin_class():
    """改label"""

    src = r"D:\UserShare\GitLab\kinsus-panel-tray-defect-detection\Datasets\Experiment Data\20230316\待標註\Annotation"
    target = (
        r"D:\UserShare\GitLab\kinsus-panel-tray-defect-detection\Datasets\Experiment Data\20230316\待標註\Annotation_new"
    )

    allFileList = os.listdir(src)

    for file in allFileList:
        if file.split(".")[0] != "classes":
            f = open(os.path.join(target, file), "wt")
            f_o = open(os.path.join(src, file), "rt")
            for line in f_o:
                #                if line.split(' ')[0] == '1':
                #                    print(line.split(' ')[0].replace('1', '0'), line.split(' ')[1], line.split(' ')[2], line.split(' ')[3], line.split(' ')[4])
                #                if line.split(" ")[0] == "1":
                numClass = line.split(" ")[0]
                if numClass == "0":
                    newNumClass = "1"
                elif numClass == "1":
                    newNumClass = "2"
                elif numClass == "2":
                    newNumClass = "0"
                f.write(line.split(" ")[0].replace(numClass, newNumClass) + " ")
                f.write(line.split(" ")[1] + " ")
                f.write(line.split(" ")[2] + " ")
                f.write(line.split(" ")[3] + " ")
                f.write(line.split(" ")[4])

            f.close()
            f_o.close()


def image2folder_by_label(imgFolderPath, outputFolderPath, labelFolderPath):
    """根據類別將圖片移到對應的資料夾"""
    imgList = os.listdir(imgFolderPath)
    for imgName in imgList:
        labelName = imgName[:-4] + ".txt"
        withinClass = {
            "0": False,
            "1": False,
            "2": False,
        }
        if os.path.exists(os.path.join(labelFolderPath, labelName)):
            file = open(os.path.join(labelFolderPath, labelName), "r")
            for line in file:
                _class = line.split(" ")[0]
                withinClass[str(_class)] = True

            ### 計算有幾種類別包含在內
            classCount = 0
            for value in withinClass.values():
                if value:
                    classCount += 1

            ### 沒有標註
            if classCount == 0:
                className = "8_ok"
            ### 只有1類標註
            elif classCount == 1:
                if withinClass["0"]:
                    className = "1_broken"
                elif withinClass["1"]:
                    className = "2_scratch"
                else:
                    className = "3_other"
            ### 只有2類標註
            elif classCount == 2:
                if withinClass["0"] and withinClass["1"]:
                    className = "4_broken_scratch"
                elif withinClass["0"] and withinClass["2"]:
                    className = "5_broken_other"
                elif withinClass["1"] and withinClass["2"]:
                    className = "6_scratch_other"
            ### 3類都有標註
            elif classCount == 3:
                className = "7_broken_scratch_other"
        else:
            className = "8_ok"

        ###　建立資料夾
        if not os.path.isdir(os.path.join(outputFolderPath, className)):
            os.makedirs(os.path.join(outputFolderPath, className))
        ### 複製圖片
        shutil.copyfile(os.path.join(imgFolderPath, imgName), os.path.join(outputFolderPath, className, imgName))
        ### 複製標註檔
        shutil.copyfile(os.path.join(labelFolderPath, labelName), os.path.join(outputFolderPath, className, labelName))


### 尋找圖片並複製到對應資料夾
def move_img2folder(imgFolderPath, outputFolderPath, imgName, className):
    ###　建立資料夾
    if not os.path.isdir(os.path.join(outputFolderPath, className)):
        os.makedirs(os.path.join(outputFolderPath, className))
    ### 複製圖片
    shutil.copyfile(os.path.join(imgFolderPath, imgName), os.path.join(outputFolderPath, className, imgName))


def xywh2xyxy(x, y, w, h, imgSize):
    yoloBox = [x, y, w, h]
    imageW, imageH = imgSize
    xmin = math.ceil((float(yoloBox[0]) - float(yoloBox[2]) / 2) * imageW)
    ymin = math.ceil((float(yoloBox[1]) - float(yoloBox[3]) / 2) * imageH)
    xmax = math.ceil((float(yoloBox[0]) + float(yoloBox[2]) / 2) * imageW)
    ymax = math.ceil((float(yoloBox[1]) + float(yoloBox[3]) / 2) * imageH)
    return xmin, ymin, xmax, ymax


def xyxy2xywh(x1, y1, x2, y2, imgSize):
    imageW, imageH = imgSize
    x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2)
    centerX = ((x1 + x2) / 2) / imageW
    centerY = ((y1 + y2) / 2) / imageH
    w = abs(x2 - x1) / imageW
    h = abs(y2 - y1) / imageH
    return round(centerX, 6), round(centerY, 6), round(w, 6), round(h, 6)


### xywh to xyxy
def yolo2bbox(imgFolder, inputFolder, outputFolder):
    os.makedirs(outputFolder, exist_ok=True)
    allFileList = os.listdir(inputFolder)
    for fileName in allFileList:
        if fileName.split(".")[0] == "classes" or not fileName.endswith(".txt"):
            continue
        print(fileName)
        img = cv2.imread(os.path.join(imgFolder, fileName[:-4] + ".jpg"))
        imgSize = (img.shape[1], img.shape[0])
        shutil.copy(os.path.join(inputFolder, fileName), os.path.join(outputFolder, fileName))
        file = open(os.path.join(inputFolder, fileName), "r")
        outputFile = open(os.path.join(outputFolder, fileName), "wt")
        for line in file:
            _class, x, y, w, h = line.split(" ")
            x1, y1, x2, y2 = xywh2xyxy(x, y, w, h, imgSize)
            outputFile.write(f"{_class} {x1} {y1} {x2} {y2}\n")
        file.close()
        outputFile.close()


### xyxy to xywh
def bbox2yolo(imgFolder, inputFolder, outputFolder):
    os.makedirs(outputFolder, exist_ok=True)
    allFileList = os.listdir(inputFolder)
    for fileName in allFileList:
        if fileName.split(".")[0] == "classes" or not fileName.endswith(".txt"):
            continue
        print(fileName)
        img = cv2.imread(os.path.join(imgFolder, fileName[:-4] + ".jpg"))
        imgSize = (img.shape[1], img.shape[0])
        shutil.copy(os.path.join(inputFolder, fileName), os.path.join(outputFolder, fileName))
        file = open(os.path.join(inputFolder, fileName), "r")
        outputFile = open(os.path.join(outputFolder, fileName), "wt")
        for line in file:
            _class, x1, y1, x2, y2 = line.split(" ")
            x, y, w, h = xyxy2xywh(x1, y1, x2, y2, imgSize)
            outputFile.write(f"{_class} {x} {y} {w} {h}\n")
        file.close()
        outputFile.close()


def remove_class(outputFolderPath, labelFolderPath, classNum):
    allFileList = os.listdir(labelFolderPath)
    for fileName in allFileList:
        if fileName.split(".")[0] == "classes" or not fileName.endswith(".txt"):
            continue
        print(fileName)
        file = open(os.path.join(labelFolderPath, fileName), "r")
        outputFile = open(os.path.join(outputFolderPath, fileName), "wt")
        for line in file:
            _class, x1, y1, x2, y2 = line.split(" ")
            if _class != str(classNum):
                outputFile.write(f"{_class} {x1} {y1} {x2} {y2}")
        file.close()
        outputFile.close()


if __name__ == "__main__":
    count_class(
        labelFilePath=r"D:\UserShare\GitLab\kinsus-panel-tray-defect-detection\Datasets\Experiment Data\20230317\20230321\OK\dataset\tmp_train_val\Annotation"
    )
    # combin_class()
    # image2folder_by_label(
    #     imgFolderPath=r"D:\UserShare\GitLab\kinsus-panel-tray-defect-detection\Datasets\Experiment Data\20230310\dataset\tmp_train_val\Image",
    #     labelFolderPath=r"D:\UserShare\GitLab\kinsus-panel-tray-defect-detection\Datasets\Experiment Data\20230310\dataset\tmp_train_val\Annotation",
    #     outputFolderPath=r"D:\UserShare\GitLab\kinsus-panel-tray-defect-detection\Datasets\Experiment Data\20230310\dataset\tmp_train_val\tmp",
    # )
    # yolo2bbox(
    #     imgFolder=r"D:\UserShare\GitLab\kinsus-panel-tray-defect-detection\Datasets\Experiment Data\20230317\20230321\OK\dataset\NewTest_mask_review\Image",
    #     inputFolder=r"D:\UserShare\GitLab\kinsus-panel-tray-defect-detection\Datasets\Experiment Data\20230317\20230321\OK\dataset\NewTest_mask_review\Annotation_xywh",
    #     outputFolder=r"D:\UserShare\GitLab\kinsus-panel-tray-defect-detection\Datasets\Experiment Data\20230317\20230321\OK\dataset\NewTest_mask_review\Annotation",
    # )
    # bbox2yolo(
    #     imgFolder=r"D:\UserShare\GitLab\kinsus-panel-tray-defect-detection\Datasets\Experiment Data\20230308\dataset\NewTest\Image",
    #     inputFolder=r"D:\UserShare\GitLab\kinsus-panel-tray-defect-detection\Datasets\Experiment Data\20230308\dataset\NewTest\Annotation",
    #     outputFolder=r"D:\UserShare\GitLab\kinsus-panel-tray-defect-detection\Datasets\Experiment Data\20230308\dataset\NewTest\Annotation_xywh",
    # )
    # remove_class(
    #     labelFolderPath=r"D:\UserShare\GitLab\kinsus-panel-tray-defect-detection\Datasets\Experiment Data\20230223_org\dataset\Test_clean_0306_mask\Annotation",
    #     outputFolderPath=r"D:\UserShare\GitLab\kinsus-panel-tray-defect-detection\Datasets\Experiment Data\20230223_org\dataset\Test_clean_0306_mask_2cls\Annotation",
    #     classNum="2",
    # )
