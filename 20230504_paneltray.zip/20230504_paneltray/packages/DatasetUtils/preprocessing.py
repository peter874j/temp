from PIL import Image
from torchvision import transforms as T
import numpy as np
import cv2
import os

os.environ["KMP_DUPLICATE_LIB_OK"] = "True"

import math
from matplotlib import pyplot as plt

# segmentRegionDict = {
#     "Quadrant1": {
#         "x1": 230,
#         "y1": 220,
#         "x2": 1090,
#         "y2": 930,
#     },
#     "Quadrant2": {
#         "x1": 140,
#         "y1": 230,
#         "x2": 1000,
#         "y2": 930,
#     },
#     "Quadrant3": {
#         "x1": 230,
#         "y1": 140,
#         "x2": 1090,
#         "y2": 850,
#     },
#     "Quadrant4": {
#         "x1": 130,
#         "y1": 140,
#         "x2": 1000,
#         "y2": 850,
#     },
# }

# ### For 2023_03_21 / 2023_03_22
# segmentRegionDict = {
#     "Quadrant1": {
#         "x1": 201,
#         "y1": 153,
#         "x2": 1106,
#         "y2": 895,
#     },
#     "Quadrant2": {
#         "x1": 140,
#         "y1": 166,
#         "x2": 1030,
#         "y2": 908,
#     },
#     "Quadrant3": {
#         "x1": 202,
#         "y1": 93,
#         "x2": 1095,
#         "y2": 826,
#     },
#     "Quadrant4": {
#         "x1": 132,
#         "y1": 104,
#         "x2": 1021,
#         "y2": 838,
#     },
# }

### For 2023_04_07
segmentRegionDict = {
    "Quadrant1": {
        "x1": 241,
        "y1": 183,
        "x2": 1076,
        "y2": 865,
    },
    "Quadrant2": {
        "x1": 115,
        "y1": 186,
        "x2": 940,
        "y2": 868,
    },
    "Quadrant3": {
        "x1": 247,
        "y1": 53,
        "x2": 1085,
        "y2": 736,
    },
    "Quadrant4": {
        "x1": 112,
        "y1": 59,
        "x2": 955,
        "y2": 743,
    },
}

### Image 圖片格式轉 cv2
def pil2cv2(img):
    img = cv2.cvtColor(np.asanyarray(img), cv2.COLOR_RGB2BGR)
    return img


### cv2 轉 Image 圖片格式
def cv22pil(img):
    img = Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
    return img


### 修改對比度與亮度
def modify_contrast_and_brightness(img, brightness=0, contrast=100):

    B = brightness / 255.0
    c = contrast / 255.0
    k = math.tan((45 + 44 * c) / 180 * math.pi)
    img = (img - 127.5 * (1 - B)) * k + 127.5 * (1 + B)
    # 所有值必須介於 0~255 之間，超過255 = 255，小於 0 = 0
    img = np.clip(img, 0, 255).astype(np.uint8)
    return img


### 高斯濾波
def gaussuan_blur(img):
    img = cv2.GaussianBlur(img, (5, 5), 0)
    return img


### 二值化
def binary(img, thresh=100, maxval=255):
    GrayImg = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    ret, binaryimg = cv2.threshold(GrayImg, thresh, maxval, cv2.THRESH_BINARY)
    # binaryimg = cv2.adaptiveThreshold(GrayImg, maxval, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY, 11, 2)
    # binaryimg = cv2.adaptiveThreshold(GrayImg, maxval, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY_INV, 11, 2)
    return binaryimg


### 圖像遮罩, 過濾非Tray部分
def mask(img, quadrant):

    # maskDict = {}
    # for key in segmentRegionDict.keys():
    #     x1, y1, x2, y2 = segmentRegionDict[key]
    #     mask = np.zeros(img.shape, dtype="uint8")
    #     mask[:, :] = 255
    #     cv2.rectangle(
    #         mask,
    #         (segmentRegionDict[key][x1], segmentRegionDict[key][y1]),
    #         (segmentRegionDict[key][x2], segmentRegionDict[key][y2]),
    #         0,
    #         -1,
    #     )
    #     maskDict[key] = mask
    # resultImg = cv2.bitwise_and(img, maskDict[f"Quadrant{quadrant}"])

    maskRegion = segmentRegionDict[f"Quadrant{quadrant}"]
    x1, y1, x2, y2 = maskRegion["x1"], maskRegion["y1"], maskRegion["x2"], maskRegion["y2"]
    resultImg = img.copy()
    resultImg[y1:y2, x1:x2] = 0

    return resultImg


### 直方圖均衡化
def equalize(img):
    resultImg = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    # resultImg = cv2.equalizeHist(resultImg)
    ### create clahe image
    clahe = cv2.createCLAHE()
    resultImg = clahe.apply(resultImg)

    return resultImg


### 最大化對比度
def random_autocontrast(imgPath):
    img = Image.open(imgPath)
    imgRA = T.RandomAutocontrast(p=1)(img)
    img = pil2cv2(img)
    imgRA = pil2cv2(imgRA)
    cv2.imshow("img", img)
    cv2.imshow("imgRA", imgRA)
    cv2.waitKey(0)


if __name__ == "__main__":
    imgFolder = (
        r"D:\UserShare\GitLab\kinsus-panel-tray-defect-detection\Datasets\Experiment Data\20230406\2023_04_07\Image"
    )
    outputImgFolder = r"D:\UserShare\GitLab\kinsus-panel-tray-defect-detection\Datasets\Experiment Data\20230406\2023_04_07_mask\Image"
    save = True

    if save:
        os.makedirs(outputImgFolder, exist_ok=True)

    allImgList = os.listdir(imgFolder)
    for imgName in allImgList:
        imgName, extension = os.path.splitext(imgName)  # 分割檔名與附檔名
        quadrant = imgName[-1]
        img = cv2.imread(os.path.join(imgFolder, imgName + extension))
        newimg = img
        newimg = mask(newimg, quadrant)
        # newimg = modify_contrast_and_brightness(newimg, brightness=30, contrast=100)
        # newimg = gaussuan_blur(img)
        # newimg = equalize(newimg)
        # cv2.imshow("equalize", newimg)

        # newimg = mask(img, quadrant)
        # newimg = equalize(newimg)

        if save:
            cv2.imwrite(os.path.join(outputImgFolder, imgName + ".jpg"), newimg)
        else:
            cv2.imshow("img", img)
            cv2.imshow("resultIng", newimg)
            cv2.waitKey(0)
