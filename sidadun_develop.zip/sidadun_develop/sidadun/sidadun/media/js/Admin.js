var info = new Vue({
    el: "#info",
    data: {
        isDisplay: false
    }
})

var app = new Vue({
    el: "#app",
    data: {
        Permission: 0, // 預設0沒權限
    },
    created: function () {
        this.init();
    },
    methods: {
        init: async function () {
            console.log('管理員列表');
            let self = this;
            self.LoadAdministerList();
            self.CheckPermission();
        },
        getCookie(cookieName) {
            var name = cookieName + "=";
            var ca = document.cookie.split(';');
            for (var i = 0; i < ca.length; i++) {
                var c = ca[i];
                while (c.charAt(0) == ' ') c = c.substring(1);
                if (c.indexOf(name) == 0) return c.substring(name.length, c.length);
            }
            return "";
        },
        async LoadAdministerList() {
            console.log('載入管理員資料');
            let self = this;
            await axios.get('../API/GetAllAdminister')
                .then((response) => {
                    console.log('GetAllAdminister:', response.data);
                    AdministerTable.addData(response.data);
                })
                .catch((error) => {
                    console.log('GetAllAdminister error -', error);
                });
        },
        async AddAdminister() {
            let self = this;
            // console.log('新增管理員');

            Swal.fire({
                title: 'Add Administer Info',
                icon: 'info',
                stopKeydownPropagation: false,
                html: '<div class="input-group mb-3">' +
                    '<div class="input-group-prepend">' +
                    '<span class="input-group-text">工號</span>' +
                    '</div>' +
                    '<input type="text" class="form-control" id="userid">' +
                    '</div>',
                showCloseButton: true,
                showCancelButton: true,
                focusConfirm: false,
                confirmButtonColor: '#866E61',
                confirmButtonText: '<i class="fa fa-check"> 新增</i>',
                cancelButtonText: '<i class="fa fa-times"> 取消</i>',
                preConfirm: () => {
                    const userid = Swal.getPopup().querySelector('#userid').value
                    if (!userid) {
                        Swal.showValidationMessage(`請輸入工號`)
                    }
                    return {
                        userid: userid
                    }
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    axios.get('http://autcpmoweb01.corpnet.auo.com/AuoOrganization/Employee/' + `${result.value.userid}`)
                        .then((response) => {
                            var EmployeeData = response.data;
                            // console.log('EmployeeData:', EmployeeData);
                            if (EmployeeData == '') {
                                Swal.fire({
                                    title: "工號不存在",
                                    icon: "error",
                                })
                            } else {
                                if (result.isConfirmed) {
                                    var administer_data = {
                                        dept: EmployeeData.org_id,
                                        userid: EmployeeData.emp_no,
                                        name: EmployeeData.emp_name
                                    }
                                    axios.post('../API/GetAllAdminister', administer_data)
                                        .then((response) => {
                                            if (response.status == 200) {
                                                if (response.data == 'CONFLICT') {
                                                    Swal.fire({
                                                        icon: 'error',
                                                        title: '管理員新增失敗',
                                                        text: '工號「' + `${result.value.userid}` + '」重複'
                                                    });
                                                } else {
                                                    Swal.fire({
                                                            title: "管理員新增成功",
                                                            icon: "success",
                                                            html: '<span>部門：' + EmployeeData.org_id + '</span></br>' +
                                                                '<span>工號：' + EmployeeData.emp_no + '</span></br>' +
                                                                '<span>姓名：' + EmployeeData.emp_name + '</span>'
                                                        })
                                                        .then((result) => {
                                                            if (result.isConfirmed) {
                                                                AdministerTable.replaceData([]);
                                                                self.LoadAdministerList();
                                                            }
                                                        })
                                                }
                                            }
                                        })
                                        .catch((error) => {
                                            console.log('GetAllAdminister error - ', error);
                                            Swal.fire({
                                                icon: 'error',
                                                title: 'Error',
                                                text: '管理員新增失敗'
                                            });
                                        });
                                }
                            }
                        })
                }
            })
        },
        async CheckPermission() {
            let self = this;
            await axios.get('../API/CheckPermission')
                .then((response) => {
                    var PermissionLIst = response.data
                    // console.log('CheckPermission:', PermissionLIst);
                    if (PermissionLIst.includes(getCookie('userid'))) {
                        self.Permission = 1;
                    } else {
                        self.Permission = 0;
                    }
                })
        },
        async deleteAdministerClick(e, cell) {
            let self = this;
            if (self.Permission == 1) {
                var row = cell.getRow();
                var cell_id = row.getCell('id').getValue();
                var cell_userid = row.getCell('userid').getValue();
                var cell_name = row.getCell('name').getValue();
                console.log('管理員 刪除 id=' + cell_id);

                const swalWithBootstrapButtons = Swal.mixin({
                    customClass: {
                        confirmButton: 'btn btn-success',
                        cancelButton: 'btn btn-danger'
                    },
                    buttonsStyling: false
                })

                Swal.fire({
                    title: '確定刪除此管理員嗎？',
                    text: cell_userid + ' / ' + cell_name,
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: '刪除',
                    cancelButtonText: '取消',
                    showClass: {
                        popup: 'animate__animated animate__fadeInDown'
                    },
                    hideClass: {
                        popup: 'animate__animated animate__fadeOutUp'
                    }
                }).then((result) => {
                    if (result.isConfirmed) {
                        axios.delete('../API/GetAdministerById/' + cell_id)
                            .then(() =>
                                swalWithBootstrapButtons.fire({
                                    icon: 'success',
                                    title: 'Deleted',
                                    text: '管理員刪除成功'
                                })
                                .then((result) => {
                                    if (result.isConfirmed) {
                                        AdministerTable.replaceData([]);
                                        self.LoadAdministerList();
                                    }
                                })
                            );
                    } else if (result.dismiss === Swal.DismissReason.cancel) {
                        swalWithBootstrapButtons.fire(
                            'Cancelled',
                            '取消刪除',
                            'info'
                        );
                    }
                })
            } else {
                Swal.fire({
                    icon: 'info',
                    title: '無刪除權限',
                    html: '若須刪除請洽管理員'
                })
            }
        }
    }
});