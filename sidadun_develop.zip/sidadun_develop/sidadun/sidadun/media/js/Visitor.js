var info = new Vue({
    el: "#info",
    data: {
        isDisplay: false
    }
})

var app = new Vue({
    el: "#app",
    data: {
        VisitorDetail: {
            visitor_name: null,
            visit_date: null,
            visit_start_time: null,
            visit_end_time: null
        },
        ClickCellid: '',
        Permission: 0, // 預設0沒權限
    },
    created: function () {
        this.init();
    },
    methods: {
        init: async function () {
            console.log('參訪團列表');
            let self = this;
            self.LoadVisitorList();
            self.CheckPermission();
        },
        getCookie(cookieName) {
            var name = cookieName + "=";
            var ca = document.cookie.split(';');
            for (var i = 0; i < ca.length; i++) {
                var c = ca[i];
                while (c.charAt(0) == ' ') c = c.substring(1);
                if (c.indexOf(name) == 0) return c.substring(name.length, c.length);
            }
            return "";
        },
        async LoadVisitorList() {
            console.log('載入參訪團資料');
            let self = this;
            await axios.get('../API/GetAllVisitor')
                .then((response) => {
                    console.log('GetAllVisitor:', response.data);
                    VisitorTable.addData(response.data);
                })
                .catch((error) => {
                    console.log('GetAllVisitor error -', error);
                });
        },
        async AddVisitor() {
            let self = this;
            // console.log('新增參訪團');

            Swal.fire({
                title: 'Add Visitor Info',
                icon: 'info',
                stopKeydownPropagation: false,
                html: '<div class="input-group mb-3">' +
                    '<div class="input-group-prepend">' +
                    '<span class="input-group-text">參訪團名稱</span>' +
                    '</div>' +
                    '<input type="text" class="form-control" id="visitor_name">' +
                    '</div>' + 
                    '<div class="input-group mb-3">' +
                    '<div class="input-group-prepend">' +
                    '<span class="input-group-text">參訪日期</span>' +
                    '</div>' +
                    '<input type="text" class="form-control" id="visit_date">' +
                    '</div>' + 
                    '<div class="input-group mb-3">' +
                    '<div class="input-group-prepend">' +
                    '<span class="input-group-text">開始參訪時間</span>' +
                    '</div>' +
                    '<input type="time" class="form-control" id="visit_start_time">' +
                    '</div>' + 
                    '<div class="input-group mb-3">' +
                    '<div class="input-group-prepend">' +
                    '<span class="input-group-text">結束參訪時間</span>' +
                    '</div>' +
                    '<input type="time" class="form-control" id="visit_end_time">' +
                    '</div>',
                showCloseButton: true,
                showCancelButton: true,
                focusConfirm: false,
                confirmButtonColor: '#866E61',
                confirmButtonText: '<i class="fa fa-check"> 新增</i>',
                cancelButtonText: '<i class="fa fa-times"> 取消</i>',
                preConfirm: () => {
                    const name = Swal.getPopup().querySelector('#visitor_name').value
                    const date = Swal.getPopup().querySelector('#visit_date').value
                    const start_time = Swal.getPopup().querySelector('#visit_start_time').value
                    const end_time = Swal.getPopup().querySelector('#visit_end_time').value
                    if (!name || !date || !start_time || !end_time) {
                        Swal.showValidationMessage(`請輸入名稱、日期、開始結束時間`)
                    }
                    return {
                        name: name,
                        date: date,
                        start_time: start_time,
                        end_time: end_time
                    }
                },
                didOpen: () => {
                    visit_date = new Pikaday({ field: $('#visit_date')[0] });
                },
            }).then((result) => {
                if (result.isConfirmed) {
                    var visitor_data = {
                        visitor_name: document.getElementById('visitor_name').value,
                        visit_date: document.getElementById('visit_date').value,
                        visit_time: document.getElementById('visit_start_time').value + '-' + document.getElementById('visit_end_time').value,
                    }
                    console.log('visitor_data:', visitor_data);
                    axios.post('../API/GetAllVisitor', visitor_data)
                        .then((response) => {
                            if (response.status == 200) {
                                if (response.data == 'CONFLICT') {
                                    Swal.fire({
                                        icon: 'error',
                                        title: '參訪團新增失敗',
                                        text: '參訪團「' + `${result.value.name}` + '」重複'
                                    });
                                } else {
                                    Swal.fire({
                                            title: "參訪團新增成功",
                                            icon: "success",
                                            html: '<span>名稱 - ' + visitor_data.visitor_name + '</span></br>' +
                                                '<span>日期 - ' + visitor_data.visit_date + '</span></br>' +
                                                '<span>時間 - ' + visitor_data.visit_time + '</span>',
                                        })
                                        .then((result) => {
                                            if (result.isConfirmed) {
                                                VisitorTable.replaceData([]);
                                                self.LoadVisitorList();
                                            }
                                        })
                                }
                            }
                        })
                        .catch((error) => {
                            console.log('GetAllVisitor error - ', error);
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: '參訪團新增失敗'
                            });
                        });
                }
            })
        },
        async CheckPermission() {
            let self = this;
            await axios.get('../API/CheckPermission')
                .then((response) => {
                    var PermissionLIst = response.data
                    // console.log('CheckPermission:', PermissionLIst);
                    if (PermissionLIst.includes(getCookie('userid'))) {
                        self.Permission = 1;
                    } else {
                        self.Permission = 0;
                    }
                })
        },
        async deleteVisitorClick(e, cell) {
            let self = this;
            if (self.Permission == 1) {
                var row = cell.getRow();
                var cell_id = row.getCell('id').getValue();
                var cell_visitor_name = row.getCell('visitor_name').getValue();
                var cell_visit_date = row.getCell('visit_date').getValue();
                console.log('參訪團 刪除 id=' + cell_id);

                const swalWithBootstrapButtons = Swal.mixin({
                    customClass: {
                        confirmButton: 'btn btn-success',
                        cancelButton: 'btn btn-danger'
                    },
                    buttonsStyling: false
                })

                Swal.fire({
                    title: '確定刪除此參訪團嗎？',
                    text: cell_visitor_name + ' / ' + cell_visit_date,
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: '刪除',
                    cancelButtonText: '取消',
                    showClass: {
                        popup: 'animate__animated animate__fadeInDown'
                    },
                    hideClass: {
                        popup: 'animate__animated animate__fadeOutUp'
                    }
                }).then((result) => {
                    if (result.isConfirmed) {
                        axios.delete('../API/GetVisitorById/' + cell_id)
                            .then(() =>
                                swalWithBootstrapButtons.fire({
                                    icon: 'success',
                                    title: 'Deleted',
                                    text: '參訪團刪除成功'
                                })
                                .then((result) => {
                                    if (result.isConfirmed) {
                                        VisitorTable.replaceData([]);
                                        self.LoadVisitorList();
                                    }
                                })
                            );
                    } else if (result.dismiss === Swal.DismissReason.cancel) {
                        swalWithBootstrapButtons.fire(
                            'Cancelled',
                            '取消刪除',
                            'info'
                        );
                    }
                })
            } else {
                Swal.fire({
                    icon: 'info',
                    title: '無刪除權限',
                    html: '若須刪除請洽管理員'
                })
            }
        },
        async editVisitorClick(e, cell) {
            let self = this;
            var row = cell.getRow();
            var cell_id = row.getCell('id').getValue();
            self.ClickCellid = cell_id;
            console.log('參訪團 編輯 id=' + cell_id);

            await axios.get('../API/GetVisitorById/' + cell_id)
                .then((response) => {
                    console.log('(Edit) GetVisitorById:', response.data);
                    var Detail = response.data[0];
                    self.VisitorDetail.visitor_name = Detail['visitor_name']
                    self.VisitorDetail.visit_date = Detail['visit_date']
                    self.VisitorDetail.visit_start_time = Detail['visit_time'].split('-')[0]
                    self.VisitorDetail.visit_end_time = Detail['visit_time'].split('-')[1]
                })
                .catch((error) => {
                    console.log('editVisitorClick error -', error);
                });
        },
        async UpdateVisitor() {
            let self = this;
            if (self.VisitorDetail.visitor_name != null && self.VisitorDetail.visit_date != null && self.VisitorDetail.visit_time != '') {
                let update_visitor_data = {
                    visitor_name: self.VisitorDetail.visitor_name,
                    visit_date: self.VisitorDetail.visit_date,
                    visit_time: self.VisitorDetail.visit_time,
                }
                // console.log('update_visitor_data', update_visitor_data);

                axios.patch('../API/GetVisitorById/' + self.ClickCellid, update_visitor_data)
                    .then(function (response) {
                        if (response.status == 200) {
                            Swal.fire({
                                    icon: 'success',
                                    title: '參訪團編輯成功',
                                    confirmButtonColor: '#866E61',
                                })
                                .then((result) => {
                                    if (result.isConfirmed) {
                                        VisitorTable.replaceData([]);
                                        self.LoadVisitorList();
                                    }
                                })
                        } else {
                            Swal.fire({
                                title: "參訪團編輯失敗",
                                icon: "error",
                            })
                        }
                    })
                    .catch((error) => {
                        console.log('UpdatVisitor error - ', error);
                    });
            } else {
                Swal.fire({
                    icon: 'error',
                    title: '參訪團編輯失敗',
                    html: '請輸入完整資料'
                })
            }
        }
    }
});