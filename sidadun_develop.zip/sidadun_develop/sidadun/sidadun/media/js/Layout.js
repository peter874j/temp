var info = new Vue({
    el: "#info",
    data: {
        isDisplay: true
    }
})

var app = new Vue({
    el: "#app",
    data: {
        heatMapObs: null,
        heatMapData: {},
        heatMapInstance: {},
        drawingData: [],
        visitorData: {},
        AreaData1: [],
        AreaData2: [],
    },
    created: function () {
        this.init();
    },
    mounted() {
        let self = this;
        self.HeatmapTimer = setInterval(self.LoadHeatmapData, 5000);
        self.visitorTimer = setInterval(self.LoadvisitorData, 60000);
    },
    computed: {
        peopleCountClass() {
            value = parseInt(this.heatMapData.all_count);
            if (value >= 30) {
                return 'gradient-2'
            } else if (value >= 21 && value < 30) {
                return 'gradient-3'
            } else if (value >= 11 && value < 20) {
                return 'gradient-1'
            } else {
                return 'gradient-4'
            }
        }
    },
    methods: {
        init: async function () {
            let self = this;
            await self.GetArea();
            await self.LoadHeatmapData();
            await self.LoadvisitorData();
            await self.heatMapInit();
            await self.createAreaVisitorChart();
            self.heatMapObs = new ResizeObserver(self.heatMapInit);
            self.heatMapObs.observe(document.getElementById('layout'));
        },
        async LoadvisitorData() {
            let self = this;
            console.log("LoadvisitorData")
            await axios.get('../API/GetAreaVisitor')
                .then((res) => {
                    // console.log(res)
                    self.visitorData = res.data[0];
                })
                .catch((error) => {
                    console.log(error);
                });
        },
        async LoadHeatmapData() {
            let self = this;
            console.log("LoadHeatmapData")
            await axios.get('../API/GetHeatmap')
                .then((res) => {
                    self.heatMapData = res.data[0];
                })
                .catch((error) => {
                    console.log(error);
                });
        },
        createPointData(data) {
            this.drawData = []
            var scaleRatio = {};
            scaleRatio = {
                width: document.getElementById('map').width / document.getElementsByClassName('heatmap-canvas')[0].width,
                height: document.getElementById('map').height / document.getElementsByClassName('heatmap-canvas')[0].height,
            }
            data.forEach(element => {
                obj = {
                    "x": element[0] * scaleRatio.width,
                    "y": element[1] * scaleRatio.height,
                    "value": element[2]
                }
                this.drawData.push(obj);
            });
        },
        async heatMapInit() {
            let self = this;
            // let arr = [];
            console.log('init')
            if (document.getElementsByClassName('heatmap-canvas')[0] != undefined) {
                document.getElementsByClassName('heatmap-canvas')[0].remove();
                self.heatMapInstance = {}
            }
            self.heatMapInstance = h337.create({
                container: document.getElementById('layout'), //存放heatmap的div
                maxOpacity: 0.4,
                backgroundColor: 'rgba(63, 127, 191,.2)',
                gradient: {
                    '.2': 'rgba(63, 127, 191,.2)',
                    '.4': 'green',
                    '.6': 'yellow',
                    '.95': 'red'
                },
                onExtremaChange: function (data) {
                    updateLegend(data);
                }
            });
            self.createPointData(JSON.parse(self.heatMapData.data));

            const drawData = { // 熱區繪製的資料格式
                max: 100,
                data: self.drawData
            };
            self.heatMapInstance.setData(drawData);
            // document.getElementsByClassName('heatmap-canvas')[0].style.width = "100%";

            // var legendCanvas = document.getElementsByClassName('heatmap-canvas')[0];
            // legendCanvas.width = 100;
            // legendCanvas.height = 10;
            var gradientCfg = {};

            function updateLegend(data) {
                // the onExtremaChange callback gives us min, max, and the gradientConfig
                // so we can update the legend
                document.querySelector('#min').innerHTML = data.min;
                document.querySelector('#max').innerHTML = data.max;
                // regenerate gradient image
                if (data.gradient != gradientCfg) {
                    gradientCfg = data.gradient;
                    var gradient = document.getElementsByClassName('heatmap-canvas')[0].getContext('2d').createLinearGradient(0, 0, 100, 1);
                    for (var key in gradientCfg) {
                        gradient.addColorStop(key, gradientCfg[key]);
                    }
                    document.getElementsByClassName('heatmap-canvas')[0].getContext('2d').fillStyle = gradient;
                    document.getElementsByClassName('heatmap-canvas')[0].getContext('2d').fillRect(0, 0, 100, 10);
                    document.querySelector('#gradient').src = document.getElementsByClassName('heatmap-canvas')[0].toDataURL();
                }
            };
            /* legend code end */

            /* tooltip code start */
            var heatMapWrapper = document.querySelector('.heatmap-canvas');
            var tooltip = document.querySelector('.heat-map-tooltip');
            // var scaleRatio = 0;
            // scaleRatio = document.getElementById('map').width / document.getElementsByClassName('heatmap-canvas')[0].width
            var scaleRatio = {};
            scaleRatio = {
                width: document.getElementById('map').width / document.getElementsByClassName('heatmap-canvas')[0].width,
                height: document.getElementById('map').height / document.getElementsByClassName('heatmap-canvas')[0].height,
            }

            function updateTooltip(x, y, value) {
                // + 15 for distance to cursor
                var transl = 'translate(' + (x + 15) + 'px, ' + (y + 15) + 'px)';
                tooltip.style.webkitTransform = transl;
                tooltip.innerHTML = value;
            };
            heatMapWrapper.onmousemove = function (ev) {

                var x = ev.layerX;
                var y = ev.layerY;
                // getValueAt gives us the value for a point p(x/y)
                var value = self.heatMapInstance.getValueAt({
                    x: x / scaleRatio.width,
                    y: y / scaleRatio.height
                });
                tooltip.style.display = 'block';
                updateTooltip(x, y, value);
            };
            // hide tooltip on mouseout
            heatMapWrapper.onmouseout = function () {
                tooltip.style.display = 'none';
            };
        },
        async GetArea() {
            let self = this;
            axios.get('../API/GetAllArea')
                .then(function (response) {
                    // console.log('AreaList:', response.data);
                    var options_num = [];
                    var options_name = [];
                    for (var i = 0; i < response.data.length; i++) {
                        options_num.push(response.data[i]['area_num']);
                        options_name.push(response.data[i]['area_name']);
                    }
                    // console.log('options_num:', options_num);
                    // console.log('options_name:', options_name);

                    const num_middleIndex = Math.ceil(options_num.length / 2);
                    const num_firstHalf = options_num.splice(0, num_middleIndex);
                    const num_secondHalf = options_num.splice(-num_middleIndex);
                    const name_middleIndex = Math.ceil(options_name.length / 2);
                    const name_firstHalf = options_name.splice(0, name_middleIndex);
                    const name_secondHalf = options_name.splice(-name_middleIndex);

                    // console.log(num_firstHalf);
                    // console.log(num_secondHalf);
                    // console.log(name_firstHalf);
                    // console.log(name_secondHalf);

                    var Data1 = [];
                    for (var i = 0; i < num_firstHalf.length; i++) {
                        var tmp_dict = {
                            num: num_firstHalf[i],
                            name: name_firstHalf[i]
                        };
                        Data1.push(tmp_dict);
                    }
                    self.AreaData1 = Data1;
                    // console.log('AreaData1:', self.AreaData1);

                    var Data2 = [];
                    for (var i = 0; i < num_secondHalf.length; i++) {
                        var tmp_dict = {
                            num: num_secondHalf[i],
                            name: name_secondHalf[i]
                        };
                        Data2.push(tmp_dict);
                    }
                    self.AreaData2 = Data2;
                    // console.log('AreaData2:', self.AreaData2);
                })
                .catch((error) => {
                    console.log('GetArea error - ', error);
                });
        },
        createAreaVisitorChart() {
            var self = this;
            var area = app.visitorData.area.substring(2, app.visitorData.area.length - 2).replaceAll("'", "").split(", ")
            var myLayoutCountChart = echarts.init(document.getElementById('LayoutCountChart'));
            myLayoutCountChart.setOption({
                grid: {
                    left: '10%',
                    right: '0%'
                },
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {
                        type: 'shadow'
                    }
                },
                xAxis: [{
                    type: 'category',
                    data: area,
                    axisTick: {
                        show: false,
                    },
                    splitLine: {
                        show: false,
                    },
                    axisLine: {
                        show: false,
                    },
                    axisLabel: {
                        color: '#959494',
                        fontSize: 12,
                        fontWeight: 600,
                        interval: 0,
                        padding: [8, 0, 0, 0]
                    },
                }],
                yAxis: [{
                    type: 'value',
                    name: '(人)',
                    nameTextStyle: {
                        color: "#959494",
                        fontSize: 12,
                        padding: [0, 0, 6, -60],
                    },
                    axisLabel: {
                        show: true,
                        textStyle: {
                            color: '#959494'
                        },
                        padding: 10
                    },
                }],
                series: [{
                    name: '人數',
                    type: 'bar',
                    emphasis: {
                        focus: 'series'
                    },
                    barWidth: 20,
                    itemStyle: {
                        color: '#866E61'
                    },
                    label: {
                        normal: {
                            show: true,
                            position: "top",
                            formatter: function (data) {
                                return '{a0|' + data.value + '}';
                            },
                            rich: {
                                a0: {
                                    color: '#866E61',
                                    fontSize: 14
                                },
                            }
                        },
                    },
                    data: JSON.parse(self.visitorData.count)
                }]
            });
        }
    }
});