var info = new Vue({
    el: "#info",
    data: {
        isDisplay: true
    }
})

var app = new Vue({
    el: "#app",
    data: {
        AreaData1: [],
        AreaData2: [],
        VisitorOptions: [],
        VisitorData: {},
        SelectVisitor: 'All'
    },
    created: function () {
        this.init();
    },
    methods: {
        init: async function () {
            let self = this;
            await self.LoadVisitorData();
            await self.GetVisitor();
            await self.GetArea();
            await self.CreateAreaVisitorChart();
        },
        async LoadVisitorData() {
            let self = this;
            await axios.get('../API/GetAreaVisitor')
                .then((res) => {
                    self.VisitorData = res.data[0];
                })
                .catch((error) => {
                    console.log('LoadVisitorData:', error);
                });
        },
        async GetArea() {
            let self = this;
            axios.get('../API/GetAllArea')
                .then(function (response) {
                    // console.log('AreaList:', response.data);
                    var options_num = [];
                    var options_name = [];
                    for (var i = 0; i < response.data.length; i++) {
                        options_num.push(response.data[i]['area_num']);
                        options_name.push(response.data[i]['area_name']);
                    }
                    // console.log('options_num:', options_num);
                    // console.log('options_name:', options_name);

                    const num_middleIndex = Math.ceil(options_num.length / 2);
                    const num_firstHalf = options_num.splice(0, num_middleIndex);
                    const num_secondHalf = options_num.splice(-num_middleIndex);
                    const name_middleIndex = Math.ceil(options_name.length / 2);
                    const name_firstHalf = options_name.splice(0, name_middleIndex);
                    const name_secondHalf = options_name.splice(-name_middleIndex);

                    // console.log(num_firstHalf);
                    // console.log(num_secondHalf);
                    // console.log(name_firstHalf);
                    // console.log(name_secondHalf);

                    var Data1 = [];
                    for (var i = 0; i < num_firstHalf.length; i++) {
                        var tmp_dict = {
                            num: num_firstHalf[i],
                            name: name_firstHalf[i]
                        };
                        Data1.push(tmp_dict);
                    }
                    self.AreaData1 = Data1;
                    // console.log('AreaData1:', self.AreaData1);

                    var Data2 = [];
                    for (var i = 0; i < num_secondHalf.length; i++) {
                        var tmp_dict = {
                            num: num_secondHalf[i],
                            name: name_secondHalf[i]
                        };
                        Data2.push(tmp_dict);
                    }
                    self.AreaData2 = Data2;
                    // console.log('AreaData2:', self.AreaData2);
                })
                .catch((error) => {
                    console.log('GetArea error - ', error);
                });
        },
        async GetVisitor() {
            let self = this;

            function search(params, data) {
                if ($.trim(params.term) === '') {
                    return data;
                }
                if (typeof data.text === 'undefined') {
                    return null;
                }
                if (data.text.indexOf(params.term) > -1) {
                    var modifiedData = $.extend({}, data, true);
                    modifiedData.text += ' (匹配)';
                    return modifiedData;
                }
                return null;
            }
            await axios.get('../API/GetAllVisitor')
                .then(response => {
                    console.log('VisitorList:', response.data);

                    var options = [];
                    for (var i = 0; i < response.data.length; i++) {
                        var tmp_dict = {
                            text: response.data[i]['visitor_name'],
                            value: response.data[i]['visitor_name']
                        };
                        options.push(tmp_dict);
                    }
                    self.VisitorOptions = options
                })
                .catch((error) => {
                    console.log('GetVisitor error - ', error);
                });

            $('#VisitorFilter').select2({
                width: '100%',
                allowClear: true,
                closeOnSelect: true,
                dropdownAutoWidth: true,
                matcher: search
            });
        },
        UpdateVisitor() {
            console.log('Update Visitor');
            var data = $(".select2 option:selected").text();
            console.log(data);
            // console.log('VisitorFilter :', $("#VisitorFilter").val(data));
        },
        CreateAreaVisitorChart() {
            var self = this;
            var area = app.VisitorData.area.substring(2, app.VisitorData.area.length - 2).replaceAll("'", "").split(", ")
            var myLayoutCountChart = echarts.init(document.getElementById('LayoutCountChart'));
            myLayoutCountChart.setOption({
                grid: {
                    left: '6%',
                    right: '0%'
                },
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {
                        type: 'shadow'
                    }
                },
                xAxis: [{
                    type: 'category',
                    data: area,
                    axisTick: {
                        show: false,
                    },
                    splitLine: {
                        show: false,
                    },
                    axisLine: {
                        show: false,
                    },
                    axisLabel: {
                        color: '#959494',
                        fontSize: 12,
                        fontWeight: 600,
                        interval: 0,
                        padding: [8, 0, 0, 0]
                    },
                }],
                yAxis: [{
                    type: 'value',
                    name: '(人)',
                    nameTextStyle: {
                        color: "#959494",
                        fontSize: 12,
                        padding: [0, 0, 6, -60],
                    },
                    axisLabel: {
                        show: true,
                        textStyle: {
                            color: '#959494'
                        },
                        padding: 10
                    },
                }],
                series: [{
                    name: '人數',
                    type: 'bar',
                    emphasis: {
                        focus: 'series'
                    },
                    barWidth: 30,
                    itemStyle: {
                        color: '#866E61'
                    },
                    label: {
                        normal: {
                            show: true,
                            position: "top",
                            formatter: function (data) {
                                return '{a0|' + data.value + '}';
                            },
                            rich: {
                                a0: {
                                    color: '#866E61',
                                    fontSize: 14
                                },
                            }
                        },
                    },
                    data: JSON.parse(self.VisitorData.count)
                }]
            });
            window.addEventListener('resize', function () {
                myLayoutCountChart.resize();
            })
        }
    }
});