import pymysql
from datetime import date
from itertools import chain
from django.http import Http404
from django.db import connection
from rest_framework import views
from rest_framework import status
from rest_framework.response import Response
from drf_yasg.utils import swagger_auto_schema
from API.models import Heatmap_mainlist, AreaVisitor_mainlist
from API.models import Area_mainlist, Visitor_mainlist, Administer_mainlist
from API.serializers import HeatmapMainlistSerializer, AreaVisitorMainlistSerializer 
from API.serializers import AreaMainlistSerializer, VisitorMainlistSerializer, AdministerMainlistSerializer


class HeatmapMainlistView(views.APIView):
    @swagger_auto_schema(operation_summary='列出最近一筆熱點資訊')
    def get(self, request):
        queryset = Heatmap_mainlist.objects.order_by('-insert_time')[:1]
        serializer = HeatmapMainlistSerializer(queryset, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
    
    @swagger_auto_schema(operation_summary='新增熱點資訊')
    def post(self, request, *args, **kwargs):
        serializer = HeatmapMainlistSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)


class AreaVisitorMainlistView(views.APIView):
    @swagger_auto_schema(operation_summary='列出最近一筆各展區人數統計資訊')
    def get(self, request):
        queryset = AreaVisitor_mainlist.objects.order_by('-insert_time')[:1]
        serializer = AreaVisitorMainlistSerializer(queryset, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
    
    @swagger_auto_schema(operation_summary='新增一筆各展區人數統計資訊')
    def post(self, request, *args, **kwargs):
        serializer = AreaVisitorMainlistSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)


class AreaMainlistView(views.APIView):
    @swagger_auto_schema(operation_summary='列出展區清單')
    def get(self, request):
        queryset = Area_mainlist.objects.order_by('area_num')
        serializer = AreaMainlistSerializer(queryset, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
    
    @swagger_auto_schema(operation_summary='新增展區')
    def post(self, request, *args, **kwargs):
        serializer = AreaMainlistSerializer(data=request.data) 
        queryset_area = Area_mainlist.objects.get_queryset().values('id', 'area_num', 'area_name')
        result_area = [entry for entry in queryset_area]
        result_area_name = [i['area_name'] for i in result_area]

        if (request.data['area_name'] in result_area_name):
            return Response('CONFLICT')
        else:
            serializer.is_valid(raise_exception=True)
            serializer.save()
            return Response(serializer.data)


class AreaMainlist_Id(views.APIView):
    queryset = Area_mainlist.objects.all()
    serializer_class = AreaMainlistSerializer

    def get_object(self, id):
        try:
            return Area_mainlist.objects.get(id=id)
        except Area_mainlist.DoesNotExist:
            raise Http404
    
    @swagger_auto_schema(operation_summary='使用id查詢單筆展區')
    def get(self, request, id):
        if id is None:
            queryset2 = Area_mainlist.objects.get_queryset()
            serializer = AreaMainlistSerializer(queryset2, many=True)
            return Response(serializer.data)
        else:
            queryset2 = Area_mainlist.objects.get_queryset().filter(id=id)
            serializers = AreaMainlistSerializer(queryset2, many=True)
            return Response(serializers.data)
    
    @swagger_auto_schema(operation_summary='使用id更新展區')
    def patch(self, request, id):
        result = self.get_object(id)
        serializer = AreaMainlistSerializer(result, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    @swagger_auto_schema(operation_summary='使用id刪除展區')
    def delete(self, request, id):
        result = self.get_object(id)
        result.delete()
        return Response(status=status.HTTP_200_OK)


class VisitorMainlistView(views.APIView):
    @swagger_auto_schema(operation_summary='列出參訪團清單')
    def get(self, request):
        queryset = Visitor_mainlist.objects.all()
        serializer = VisitorMainlistSerializer(queryset, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
    
    @swagger_auto_schema(operation_summary='新增參訪團')
    def post(self, request, *args, **kwargs):
        serializer = VisitorMainlistSerializer(data=request.data) 
        queryset_visitor = Visitor_mainlist.objects.get_queryset().values('id', 'visitor_name', 'visit_date', 'visit_time')
        result_visitor = [entry for entry in queryset_visitor]
        result_visitor_name = [i['visitor_name'] for i in result_visitor]

        if (request.data['visitor_name'] in result_visitor_name):
            return Response('CONFLICT')
        else:
            serializer.is_valid(raise_exception=True)
            serializer.save()
            return Response(serializer.data)


class VisitorMainlist_Id(views.APIView):
    queryset = Visitor_mainlist.objects.all()
    serializer_class = VisitorMainlistSerializer

    def get_object(self, id):
        try:
            return Visitor_mainlist.objects.get(id=id)
        except Visitor_mainlist.DoesNotExist:
            raise Http404
    
    @swagger_auto_schema(operation_summary='使用id查詢單筆參訪團')
    def get(self, request, id):
        if id is None:
            queryset2 = Visitor_mainlist.objects.get_queryset()
            serializer = VisitorMainlistSerializer(queryset2, many=True)
            return Response(serializer.data)
        else:
            queryset2 = Visitor_mainlist.objects.get_queryset().filter(id=id)
            serializers = VisitorMainlistSerializer(queryset2, many=True)
            return Response(serializers.data)
    
    @swagger_auto_schema(operation_summary='使用id更新參訪團')
    def patch(self, request, id):
        result = self.get_object(id)
        serializer = VisitorMainlistSerializer(result, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    @swagger_auto_schema(operation_summary='使用id刪除參訪團')
    def delete(self, request, id):
        result = self.get_object(id)
        result.delete()
        return Response(status=status.HTTP_200_OK)


class AdministerMainlistView(views.APIView):
    @swagger_auto_schema(operation_summary='列出管理員清單')
    def get(self, request):
        queryset = Administer_mainlist.objects.all()
        serializer = AdministerMainlistSerializer(queryset, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
    
    @swagger_auto_schema(operation_summary='新增管理員')
    def post(self, request, *args, **kwargs):
        serializer = AdministerMainlistSerializer(data=request.data) 
        queryset_administer = Administer_mainlist.objects.get_queryset().values('id', 'dept', 'userid', 'name')
        result_administer = [entry for entry in queryset_administer]
        result_administer_userid = [i['userid'] for i in result_administer]

        if (request.data['userid'] in result_administer_userid):
            return Response('CONFLICT')
        else:
            serializer.is_valid(raise_exception=True)
            serializer.save()
            return Response(serializer.data)


class AdministerMainlist_Id(views.APIView):
    queryset = Administer_mainlist.objects.all()
    serializer_class = AdministerMainlistSerializer

    def get_object(self, id):
        try:
            return Administer_mainlist.objects.get(id=id)
        except Administer_mainlist.DoesNotExist:
            raise Http404
    
    @swagger_auto_schema(operation_summary='使用id刪除管理員')
    def delete(self, request, id):
        result = self.get_object(id)
        result.delete()
        return Response(status=status.HTTP_200_OK)


class CheckPermissionView(views.APIView):
    @swagger_auto_schema(operation_summary='管理員權限檢查')
    def get(self, request):
        serializer = AdministerMainlistSerializer(data=request.data) 
        queryset_administer = Administer_mainlist.objects.get_queryset().values('userid')
        result_administer = [entry for entry in queryset_administer]
        PermissionList = [i['userid'] for i in result_administer]
        return Response(PermissionList, status=status.HTTP_200_OK)