from django.conf.urls import url
from django.urls import path, include
from rest_framework import permissions
from drf_yasg.views import get_schema_view
from drf_yasg import openapi

from .views import (
    HeatmapMainlistView,
    AreaVisitorMainlistView,
    AreaMainlistView,
    AreaMainlist_Id,
    VisitorMainlistView,
    VisitorMainlist_Id,
    AdministerMainlistView,
    AdministerMainlist_Id,
    CheckPermissionView,
)

schema_view = get_schema_view(
    openapi.Info(
        title="Sidadun API",
        default_version='1.0.0',
        description="Sidadun API清單",
        terms_of_service="http://swagger.io/terms/",
        contact=openapi.Contact(
            name="API Support", email="Jenny.CY.Chiu@auo.com"),
        license=openapi.License(name="BSD License")
    ),
    public=True,
    permission_classes=(permissions.AllowAny,),
)

urlpatterns = [
    url(r'^swagger(?P<format>\.json|\.yaml)$', schema_view.without_ui(cache_timeout=0), name='schema-json'),
    url(r'^swagger/$', schema_view.with_ui('swagger', cache_timeout=0), name='schema-swagger-ui'),
    url(r'^redoc/$', schema_view.with_ui('redoc', cache_timeout=0), name='schema-redoc'),
    url(r'^GetHeatmap$', HeatmapMainlistView.as_view()),
    url(r'^GetAreaVisitor$', AreaVisitorMainlistView.as_view()),
    url(r'^GetAllArea$', AreaMainlistView.as_view()),
    url(r'^GetAreaById/(?P<id>\w+)$', AreaMainlist_Id.as_view()),
    url(r'^GetAllVisitor$', VisitorMainlistView.as_view()),
    url(r'^GetVisitorById/(?P<id>\w+)$', VisitorMainlist_Id.as_view()),
    url(r'^GetAllAdminister$', AdministerMainlistView.as_view()),
    url(r'^GetAdministerById/(?P<id>\w+)$', AdministerMainlist_Id.as_view()),
    url(r'^CheckPermission$', CheckPermissionView.as_view()),
]