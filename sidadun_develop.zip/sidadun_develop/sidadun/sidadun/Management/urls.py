from django.urls import path
from Management import views


urlpatterns = [
    path('Admin', views.Admin, name='Admin'),
    path('Area', views.Area, name='Area'),
    path('Visitor', views.Visitor, name='Visitor'),
    path('Live', views.Live, name='Live'),
]