class MelsecA1ENet(NetworkDeviceBase):
    '''三菱PLC通讯协议，采用A兼容1E帧协议实现，使用二进制码通讯，请根据实际型号来进行选取'''
    PLCNumber = 0xFF
    def __init__(self,ipAddress= "127.0.0.1",port = 0):
        '''实例化一个三菱的A兼容1E帧协议的通讯对象'''
        self.iNetMessage = MelsecA1EBinaryMessage()
        self.byteTransform = RegularByteTransform()
        self.ipAddress = ipAddress
        self.port = port
        self.WordLength = 1
    @staticmethod
    def BuildReadCommand(address,length,plcNumber):
        '''根据类型地址长度确认需要读取的指令头'''
        analysis = MelsecHelper.McA1EAnalysisAddress( address )
        if analysis.IsSuccess == False : return OperateResult.CreateFailedResult( analysis )
        
        subtitle = 0
        if analysis.Content1.DataType == 0x01:
            subtitle = 0x00
        else:
            subtitle = 0x01

        _PLCCommand = bytearray(12)
        _PLCCommand[0]  = subtitle                               # 副标题
        _PLCCommand[1]  = plcNumber                              # PLC编号
        _PLCCommand[2]  = 0x0A                                   # CPU监视定时器（L）这里设置为0x00,0x0A，等待CPU返回的时间为10*250ms=2.5秒
        _PLCCommand[3]  = 0x00                                   # CPU监视定时器（H）
        _PLCCommand[4]  = analysis.Content2 % 256                # 起始软元件（开始读取的地址）
        _PLCCommand[5]  = analysis.Content2 // 256
        _PLCCommand[6]  = 0x00
        _PLCCommand[7]  = 0x00
        _PLCCommand[8]  = analysis.Content1.DataCode[1]          # 软元件代码（L）
        _PLCCommand[9]  = analysis.Content1.DataCode[0]          # 软元件代码（H）
        _PLCCommand[10] = length % 256                           # 软元件点数
        _PLCCommand[11] = 0x00

        return OperateResult.CreateSuccessResult( _PLCCommand )
    @staticmethod
    def BuildWriteCommand( address,value,plcNumber):
        '''根据类型地址以及需要写入的数据来生成指令头'''
        analysis = MelsecHelper.McA1EAnalysisAddress( address )
        if analysis.IsSuccess == False : return OperateResult.CreateFailedResult( analysis )
        
        length = -1
        if analysis.Content1.DataType == 1:
            # 按照位写入的操作，数据需要重新计算
            length2 =  len(value) // 2 + 1
            if len(value) % 2 == 0 : 
                length2 = len(value) // 2
            buffer = bytearray(length2)

            for i in range(length2):
                if value[i * 2 + 0] != 0x00 :
                    buffer[i] += 0x10
                if (i * 2 + 1) < len(value) :
                    if value[i * 2 + 1] != 0x00 :
                        buffer[i] += 0x01
            length = len(value)
            value = buffer

        subtitle = 0
        if analysis.Content1.DataType == 0x01:
            subtitle = 0x02
        else:
            subtitle = 0x03
        
        _PLCCommand = bytearray(12 + len(value))
        _PLCCommand[0]  = subtitle                               # 副标题
        _PLCCommand[1]  = plcNumber                              # PLC编号
        _PLCCommand[2]  = 0x0A                                   # CPU监视定时器（L）这里设置为0x00,0x0A，等待CPU返回的时间为10*250ms=2.5秒
        _PLCCommand[3]  = 0x00                                   # CPU监视定时器（H）
        _PLCCommand[4]  = analysis.Content2 % 256                # 起始软元件（开始读取的地址）
        _PLCCommand[5]  = analysis.Content2 // 256
        _PLCCommand[6]  = 0x00
        _PLCCommand[7]  = 0x00
        _PLCCommand[8]  = analysis.Content1.DataCode[1]          # 软元件代码（L）
        _PLCCommand[9]  = analysis.Content1.DataCode[0]          # 软元件代码（H）
        _PLCCommand[10] = length % 256                           # 软元件点数
        _PLCCommand[11] = 0x00

        # 判断是否进行位操作
        if analysis.Content1.DataType == 1:
            if length > 0:
                _PLCCommand[10] = length % 256                   # 软元件点数
            else:
                _PLCCommand[10] = len(value) * 2 % 256           # 软元件点数
        else:
            _PLCCommand[10] = len(value) // 2 % 256              # 软元件点数
        _PLCCommand[12:] = value

        return OperateResult.CreateSuccessResult( _PLCCommand )
    @staticmethod
    def ExtractActualData( response, isBit ):
        ''' 从PLC反馈的数据中提取出实际的数据内容，需要传入反馈数据，是否位读取'''
        if isBit == True:
            # 位读取
            Content = bytearray((len(response) - 2) * 2)
            i = 2
            while i < len(response):
                if (response[i] & 0x10) == 0x10:
                    Content[(i - 2) * 2 + 0] = 0x01
                if (response[i] & 0x01) == 0x01:
                    Content[(i - 2) * 2 + 1] = 0x01
                i = i + 1

            return OperateResult.CreateSuccessResult( Content )
        else:
            # 字读取
            return OperateResult.CreateSuccessResult( response[2:] )
    def Read( self, address, length ):
        '''从三菱PLC中读取想要的数据，返回读取结果'''
        # 获取指令
        command = MelsecA1ENet.BuildReadCommand( address, length, self.PLCNumber )
        if command.IsSuccess == False :
            return OperateResult.CreateFailedResult( command )

        # 核心交互
        read = self.ReadFromCoreServer( command.Content )
        if read.IsSuccess == False : return OperateResult.CreateFailedResult( read )

        # 错误代码验证
        errorCode = read.Content[1]
        if errorCode != 0 : return OperateResult(err=errorCode, msg=StringResources.MelsecPleaseReferToManulDocument())

        # 数据解析，需要传入是否使用位的参数
        return MelsecA1ENet.ExtractActualData( read.Content, command.Content[0] == 0x00 )
    def ReadBool( self, address, length = None ):
        '''从三菱PLC中批量读取位软元件，返回读取结果'''
        if length == None:
            read = self.ReadBool(address,1)
            if read.IsSuccess == False:
                return OperateResult.CreateFailedResult(read)
            else:
                return OperateResult.CreateSuccessResult(read.Content[0])
        else:
            # 解析地址
            analysis = MelsecHelper.McA1EAnalysisAddress( address )
            if analysis.IsSuccess == False : 
                return OperateResult.CreateFailedResult( analysis )

            # 位读取校验
            if analysis.Content1.DataType == 0x00 : 
                return OperateResult( msg = StringResources.MelsecReadBitInfo() )

            # 核心交互
            read = self.Read( address, length )
            if read.IsSuccess == False : 
                return OperateResult.CreateFailedResult( read )

            # 转化bool数组
            content = []
            for i in range(length):
                if read.Content[i] == 0x01:
                    content.append(True)
                else:
                    content.append(False)
            return OperateResult.CreateSuccessResult( content )
    def Write( self, address, value ):
        '''向PLC写入数据，数据格式为原始的字节类型'''
        # 解析指令
        command = MelsecA1ENet.BuildWriteCommand( address, value, self.PLCNumber )
        if command.IsSuccess == False : return command

        # 核心交互
        read = self.ReadFromCoreServer( command.Content )
        if read.IsSuccess == False : return read

        # 错误码校验
        errorCode = read.Content[1]
        if errorCode != 0 : return OperateResult(err=errorCode, msg=StringResources.MelsecPleaseReferToManulDocument())

        # 成功
        return OperateResult.CreateSuccessResult( )
    def WriteBool( self, address, values ):
        '''向PLC中位软元件写入bool数组或是值，返回值说明，比如你写入M100,values[0]对应M100'''
        if type(values) == list:
            buffer = bytearray(len(values))
            for i in range(len(values)):
                if values[i] == True:
                    buffer[i] = 0x01
            return self.Write(address, buffer)
        else:
            return self.Write(address,[values])