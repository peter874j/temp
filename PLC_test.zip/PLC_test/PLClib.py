import socket
import numpy as np
import configparser


class PLC():
    def __init__(self,HOST,PORT):
        self.HOST = HOST
        self.PORT = PORT
        self.client = socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
        
    def get(self,register,start,length):
        message = bytearray(b'\x50\x00\x00\xFF\xFF\x03\x00\x0C\x00\x00\x00\x01\x04\x00\x00')
        register = register.upper()
        if register == 'D':
            deviceCode=0xA8
            dataType="word"
        elif register == 'M':
            deviceCode=0x90
            dataType="bit"
        elif register == 'X':
            deviceCode=0x9C
            dataType="bit"
        elif register == 'Y':
            deviceCode=0x9D
            dataType="bit"
        else:
            raise Exception('Does not support register type '+str(register)+'.')
            
        if dataType =="word":
            message[13] = 0 #change subcommand
        elif dataType =="bit":
            message[13] = 1
            
        startB = bytearray(start.to_bytes(3,'little'))
        lengthB = bytearray(length.to_bytes(2,'little'))
        message += startB
        message.append(deviceCode)
        message += lengthB
        self.client.sendto(message,(self.HOST,self.PORT))
        #print("con")
        response = self.client.recv(1024)
        response = list(response)
        response = np.array(response)
        if dataType =="word":
            focus = response[11:11+length*2]
            data = focus[1::2]*256+focus[0::2]
        elif dataType =="bit":
            focus = response[11:11+length]
            data=[]
            for i in focus:
                data.append(i>>4)
                data.append(i&0xF)
        return data
    
    def set(self,register,start,length,value):
        value=np.array(value)
        message = bytearray(b'\x50\x00\x00\xFF\xFF\x03\x00\x0C\x00\x00\x00\x01\x14\x00\x00')
        register=register.upper()
        if register == 'D':
            deviceCode=0xA8
            dataType="word"
        elif register == 'M':
            deviceCode=0x90
            dataType="bit"
        elif register == 'X':
            deviceCode=0x9C
            dataType="bit"
        elif register == 'Y':
            deviceCode=0x9D
            dataType="bit"
        else:
            raise Exception('Does not support register type '+str(register)+'.')
            
        data=bytearray()
        if dataType =="word":
            message[13]=0 #change subcommand
            for v in value:
                data.append(v&0xFF)
                data.append(v>>8)
        elif dataType =="bit":
            message[13]=1
            value=value[0::2]*16+value[1::2]
            for v in value:
                data.append(v)
        startB = bytearray(start.to_bytes(3,'little'))
        lengthB = bytearray(length.to_bytes(2,'little'))
        message+=startB
        message.append(deviceCode)
        message+=lengthB
        message+=data
        dataLen=len(message)-9  #trasmit total length after index 8
        message[7]=dataLen&0xFF 
        message[8]=dataLen>>8
        self.client.sendto(message,(self.HOST,self.PORT))
        response = self.client.recv(1024)
        response = list(response)
    
if __name__=="__main__":

    parser = configparser.ConfigParser()
    parser.read('./setting_RW.cfg')
    ### section names
    __source = parser['Source']
    __read = parser['Read']
    __write = parser['Write']
    ### PLC HOST = "192.168.1.3"
    host = __source['host']
    port = int(__source['port'])
    readReg1 = __read['reg_1']
    readReg2 = __read['reg_2']
    writeReg1 = __write['reg_1']
    writeReg2 = __write['reg_2']
    value1 = int(__write['value_1'])
    value2 = int(__write['value_2'])
    print(f"PLC IP: {host}:{port}")
    print(f"Read Registers: {readReg1}, {readReg2}")
    print(f"Write Registers/value: {writeReg1}/{value1}, {writeReg2}/{value2}")

    PLCObject = PLC(host, port)

    # PLCObject.set(register=writeReg1[0], start=int(writeReg1[1:]), length=1, value=[value1])
    # PLCObject.set(register=writeReg2[0], start=int(writeReg2[1:]), length=1, value=[value2])

    while True:
        data1 = PLCObject.get(register=readReg1[0], start=int(readReg1[1:]), length=1)
        print(f"【Read Test】{readReg1}:{data1}")
        data2 = PLCObject.get(register=readReg2[0], start=int(readReg2[1:]), length=1)
        print(f"【Read Test】{readReg2}:{data2}")
