# from HslCommunication import MelsecMcNet
from HslCommunication import MelsecA1ENet
from HslCommunication import SoftBasic
import configparser

def printReadResult(result):
    if result.IsSuccess:
        content = result.Content
        print(f"{str(result)} value type: {type(content)}")
        print(f"{str(result)} value content: {content}")
    else:
        print("read failed   "+result.Message)


if __name__ == "__main__":
    parser = configparser.ConfigParser()
    parser.read('./setting_RW.cfg')
    ### section names
    __source = parser['Source']
    __read = parser['Read']
    __write = parser['Write']
    ### PLC HOST = "192.168.1.3"
    host = __source['host']
    port = int(__source['port'])
    readReg1 = __read['reg_1']
    readReg2 = __read['reg_2']
    writeReg1 = __write['reg_1']
    writeReg2 = __write['reg_2']
    value1 = int(__write['value_1'])
    value2 = int(__write['value_2'])
    print(f"PLC IP: {host}:{port}")
    print(f"Read Registers: {readReg1}, {readReg2}")
    print(f"Write Registers/value: {writeReg1}/{value1}, {writeReg2}/{value2}")

    logPath = r".\testlogs.txt"
    # print(SoftBasic.GetUniqueStringByGuidAndRandom())
    SoftBasic.GetUniqueStringByGuidAndRandom()
    melsecNet = MelsecA1ENet(host, port)
    connect = melsecNet.ConnectServer()
    if connect.IsSuccess == False:
        text = f"{host}:{port} Connect falied... \n"
        print(text)
        with open(logPath, 'a+') as f:
            f.write(text)
    else:
        text = f"{host}:{port} Connection successful... "
        print(text)
        with open(logPath, 'a+') as f:
            f.write(text)
        
        ### int16 read test
        print("int16 read test...")
        print(f"1. read the value from: {readReg1}")
        printReadResult(melsecNet.ReadInt16(readReg1))

        print(f"2. read the value from: {readReg2}")
        printReadResult(melsecNet.ReadInt16(readReg2))
        
        ### int16 write test
        # print("int16 write test...")
        # print(f"1. write the value {value1} to {writeReg1}")
        # melsecNet.WriteInt16(writeReg1, value1)
        # printReadResult(melsecNet.ReadInt16(writeReg1))

        # print(f"2. write the value {value2} to {writeReg2}")
        # melsecNet.WriteInt16(writeReg2, value2)
        # printReadResult(melsecNet.ReadInt16(writeReg2))

        melsecNet.ConnectClose()