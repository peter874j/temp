from rest_framework import serializers
from .models import *
from django.contrib.auth.models import User


class HeatmapMainlistSerializer(serializers.ModelSerializer):
    class Meta:
        model = Heatmap_mainlist
        fields = "__all__"


class AreaVisitorMainlistSerializer(serializers.ModelSerializer):
    class Meta:
        model = AreaVisitor_mainlist
        fields = "__all__"


class AreaMainlistSerializer(serializers.ModelSerializer):
    class Meta:
        model = Area_mainlist
        fields = "__all__"


class VisitorMainlistSerializer(serializers.ModelSerializer):
    class Meta:
        model = Visitor_mainlist
        fields = "__all__"


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ('username', 'password')


# class AdministerMainlistSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = Administer_mainlist
#         fields = "__all__"