var info = new Vue({
    el: "#info",
    data: {
        isDisplay: false
    }
})

var app = new Vue({
    el: "#app",
    data: {
        TableSetting: {},
        AdministerTable: {},
        AdministerData: [],
        AdminDetail: {
            username: null,
            password: null,
            superuser: null
        },
        Permission: 0, // 預設0沒權限
    },
    created: function () {
        this.init();
    },
    methods: {
        init: async function () {
            // console.log('帳號列表');
            let self = this;
            await self.LoadAdministerList();
            await self.InitTable();
            await self.CheckPermission();
        },
        getCookie(cookieName) {
            var name = cookieName + "=";
            var ca = document.cookie.split(';');
            for (var i = 0; i < ca.length; i++) {
                var c = ca[i];
                while (c.charAt(0) == ' ') c = c.substring(1);
                if (c.indexOf(name) == 0) return c.substring(name.length, c.length);
            }
            return "";
        },
        async InitTable() {
            let self = this;
            self.TableSetting = {
                height: "600px",
                layout: "fitColumns",
                pagination: "local",
                paginationSize: 15,
                paginationSizeSelector: [15, 30, 45],
                data: self.AdministerData,
                columns: [{
                        title: "No",
                        field: "id",
                        sorter: "number",
                        visible: false,
                        vertAlign: "middle"
                    },
                    {
                        title: "姓名",
                        field: "username",
                        vertAlign: "middle",
                        bottomCalc: function (values, data, calcParams) {
                            var calc = 0;
                            values.forEach(function (value) {
                                if (value != '') {
                                    calc++;
                                }
                            });
                            return '共 ' + calc.toString() + ' 位';
                        }
                    },
                    {
                        title: "管理員權限",
                        field: "is_superuser",
                        vertAlign: "middle",
                        formatter: function (cell, formatterParams, onRendered) {
                            var value = cell.getValue();
                            if (value == true) {
                                return '<i class="fa fa-check text-success" aria-hidden="true"></i>'
                            } else {
                                return '<i class="fa fa-times text-danger" aria-hidden="true"></i>'
                            }
                        },
                    },
                    {
                        title: "新增時間",
                        field: "date_joined",
                        vertAlign: "middle",
                        formatter: function (cell, formatterParams, onRendered) {
                            var dateStr = cell.getValue();
                            var date = dateStr.split('T')[0];
                            var time = dateStr.split('T')[1].substr(0, 8);
                            return date + " " + time;
                        },
                    },
                    // {
                    //     title: "編輯",
                    //     field: "edit",
                    //     vertAlign: "middle",
                    //     width: "100",
                    //     formatter: function (cell, formatterParams, onRendered) {
                    //         var editBtn =
                    //             '<button type="button" class="btn mb-1 btn-info btn-sm" style="border-color: #866E61; background-color: #866E61;" data-toggle="modal" data-target="#AdminDetailModal">\
                    //                 <i class="fa fa-pencil-square-o"></i></button>'
                    //         return editBtn
                    //     },
                    //     cellClick: function (e, cell) {
                    //         self.editAdminClick(e, cell);
                    //     },
                    //     visible: true,
                    // },
                    {
                        title: "刪除",
                        field: "delete",
                        width: "100",
                        vertAlign: "middle",
                        formatter: function (cell, formatterParams, onRendered) {
                            var deleteBtn =
                                '<button type="button" class="btn mb-1 btn-danger btn-sm">\
                                    <i class="fa fa-trash"></i></button>'
                            return deleteBtn
                        },
                        cellClick: function (e, cell) {
                            self.deleteAdministerClick(e, cell);
                        },
                        visible: true,
                    }
                ]
            }
            self.AdministerTable = new Tabulator("#AdministerTable", self.TableSetting);
        },
        async LoadAdministerList() {
            // console.log('載入帳號資料');
            let self = this;
            await axios.get('../API/GetAllAdminister')
                .then((response) => {
                    // console.log('GetAllAdminister:', response.data);
                    self.AdministerData = response.data;
                    // console.log('1-init', self.AdministerData);
                })
                .catch((error) => {
                    console.log('GetAllAdminister error -', error);
                });
        },
        async AddAdminister() {
            let self = this;
            // console.log('新增帳號');

            Swal.fire({
                title: '新增帳號資訊',
                icon: 'info',
                stopKeydownPropagation: false,
                html: '<div class="input-group mb-3">' +
                    '<div class="input-group-prepend">' +
                    '<span class="input-group-text">帳號</span>' +
                    '</div>' +
                    '<input type="text" class="form-control" id="username">' +
                    '</div>' +
                    '<div class="input-group mb-3">' +
                    '<div class="input-group-prepend">' +
                    '<span class="input-group-text">密碼</span>' +
                    '</div>' +
                    '<input type="text" class="form-control" id="password">' +
                    '</div>' +
                    '<div class="input-group mb-3">' +
                    '<div class="input-group-prepend">' +
                    '<span class="input-group-text">管理員權限</span>' +
                    '</div>' +
                    '<select class="form-control" id="superuser">' +
                    '<option value="True">是</option>' +
                    '<option value="False" selected>否</option>' +
                    '</select>' +
                    '</div>',
                showCloseButton: true,
                showCancelButton: true,
                focusConfirm: false,
                confirmButtonColor: '#866E61',
                confirmButtonText: '<i class="fa fa-check"> 新增</i>',
                cancelButtonText: '<i class="fa fa-times"> 取消</i>',
                preConfirm: () => {
                    const username = Swal.getPopup().querySelector('#username').value
                    const password = Swal.getPopup().querySelector('#password').value
                    const superuser = Swal.getPopup().querySelector('#superuser').value
                    if (!username || !password || !superuser) {
                        Swal.showValidationMessage(`請輸入帳號、密碼及權限`)
                    }
                    return {
                        username: username,
                        password: password,
                        superuser: superuser
                    }
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    var administer_data = {
                        username: document.getElementById('username').value,
                        password: document.getElementById('password').value,
                        superuser: document.getElementById('superuser').value
                    }
                    axios.post('../API/GetAllAdminister', administer_data, {
                            headers: {
                                'X-CSRFToken': self.getCookie('csrftoken')
                            }
                        })
                        .then((response) => {
                            if (response.status == 201) {
                                Swal.fire({
                                    title: "帳號新增成功",
                                    icon: "success",
                                    html: '<span>使用者帳號：' + administer_data.username + '</span></br>' + '<span>管理員權限：' + administer_data.superuser
                                }).then((result) => {
                                    if (result.isConfirmed) {
                                        self.AdministerTable.replaceData([]);
                                        axios.get('../API/GetAllAdminister')
                                            .then((response) => {
                                                self.AdministerData = response.data;
                                                self.AdministerTable.addData(response.data);
                                            })
                                            .catch((error) => {
                                                console.log('GetAllAdminister error -', error);
                                            });
                                    }
                                })
                            }
                        })
                        .catch((error) => {
                            console.log('GetAllAdminister error - ', error);
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: '帳號新增失敗'
                            });
                        });
                }
            })
        },
        async CheckPermission() {
            let self = this;
            axios.get('../API/CheckPermission/' + self.getCookie('name'))
                .then((response) => {
                    var Permission = response.data
                    console.log('CheckPermission:', Permission);
                    if (Permission === true) {
                        self.Permission = 1;
                    } else {
                        self.Permission = 0;
                    }
                })
        },
        async deleteAdministerClick(e, cell) {
            let self = this;
            if (self.Permission == 1) {
                var row = cell.getRow();
                var cell_id = row.getCell('id').getValue();
                var cell_name = row.getCell('username').getValue();
                console.log('帳號 刪除 id=' + cell_id);

                const swalWithBootstrapButtons = Swal.mixin({
                    customClass: {
                        confirmButton: 'btn btn-success',
                        cancelButton: 'btn btn-danger'
                    },
                    buttonsStyling: false
                })

                Swal.fire({
                    title: '確定刪除此帳號嗎？',
                    text: cell_name,
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: '刪除',
                    cancelButtonText: '取消',
                    showClass: {
                        popup: 'animate__animated animate__fadeInDown'
                    },
                    hideClass: {
                        popup: 'animate__animated animate__fadeOutUp'
                    }
                }).then((result) => {
                    if (result.isConfirmed) {
                        axios.delete('../API/GetAdministerById/' + cell_id, {
                            headers: {
                                'X-CSRFToken': self.getCookie('csrftoken')
                            }
                        }).then(() =>
                            swalWithBootstrapButtons.fire({
                                icon: 'success',
                                title: 'Deleted',
                                text: '帳號刪除成功'
                            })
                            .then((result) => {
                                if (result.isConfirmed) {
                                    self.AdministerTable.replaceData([]);
                                    axios.get('../API/GetAllAdminister')
                                        .then((response) => {
                                            self.AdministerData = response.data;
                                            self.AdministerTable.addData(response.data);
                                        })
                                        .catch((error) => {
                                            console.log('GetAllAdminister error -', error);
                                        });
                                }
                            })
                        );
                    } else if (result.dismiss === Swal.DismissReason.cancel) {
                        swalWithBootstrapButtons.fire(
                            'Cancelled',
                            '取消刪除',
                            'info'
                        );
                    }
                })
            } else {
                Swal.fire({
                    icon: 'info',
                    title: '無刪除權限',
                    html: '若須刪除請洽管理員'
                })
            }
        },
        async editAdminClick(e, cell) {
            let self = this;
            var row = cell.getRow();
            var cell_id = row.getCell('id').getValue();
            self.ClickCellid = cell_id;
            console.log('帳號 編輯 id=' + cell_id);

            await axios.get('../API/GetAdministerById/' + cell_id)
                .then((response) => {
                    console.log('(Edit) GetAdministerById:', response.data);
                    var Detail = response.data[0];
                    self.AdminDetail.username = Detail['username']
                    self.AdminDetail.password = Detail['password']
                    if (Detail['is_superuser'] === true) {
                        self.AdminDetail.superuser = 'True'
                    } else if (Detail['is_superuser'] === false) {
                        self.AdminDetail.superuser = 'False'
                    }
                })
                .catch((error) => {
                    console.log('GetAdministerById error -', error);
                });
        },
    }
});