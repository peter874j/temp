from codecs import utf_16_be_decode
import pymysql, datetime, math
from datetime import date
from itertools import chain
from django.http import Http404
from django.db import connection
from django.contrib.auth.models import User
from django.contrib.auth.hashers import make_password, check_password
from django.views.decorators.csrf import csrf_exempt
from rest_framework import views, generics
from rest_framework import status
from rest_framework.response import Response
from drf_yasg.utils import swagger_auto_schema
from API.models import Heatmap_mainlist, AreaVisitor_mainlist
from API.models import Area_mainlist, Visitor_mainlist
from API.serializers import HeatmapMainlistSerializer, AreaVisitorMainlistSerializer 
from API.serializers import AreaMainlistSerializer, VisitorMainlistSerializer, UserSerializer
import datetime
from django.conf import settings


class HeatmapMainlistView(views.APIView):
    @swagger_auto_schema(operation_summary='列出最近一筆熱點資訊')
    def get(self, request):
        queryset = Heatmap_mainlist.objects.order_by('-insert_time')[:1]
        serializer = HeatmapMainlistSerializer(queryset, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
    
    @csrf_exempt
    @swagger_auto_schema(operation_summary='新增熱點資訊')
    def post(self, request, *args, **kwargs):
        serializer = HeatmapMainlistSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)


class AllCountOneWeekView(views.APIView):
    @swagger_auto_schema(operation_summary='列出近一週總人數統計')       
    def get(self, request):
        def day_get(d):
            for i in range(0, 7):
                oneday = datetime.timedelta(days = i)
                day = d - oneday
                date_to = datetime.datetime(day.year, day.month, day.day)
                yield str(date_to)[0:10]
        result = day_get(datetime.datetime.now())        
        list = []
        for obj in result:
            list.append(obj)
        list_week_day = list[::-1]
        # print('list_week_day:', list_week_day)

        tomorrow = datetime.date.today() + datetime.timedelta(days = 1)
        start_y = int(list_week_day[0].split('-')[0])
        start_m = int(list_week_day[0].split('-')[1])
        start_d = int(list_week_day[0].split('-')[2])
        end_y = int(tomorrow.year)
        end_m = int(tomorrow.month)
        end_d = int(tomorrow.day)
        start_date = datetime.date(start_y, start_m, start_d)
        end_date = datetime.date(end_y, end_m, end_d)
        # print(start_date)
        # print(end_date)

        queryset = Heatmap_mainlist.objects.filter(insert_time__range=(start_date, end_date)).values('all_count','insert_time')
        list_queryset = [entry for entry in queryset]
        # print('list_queryset', list_queryset)

        all_count = [int(i['all_count']) for i in list_queryset]
        insert_time = [datetime.datetime.strftime(i['insert_time'],'%Y-%m-%d') for i in list_queryset]
        # print('all_count:', all_count)
        # print('insert_time:', insert_time)
        
        def access_elements(nums, list_index):
            result = [nums[i] for i in list_index]
            return result

        final_count = []
        for u in range(len(list_week_day)):
            pos_lst = [ i for i, e in enumerate(insert_time) if e in list_week_day[u] ]
            # print('pos_lst:', pos_lst)
            if (len(pos_lst) == 0):
                # print('pos_lst len:', len(pos_lst))
                final_count.append(0)
            else:
                all_count_select = access_elements(all_count, pos_lst)
                # print('all_count_select:', all_count_select)
                # print('all_count_max', max(all_count_select))
                final_count.append(max(all_count_select))

        res = {
            'week_day': list_week_day,
            'data': final_count
        }
        return Response(res, status=status.HTTP_200_OK)


class AllCountTwoWeekView(views.APIView):
    @swagger_auto_schema(operation_summary='列出近兩週總人數統計')       
    def get(self, request):
        def day_get(d):
            for i in range(0, 14):
                oneday = datetime.timedelta(days = i)
                day = d - oneday
                date_to = datetime.datetime(day.year, day.month, day.day)
                yield str(date_to)[0:10]
        result = day_get(datetime.datetime.now())        
        list = []
        for obj in result:
            list.append(obj)
        list_week_day = list[::-1]
        # print('list_week_day:', list_week_day)

        tomorrow = datetime.date.today() + datetime.timedelta(days = 1)
        start_y = int(list_week_day[0].split('-')[0])
        start_m = int(list_week_day[0].split('-')[1])
        start_d = int(list_week_day[0].split('-')[2])
        end_y = int(tomorrow.year)
        end_m = int(tomorrow.month)
        end_d = int(tomorrow.day)
        start_date = datetime.date(start_y, start_m, start_d)
        end_date = datetime.date(end_y, end_m, end_d)
        # print(start_date)
        # print(end_date)

        queryset = Heatmap_mainlist.objects.filter(insert_time__range=(start_date, end_date)).values('all_count','insert_time')
        list_queryset = [entry for entry in queryset]
        # print('list_queryset', list_queryset)

        all_count = [int(i['all_count']) for i in list_queryset]
        insert_time = [datetime.datetime.strftime(i['insert_time'],'%Y-%m-%d') for i in list_queryset]
        # print('all_count:', all_count)
        # print('insert_time:', insert_time)
        
        def access_elements(nums, list_index):
            result = [nums[i] for i in list_index]
            return result

        final_count = []
        for u in range(len(list_week_day)):
            pos_lst = [ i for i, e in enumerate(insert_time) if e in list_week_day[u] ]
            # print('pos_lst:', pos_lst)
            if (len(pos_lst) == 0):
                # print('pos_lst len:', len(pos_lst))
                final_count.append(0)
            else:
                all_count_select = access_elements(all_count, pos_lst)
                # print('all_count_select:', all_count_select)
                # print('all_count_max', max(all_count_select))
                final_count.append(max(all_count_select))

        res = {
            'week_day': list_week_day,
            'data': final_count
        }
        return Response(res, status=status.HTTP_200_OK)


class AreaVisitorMainlistView(views.APIView):
    @swagger_auto_schema(operation_summary='列出最近一筆各展區人數統計資訊')
    def get(self, request):
        queryset = AreaVisitor_mainlist.objects.order_by('-insert_time')[:1]
        serializer = AreaVisitorMainlistSerializer(queryset, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
    
    @csrf_exempt
    @swagger_auto_schema(operation_summary='新增一筆各展區人數統計資訊')
    def post(self, request, *args, **kwargs):
        serializer = AreaVisitorMainlistSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)


class HotAreaVisitorView(views.APIView):
    @swagger_auto_schema(operation_summary='列出最近一筆熱門展區資訊')
    def get(self, request):
        queryset_visitor = AreaVisitor_mainlist.objects.order_by('-insert_time')[:1].values('area', 'count')
        list_queryset_visitor = [entry for entry in queryset_visitor]
        count = [i['count'] for i in list_queryset_visitor]
        queryset_area = Area_mainlist.objects.order_by('area_num').values('area_name')
        list_queryset_area = [entry for entry in queryset_area]
        area = [i['area_name'] for i in list_queryset_area]

        for i in range(len(count)):
            count_pre = count[i].replace('"', '').replace('[', '').replace(']', '').replace(' ', '')
            count_res = [int(x) for x in count_pre.split(',')]

        def sort_index(lst, rev=True):
            index = range(len(lst))
            s = sorted(index, reverse=rev, key=lambda i: lst[i])
            return s
        
        top_3_idx = sort_index(count_res)[:3]
        # print('top_3_idx:', top_3_idx)

        tmp1 = []
        tmp2 = []
        for i in range(len(top_3_idx)):
            tmp1.append(area[top_3_idx[i]])
            tmp2.append(count_res[top_3_idx[i]])
        now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        final = [tmp1, tmp2, now]
            
        return Response(final, status=status.HTTP_200_OK)


class AreaVisitorAllCountView(views.APIView):
    @swagger_auto_schema(operation_summary='列出各展區人數統計資訊')
    def get(self, request):
        queryset = AreaVisitor_mainlist.objects.values('count')
        list_queryset = [entry for entry in queryset]
        count = [i['count'] for i in list_queryset]

        tmp = []
        for i in range(len(count)):
            u = count[i].replace('"', '').replace('[', '').replace(']', '').replace(' ', '')
            w = [int(x) for x in u.split(',')]
            tmp.append(w)
        
        def transpose(matrix):
            if matrix == None or len(matrix) == 0:
                return []      
            result = [[None for i in range(len(matrix))] for j in range(len(matrix[0]))]
            for i in range(len(matrix[0])):
                for j in range(len(matrix)):
                    result[i][j] = matrix[j][i]       
            return result
        result = transpose(tmp)

        lst_max_value = []
        lst_avg_value = []
        for i in range(len(result)):
            lst_max_value.append(max(result[i]))
            lst_avg_value.append(math.ceil(sum(result[i]) / len(result[i])))

        queryset_area = Area_mainlist.objects.order_by('area_num').values('area_name')
        list_queryset_area = [entry for entry in queryset_area]
        area_name = [i['area_name'] for i in list_queryset_area]

        final = []
        final.append(area_name)
        final.append(lst_max_value)
        final.append(lst_avg_value)
        # print('AreaVisitorAllCount Final:', final)

        return Response(final, status=status.HTTP_200_OK)


class AreaVisitorFilterCountView(generics.ListCreateAPIView):
    queryset = AreaVisitor_mainlist.objects.all().order_by('insert_time')
    serializer_class = AreaVisitorMainlistSerializer

    @swagger_auto_schema(operation_summary='列出特定條件下各展區人數統計資訊')
    def get(self, request):
        queryset = self.queryset
        print('request (insert_time):', self.request.query_params.get('insert_time'))
        print('request (filter_time):', self.request.query_params.getlist('filter_time'))
 
        if ((self.request.query_params.get('insert_time') != None) and (self.request.query_params.get('filter_time') == None)):
            print('Filter 2')
            print('insert_time:', self.request.query_params['insert_time'])
            from_date = self.request.query_params['insert_time']
            gDate = datetime.datetime(int(from_date.split('-')[0]), int(from_date.split('-')[1]), int(from_date.split('-')[2]))
            end_date = str(gDate + datetime.timedelta(days = 1)).split(' ')[0]
            # print('Time Range:', from_date, '~', end_date)
            queryset = AreaVisitor_mainlist.objects.filter(insert_time__range=[from_date, end_date]).values('count', 'insert_time')

            list_queryset = [entry for entry in queryset]
            count = [i['count'] for i in list_queryset]
            print('flat_list:', count)

            tmp = []
            for i in range(len(count)):
                u = count[i].replace('"', '').replace('[', '').replace(']', '').replace(' ', '')
                w = [int(x) for x in u.split(',')]
                tmp.append(w)
            
            def transpose(matrix):
                if matrix == None or len(matrix) == 0:
                    return []      
                result = [[None for i in range(len(matrix))] for j in range(len(matrix[0]))]
                for i in range(len(matrix[0])):
                    for j in range(len(matrix)):
                        result[i][j] = matrix[j][i]       
                return result
            result = transpose(tmp)

            lst_max_value = []
            lst_avg_value = []
            for i in range(len(result)):
                lst_max_value.append(max(result[i]))
                lst_avg_value.append(math.ceil(sum(result[i]) / len(result[i])))

            queryset_area = Area_mainlist.objects.order_by('area_num').values('area_name')
            list_queryset_area = [entry for entry in queryset_area]
            area_name = [i['area_name'] for i in list_queryset_area]

            final = []
            final.append(area_name)
            final.append(lst_max_value)
            final.append(lst_avg_value)
            print('2- AreaVisitorFilterCount Final (insert_time):', final)

        elif ((self.request.query_params.get('insert_time') != None) and (self.request.query_params.get('filter_time') != None)):
            print('Filter 3')
            print('insert_time:', self.request.query_params['insert_time'])
            print('filter_time:', self.request.query_params.getlist('filter_time'))

            all_result = []
            for n in range(len(self.request.query_params.getlist('filter_time'))):
                time_min = self.request.query_params['insert_time'] + ' ' + self.request.query_params.getlist('filter_time')[n].split('-')[0] + ':00'
                time_max = self.request.query_params['insert_time'] + ' ' + self.request.query_params.getlist('filter_time')[n].split('-')[1] + ':59'
                # print('time_min:', time_min)
                # print('time_max:', time_max)
                queryset = AreaVisitor_mainlist.objects.filter(insert_time__range=(time_min, time_max)).values('count', 'insert_time')
                list_queryset = [entry for entry in queryset]
                count = [i['count'] for i in list_queryset]
                all_result.append(count)
            # print('all_result:', all_result)
            flat_list = [item for sublist in all_result for item in sublist]
            print('flat_list:', flat_list)

            tmp = []
            for i in range(len(flat_list)):
                u = flat_list[i].replace('"', '').replace('[', '').replace(']', '').replace(' ', '')
                w = [int(x) for x in u.split(',')]
                tmp.append(w)
            
            def transpose(matrix):
                if matrix == None or len(matrix) == 0:
                    return []      
                result = [[None for i in range(len(matrix))] for j in range(len(matrix[0]))]
                for i in range(len(matrix[0])):
                    for j in range(len(matrix)):
                        result[i][j] = matrix[j][i]       
                return result
            result = transpose(tmp)

            lst_max_value = []
            lst_avg_value = []
            for i in range(len(result)):
                lst_max_value.append(max(result[i]))
                lst_avg_value.append(math.ceil(sum(result[i]) / len(result[i])))

            queryset_area = Area_mainlist.objects.order_by('area_num').values('area_name')
            list_queryset_area = [entry for entry in queryset_area]
            area_name = [i['area_name'] for i in list_queryset_area]

            final = []
            final.append(area_name)
            final.append(lst_max_value)
            final.append(lst_avg_value)
            print('3- AreaVisitorFilterCount Final (insert_time+filter_time):', final)

        return Response(final, status=status.HTTP_200_OK)


class AreaMainlistView(views.APIView):
    @swagger_auto_schema(operation_summary='列出展區清單')
    def get(self, request):
        queryset = Area_mainlist.objects.order_by('area_num')
        serializer = AreaMainlistSerializer(queryset, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
    
    @csrf_exempt
    @swagger_auto_schema(operation_summary='新增展區')
    def post(self, request, *args, **kwargs):
        serializer = AreaMainlistSerializer(data=request.data) 
        queryset_area = Area_mainlist.objects.get_queryset().values('id', 'area_num', 'area_name')
        result_area = [entry for entry in queryset_area]
        result_area_name = [i['area_name'] for i in result_area]

        if (request.data['area_name'] in result_area_name):
            return Response('CONFLICT')
        else:
            serializer.is_valid(raise_exception=True)
            serializer.save()
            return Response(serializer.data)


class AreaMainlist_Id(views.APIView):
    queryset = Area_mainlist.objects.all()
    serializer_class = AreaMainlistSerializer

    def get_object(self, id):
        try:
            return Area_mainlist.objects.get(id=id)
        except Area_mainlist.DoesNotExist:
            raise Http404
    
    @swagger_auto_schema(operation_summary='使用id查詢單筆展區')
    def get(self, request, id):
        if id is None:
            queryset2 = Area_mainlist.objects.get_queryset()
            serializer = AreaMainlistSerializer(queryset2, many=True)
            return Response(serializer.data)
        else:
            queryset2 = Area_mainlist.objects.get_queryset().filter(id=id)
            serializers = AreaMainlistSerializer(queryset2, many=True)
            return Response(serializers.data)
    
    @csrf_exempt
    @swagger_auto_schema(operation_summary='使用id更新展區')
    def patch(self, request, id):
        result = self.get_object(id)
        serializer = AreaMainlistSerializer(result, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    @csrf_exempt
    @swagger_auto_schema(operation_summary='使用id刪除展區')
    def delete(self, request, id):
        result = self.get_object(id)
        result.delete()
        return Response(status=status.HTTP_200_OK)


class VisitorMainlistView(views.APIView):
    @swagger_auto_schema(operation_summary='列出參訪團清單')
    def get(self, request):
        queryset = Visitor_mainlist.objects.all()
        serializer = VisitorMainlistSerializer(queryset, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
    
    @csrf_exempt
    @swagger_auto_schema(operation_summary='新增參訪團')
    def post(self, request, *args, **kwargs):
        serializer = VisitorMainlistSerializer(data=request.data) 
        queryset_visitor = Visitor_mainlist.objects.get_queryset().values('id', 'visitor_name', 'visit_date', 'visit_time')
        result_visitor = [entry for entry in queryset_visitor]
        result_visitor_name = [i['visitor_name'] for i in result_visitor]

        if (request.data['visitor_name'] in result_visitor_name):
            return Response('CONFLICT')
        else:
            serializer.is_valid(raise_exception=True)
            serializer.save()
            return Response(serializer.data)


class VisitorMainlist_Id(views.APIView):
    queryset = Visitor_mainlist.objects.all()
    serializer_class = VisitorMainlistSerializer

    def get_object(self, id):
        try:
            return Visitor_mainlist.objects.get(id=id)
        except Visitor_mainlist.DoesNotExist:
            raise Http404
    
    @swagger_auto_schema(operation_summary='使用id查詢單筆參訪團')
    def get(self, request, id):
        if id is None:
            queryset2 = Visitor_mainlist.objects.get_queryset()
            serializer = VisitorMainlistSerializer(queryset2, many=True)
            return Response(serializer.data)
        else:
            queryset2 = Visitor_mainlist.objects.get_queryset().filter(id=id)
            serializers = VisitorMainlistSerializer(queryset2, many=True)
            return Response(serializers.data)
    
    @csrf_exempt
    @swagger_auto_schema(operation_summary='使用id更新參訪團')
    def patch(self, request, id):
        result = self.get_object(id)
        serializer = VisitorMainlistSerializer(result, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    @csrf_exempt
    @swagger_auto_schema(operation_summary='使用id刪除參訪團')
    def delete(self, request, id):
        result = self.get_object(id)
        result.delete()
        return Response(status=status.HTTP_200_OK)


class VisitorFilterView(generics.ListCreateAPIView):
    queryset = Visitor_mainlist.objects.all().order_by('visit_time')
    serializer_class = VisitorMainlistSerializer
    
    @swagger_auto_schema(operation_summary='依據篩選條件列出參訪團')
    def get_queryset(self):
        queryset = self.queryset
        if self.request.query_params.get('visit_type'):
            # print(self.request.query_params['visit_type'])
            if (self.request.query_params['visit_type'] == 'all'):
                queryset = queryset.filter(visit_type__in=['學校','企業'])
            else:
                queryset = queryset.filter(visit_type=self.request.query_params['visit_type'])
        if self.request.query_params.get('visit_goal'):
            # print(self.request.query_params['visit_goal'])
            if (self.request.query_params['visit_goal'] == 'all'):
                queryset = queryset.filter(visit_goal__in=['導覽','自由參觀'])
            else:
                queryset = queryset.filter(visit_goal=self.request.query_params['visit_goal'])
        if self.request.query_params.get('visit_date'):
            # print(self.request.query_params['visit_date'])
            queryset = queryset.filter(visit_date=self.request.query_params['visit_date'])
        return queryset


class AdministerMainlistView(views.APIView):
    @swagger_auto_schema(operation_summary='列出管理員清單')
    def get(self, request):
        queryset = User.objects.get_queryset().values()
        return Response(queryset, status=status.HTTP_200_OK)
    
    @csrf_exempt
    @swagger_auto_schema(operation_summary='新增管理員')
    def post(self, request, *args, **kwargs):
        # print(request.data)
        user = User.objects.create_user(request.data['username'], '', request.data['password'])
        user.is_staff = True
        if (request.data['superuser'] == 'True'):
            user.is_superuser = True
        else:
            user.is_superuser = False
        user.save()
        # add_user = {
        #     'username': request.data['username'],
        #     'password': make_password(request.data['password'])
        # }
        # print('add_user:', add_user)
        # serializer = UserSerializer(data=add_user)
        # if serializer.is_valid():
        #     serializer.save()
        #     return Response(serializer.data, status=status.HTTP_201_CREATED)
        # else:
        #     return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        return Response('OK', status=status.HTTP_201_CREATED)


class AdministerMainlist_Id(views.APIView):
    def get_object(self, id):
        try:
            return User.objects.get(id=id)
        except User.DoesNotExist:
            raise Http404

    @swagger_auto_schema(operation_summary='使用id查詢管理員')
    def get(self, request, id):
        queryset = User.objects.get_queryset().filter(id=id).values()
        result = [entry for entry in queryset]
        password = [i['password'] for i in result][0]
        return Response(queryset, status=status.HTTP_200_OK)

    @csrf_exempt
    @swagger_auto_schema(operation_summary='使用id刪除管理員')
    def delete(self, request, id):
        result = self.get_object(id)
        result.delete()
        return Response(status=status.HTTP_200_OK)


class CheckPermissionView(views.APIView):
    @swagger_auto_schema(operation_summary='管理員權限檢查')
    def get(self, request, username):
        queryset_check = User.objects.filter(username=username).values('is_superuser')
        result = [entry for entry in queryset_check]
        check_is_superuser = [i['is_superuser'] for i in result][0]
        # print('CheckPermission:', check_is_superuser)
        return Response(check_is_superuser, status=status.HTTP_200_OK)