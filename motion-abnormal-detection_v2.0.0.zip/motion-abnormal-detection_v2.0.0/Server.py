from flask import Flask, render_template, Response, request, json, send_file, redirect, url_for
from Camera import Camera, perspective_transform
from Logger import *
from datetime import datetime
import cv2
import copy
import win32api

from Config import SoundSwitch, Frame, ServiceConfig, ConfigType, SrvCfg
from flask_login import LoginManager, UserMixin
from AIModule.SystemDetection import Hands

import sys
sys.path.insert(0, './AIModule/YOLOV5')

app = Flask(__name__)
login_manager = LoginManager()
login_manager.init_app(app)

class User(UserMixin):
    pass

def InitGlbVar():
    global Cam1Frame, Cam2Frame, Cam1AlarmCount, Cam2AlarmCount
    Cam1AlarmCount = 0
    Cam2AlarmCount = 0

def iteratate_cam1_frame(camera, detectionModel):
    global Cam1Frame, Cam1AlarmCount
    
    while True:
        Cam1Frame = camera.get_frame()
        try:
            frame = perspective_transform(Cam1Frame, Frame.cam1ROIPts) #透視變換函數
            frame, judgeFlag = detectionModel.run(frame)
        except:
            judgeFlag = False
        frame = Frame.encode(frame)
        if judgeFlag:
            Cam1AlarmCount += 1
        yield frame

def iteratate_cam2_frame(camera, detectionModel):
    global Cam2Frame, Cam2AlarmCount
    
    while True:
        Cam2Frame = camera.get_frame()
        try:
            frame = perspective_transform(Cam2Frame, Frame.cam2ROIPts) #透視變換函數
            frame, judgeFlag = detectionModel.run(frame)
        except:
            judgeFlag = False
        frame = Frame.encode(frame)
        if judgeFlag:
            Cam2AlarmCount += 1
        yield frame

### 主頁面進入點
@app.route("/entrypoint", methods=['GET'])
def entrypoint():
    Frame.initialize_label() # 子頁面修改label後，要更新model作業區位置
    return render_template("index.html", user_time=system_time_info())

### 跳轉子頁面
@app.route("/sec_page", methods=['GET'])
def second_entrypoint():
    Logger.info("Requested /second_page")
    return render_template("sec_page.html")

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        return render_template("login.html")
    user_id = request.form['user_id']
    if (user_id == SrvCfg.fabID + '_' + 'admin') and (request.form['password'] == 'zn123456'):
        return redirect(url_for('entrypoint'))
    
    win32api.MessageBox(0, "無法識別該用戶帳號及密碼\nThe username or password is not recognized.", "Authentication Error", 0x1000) #4096
    return render_template('login.html')

### 主頁面進入點
@app.route("/initialize_html", methods=['POST'])
def initialize_html():
    if request.method == "POST":
        return json.dumps({'handsSoundSwitch':SoundSwitch.flag['hands']})

### 取得系統時間
@app.route("/now_time.txt")
def system_time_info():
    return datetime.now().strftime("%Y/%m/%d %H:%M:%S")

### 第1個camera的串流含式(手部)
@app.route("/video_feed_1")
def video_feed_1():
    return Response(iteratate_cam1_frame(camera1, CAM1HandsDetection),
		mimetype="multipart/x-mixed-replace; boundary=frame")

### 第2個camera的串流含式(手部)
@app.route("/video_feed_2")
def video_feed_2():
    return Response(iteratate_cam2_frame(camera2, CAM2HandsDetection),
		mimetype="multipart/x-mixed-replace; boundary=frame")

@app.route("/sound_switch", methods=['POST']) 
def sound_switch():
    if request.method == "POST":
        soundType = request.get_json(force=True)
        SoundSwitch.flag[soundType] = not SoundSwitch.flag[soundType]
        return "OK"

### 取得手部狀態的函數，給前端使用(前端會一直呼叫這個函數)
@app.route("/cam1_result", methods=['POST']) 
def cam1_result():
    global Cam1AlarmCount
    if request.method == "POST":
        if Cam1AlarmCount > 0:
            Cam1AlarmCount = Cam1AlarmCount - 1
            return json.dumps(True)
        else:
            return json.dumps(False) 

@app.route("/cam2_result", methods=['POST']) 
def cam2_result():
    global Cam2AlarmCount
    if request.method == "POST":
        if Cam2AlarmCount > 0:
            Cam2AlarmCount = Cam2AlarmCount - 1
            return json.dumps(True)
        else:
            return json.dumps(False) 

@app.route("/currentCam1Frame", methods=['GET'])
def get_currentCam1Frame():
	global Cam1Frame
	frame = copy.deepcopy(Cam1Frame)
	frame = cv2.resize(frame, (int(frame.shape[1]/1.6), int(frame.shape[0]/1.6)), interpolation=cv2.INTER_AREA)
	file_object = Frame.transform_virtual_file(frame)
	return send_file(file_object, mimetype='image/PNG')

@app.route("/currentCam2Frame", methods=['GET'])
def get_currentCam2Frame():
	global Cam2Frame
	frame = copy.deepcopy(Cam2Frame)
	frame = cv2.resize(frame, (int(frame.shape[1]/1.6), int(frame.shape[0]/1.6)), interpolation=cv2.INTER_AREA)
	file_object = Frame.transform_virtual_file(frame)
	return send_file(file_object, mimetype='image/PNG')

### 前端(子頁面)的透視變換
@app.route("/cam1_perspective_transform", methods=['GET', 'POST'])
def cam1_perspective_transform():
    coordinates = ServiceConfig.get_cam1_coordinate()
    warpedImg = perspective_transform(Cam1Frame, coordinates)
    file_object = Frame.transform_virtual_file(warpedImg)
    return send_file(file_object, mimetype='image/PNG')

@app.route("/cam2_perspective_transform", methods=['GET', 'POST'])
def cam2_perspective_transform():
    coordinates = ServiceConfig.get_cam2_coordinate()
    warpedImg = perspective_transform(Cam2Frame, coordinates)
    file_object = Frame.transform_virtual_file(warpedImg)
    return send_file(file_object, mimetype='image/PNG')

### 手部座標點寫入txt
@app.route("/cam1_submit", methods=["POST"])
def cam1_submit():
    if request.method == "POST":
        data = request.get_json(force=True)
        ServiceConfig.write_config(data, ConfigType.cam1)
        return "OK"
    else:
        return "OK"

@app.route("/cam2_submit", methods=["POST"])
def cam2_submit():
    if request.method == "POST":
        data = request.get_json(force=True)
        ServiceConfig.write_config(data, ConfigType.cam2)
        return "OK"
    else:
        return "OK"

### (子頁面)console寫入txt
@app.route("/download_console", methods=["POST"])
def download_console():
    if request.method == "POST":
        data = request.get_json(force=True)
        ServiceConfig.write_config(data['text'], data['consoleType'])    
        return "OK"
    else:
        return "OK" 

### (主、子頁面)console讀取console_config.txt
@app.route("/read_console_config", methods=['POST'])
def read_consoleInfo():
    consoleType = request.get_json(force=True)
    data = ServiceConfig.get_console_config(consoleType)
    return json.dumps(data) 

### (子頁面)讀取 hands_config.txt 資料傳到前端
@app.route("/read_cam1_config", methods=['POST'])
def read_cam1_config():
    if request.method == "POST":
        data = ServiceConfig.get_cam1_coordinate()
        return json.dumps(data)
    else:
        return "OK"

@app.route("/read_cam2_config", methods=['POST'])
def read_cam2_config():
    if request.method == "POST":
        data = ServiceConfig.get_cam2_coordinate()
        return json.dumps(data)
    else:
        return "OK"

if __name__=="__main__":

    ### set parameter
    InitGlbVar()
    
    ### Log Module Config
    Logger.config(
        logTypes=LogType.Console | LogType.File,
        consoleLogConfig=ConsoleLogConfig(
            level=LogLevel.WARNING,
        ),
        fileLogConfig=FileLogConfig(
            level=LogLevel.INFO,
            newline=False,
            dirname=SrvCfg.recordPath,
            suffix="debug",
        )
    )
    

    print("Welcome to AUO Vision Guard V2.0.0...")
    ### 建立檢測模型
    CAM1HandsDetection = Hands(SrvCfg.handsThres1, SrvCfg.handsDegree1, 1)
    CAM2HandsDetection = Hands(SrvCfg.handsThres2, SrvCfg.handsDegree2, 2)
    
    ### 初始化兩個camera
    camera1 = Camera(video_source=SrvCfg.handsSource1)
    camera1.run() # thread 1
    Logger.info(f"Loading camera1 from {SrvCfg.handsSource1}")

    camera2 = Camera(video_source=SrvCfg.handsSource2)
    camera2.run() # thread 2
    Logger.info(f"Loading camera2 from {SrvCfg.handsSource2}")

    ### Build Web Server
    Logger.info("Starting Web Server...")
    app.run(host=SrvCfg.host, port=SrvCfg.port)
