import io
import configparser
from re import A
import numpy as np
from pathlib import Path
import os
from datetime import datetime
import cv2
from PIL import Image

from AIModule.ObjectUtils import BBox

class SoundSwitch:
	flag = {"motion":True, "hands":True}

class ConfigType:
	cam1 = "cam1_config"
	cam2 = "cam2_config"

class SrvCfg:
	_parser = configparser.ConfigParser()
	_parser.read('./config/setting.cfg')

	### section names
	_source = _parser['Source']
	_target = _parser['Target']
	_weights = _parser['Weights']
	_cam1Setting = _parser['CAM1Setting']
	_cam2Setting = _parser['CAM2Setting']
	_sound = _parser['Sound']
	_alarm = _parser['AlarmInfo']
	_fileScheduling = _parser['FileScheduling']

	### items in section
	handsSource1 = _source['CAM1']
	handsSource2 = _source['CAM2']
	port = int(_source['port'])
	host = _source['host']
	recordPath = _target['recordPath']
	handsWeight = _weights['hands']

	eqID = {1:_cam1Setting['eqID'], 2:_cam2Setting['eqID']}
	handsThres1 = int(_cam1Setting['pixels'])
	handsDegree1 = float(_cam1Setting['degree'])
	handsThres2 = int(_cam2Setting['pixels'])
	handsDegree2 = float(_cam2Setting['degree'])

	soundOfHandsAlert = _sound['audio']

	AMSSwitch = _alarm['AMSSwitch']
	fabID = _alarm['fabID']
	process = _alarm['process']
	alarmMessage = _alarm['alarmMessage']

	maxMBSize = int(_fileScheduling['maxMBSize'])
	maxDays = int(_fileScheduling['maxDays'])

class ServiceConfig:

	@staticmethod
	def write_config(data, type):
		dateFormat = "%Y/%m/%d"
		dateText = datetime.now().strftime(dateFormat)
		### 處理hand、motion txt
		if isinstance(data, list):
			with open('config/{}.txt'.format(type), 'w') as f:
				f.write(('\n').join(data)) 
		else:
			### 處理console txt
			dateInfo = dateText.replace('/','')
			savePath = os.path.join(SrvCfg.recordPath, dateInfo) 
			Path(savePath).mkdir(parents=True, exist_ok=True)
			consoleFile = os.path.join(savePath, f'{type}.txt')
			with open(consoleFile, 'a+') as f:
				f.write(data + '\n') 
    #透視變換四個點
	@staticmethod
	def get_cam1_coordinate():
		result = []
		with open('config/{}.txt'.format(ConfigType.cam1), 'r') as f:
			for line in f.readlines():
				temp = line.split(" ")
				result.append([int(temp[0]), int(temp[1])])
			return result
	
	@staticmethod
	def get_cam2_coordinate():
		result = []
		with open('config/{}.txt'.format(ConfigType.cam2), 'r') as f:
			for line in f.readlines():
				temp = line.split(" ")
				result.append([int(temp[0]), int(temp[1])])
			return result

	#獲得console內容
	@staticmethod
	def get_console_config(type):
		date = datetime.now().strftime('%Y%m%d')	
		path = f"{SrvCfg.recordPath}/{date}"
		file = os.path.join(path, f'{type}.txt') 
		Path(f"{SrvCfg.recordPath}/{date}").mkdir(parents=True, exist_ok=True) #建立資料夾
		Path(file).touch() #建立txt
		with open(file, 'r') as f:
			contents = f.readlines()      
			return contents


class Frame:

	cam1ROIPts = ServiceConfig.get_cam1_coordinate() 
	cam2ROIPts = ServiceConfig.get_cam2_coordinate() 

	@staticmethod
	def initialize_label():
		Frame.cam1ROIPts = ServiceConfig.get_cam1_coordinate() 
		Frame.cam2ROIPts = ServiceConfig.get_cam2_coordinate() 

	@staticmethod
	def draw_rectangle_in_zone(frame):
		for BBox in Frame.BBoxInfo:
			pts = np.array([[BBox.pointOfTopLeft.x, BBox.pointOfTopLeft.y], [BBox.pointOfTopRight.x, BBox.pointOfTopRight.y],
			 					[BBox.pointOfBottomLeft.x, BBox.pointOfBottomLeft.y], [BBox.pointOfBottomRight.x, BBox.pointOfBottomRight.y]], np.int32)
			cv2.polylines(frame, [pts], True, (0,0,255), 5)
			cv2.putText(frame, BBox.zoneName, (BBox.pointOfTopLeft.x, BBox.pointOfTopLeft.y), cv2.FONT_HERSHEY_DUPLEX, 2, (0, 255, 255), 3, cv2.LINE_AA)

	@staticmethod
	def transform_virtual_file(frame):
		frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
		frame = Image.fromarray(frame.astype('uint8'))
		file_object = io.BytesIO()
		frame.save(file_object, 'PNG')
		file_object.seek(0)
		return file_object

	@staticmethod
	def encode(frame):
		frame = cv2.imencode('.png', frame)[1].tobytes()
		frame = (b'--frame\r\n'b'Content-Type: image/png\r\n\r\n' + frame + b'\r\n')
		return frame
