import os

os.environ["CUDA_VISIBLE_DEVICES"] = "3"
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

from core.core import core


def main():
    # cam1Path = "rtsp://admin:Auo+84149738@192.168.226.201/profile1"
    # cam2Path = "rtsp://admin:Auo+84149738@192.168.226.202/profile1"
    # cam3Path = "rtsp://admin:Auo+84149738@192.168.226.203/profile1"
    # cam4Path = "rtsp://admin:Auo+84149738@192.168.226.204/profile1"
    cam1Path = r"data\videos\cam1_demo.mp4"
    cam2Path = r"data\videos\cam2_demo.mp4"
    cam3Path = r"data\videos\cam3_demo.mp4"
    cam4Path = r"data\videos\cam4_test_3.mp4"
    # cam1Path = r"data\videos\人流魚眼Demo.avi"
    # cam2Path = r"data\videos\人流魚眼Demo.avi"
    # cam3Path = r"data\videos\人流魚眼Demo.avi"
    # cam4Path = r"data\videos\人流魚眼Demo.avi"
    url = "http://tw100043939.corpnet.auo.com:2022/"  # 最後要加 "/"
    core(
        cam1Path=cam1Path,
        cam2Path=cam2Path,
        cam3Path=cam3Path,
        cam4Path=cam4Path,
        layoutImgPath=r"data\images\layout-blank-new.png",
        heatmapUrl=url + "API/GetHeatmap",
        areaVisitorUrl=url + "API/GetAreaVisitor",
        addAvgTimeUrl=url + "API/GetAllAvgtime",
        ModifyAvgTimeUrl=url + "API/GetAvgtimeByNoid/",  # 最後要加 "/"
        cuda=True,
        visualize=False,
        videoMode=True,
    )


if __name__ == "__main__":
    main()
