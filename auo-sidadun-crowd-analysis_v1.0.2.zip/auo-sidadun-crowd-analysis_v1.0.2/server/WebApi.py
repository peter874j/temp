import requests
import threading
import time
import os


class WebApi:
    def __init__(self, heatmapUrl, areaVisitorUrl, areaNameList, postInerval=0.5) -> None:
        self.heatmapUrl = heatmapUrl
        self.areaVisitorUrl = areaVisitorUrl
        self.areaNameList = areaNameList
        self.postInerval = postInerval
        self.areaVisitorData, self.heatmapData, self.idDict = None, None, None
        self.avgStayTimeDict = dict()
        self.lastTimePost = 0
        self.postThread = threading.Thread(target=self.post_thread)
        self.postThread.start()

    # def post_area_visitor(self, fenceCntDict):
    #     """_summary_

    #     Args:
    #         fenceCnt (_type_): _description_
    #     """
    #     cntList = list()
    #     ### FIXME: YJChou 2023/02/23 查詢對應的區域名稱
    #     for fenceId, fenceCnt in fenceCntDict.items():
    #         cntList.append(fenceCnt)
    #     data = {"area": str(self.areaNameList), "count": str(cntList)}
    #     r = requests.post(self.areaVisitorUrl, data=data)
    #     # print(r)

    # def post_heatmap(self, peopleCount, heatMapData, accCount):
    #     """_summary_

    #     Args:
    #         data (_type_): _description_
    #     """
    #     data = {"all_count": peopleCount, "acc_count": accCount, "data": heatMapData}
    #     r = requests.post(self.heatmapUrl, data=data)
    #     # print(r)

    def post_area_visitor(self, fenceCntDict):
        cntList = list()
        ### FIXME: YJChou 2023/02/23 查詢對應的區域名稱
        for fenceId, fenceCnt in fenceCntDict.items():
            cntList.append(fenceCnt)
        self.areaVisitorData = {"area": str(self.areaNameList), "count": str(cntList)}

    def post_heatmap(self, peopleCount, heatMapData, accCount):
        """_summary_

        Args:
            data (_type_): _description_
        """
        self.heatmapData = {"all_count": peopleCount, "acc_count": accCount, "data": heatMapData}

    def post_id(self, idDict):
        self.idDict = idDict
        return self.avgStayTimeDict

    def post_thread(self):
        ### FIXME:
        self.stayTimeCal = StayTimeCal(maxLen=999)
        while True:
            if self.areaVisitorData is None or self.heatmapData is None:
                time.sleep(0.1)
                continue
            else:
                try:
                    timeNow = time.time()
                    ### 避免頻繁上傳資料
                    if timeNow - self.lastTimePost < self.postInerval:
                        time.sleep(0.1)
                        continue
                    self.lastTimePost = time.time()
                    t1 = time.time()
                    r = requests.post(self.areaVisitorUrl, data=self.areaVisitorData)
                    t2 = time.time()
                    # print("Post areaVisitorUrl finished in {:2f}s".format(t2 - t1))
                    t1 = time.time()
                    r = requests.post(self.heatmapUrl, data=self.heatmapData)
                    t2 = time.time()
                    # print("Post heatmapUrl finished in {:2f}s".format(t2 - t1))
                except Exception as e:
                    print("Post areaVisitorUrl and heatmapUrl Error!")
                    print(e)

                ### 計算各ID停留時間
                entryIdDict, exitIdDict, avgStayTimeDict = self.stayTimeCal.update(self.idDict)
                self.avgStayTimeDict = avgStayTimeDict
                ### FIXME: 待前端API完成
                ### 上傳到前端
                # try:
                #     ### 進入ID
                #     r = requests.post(self., data=entryIdDict)
                #     ### 離開ID
                #     r = requests.post(self., data=exitIdDict)
                # except Exception as e:
                #     print('Post entryIdDict and exitIdDict Error!')
                #     print(e)


class StayTimeCal:
    def __init__(self, maxLen=999, outputFolder=r"data\txt\id_track") -> None:
        """計算各展區平均停留時間

        Args:
            maxLen (int, optional): 各圍籬記錄ID的最大長度 (需大於單一展區最大人數). Defaults to 999.
            outputFolder (str, optional): 輸出資料夾. Defaults to "data\txt".
        """
        self.maxLen = maxLen
        self.outputFolder = outputFolder
        os.makedirs(self.outputFolder, exist_ok=True)
        ### 初始化8個展區
        self.existIdDict, self.resultDict = dict(), dict()
        for fenceNum in list((str(i) for i in range(1, 9))):
            self.existIdDict[fenceNum] = dict()  # 紀錄各展區當前存在ID進入時間
            self.resultDict[fenceNum] = dict()  # 紀錄各展區所有ID進出時間

    def update(self, idDict):
        """計算各ID進出時間"""
        ### 初始化8個展區
        entryIdDict, exitIdDict, avgStayTimeDict = dict(), dict(), dict()
        for fenceNum in list((str(i) for i in range(1, 9))):
            entryIdDict[fenceNum] = dict()  # 紀錄各展區進入的ID
            exitIdDict[fenceNum] = dict()  # 紀錄各展區離開的ID
            avgStayTimeDict[fenceNum] = 0  # maxLen時間區間內的平均停留時間

        for fenceNum, idList in idDict.items():
            ### 沒有記錄過的ID, 記錄進入時間
            for id in idList:
                if id not in self.resultDict[fenceNum].keys():
                    startTime = time.time()
                    self.existIdDict[fenceNum][id] = dict({"startTime": startTime})
                    entryIdDict[fenceNum][id] = dict({"startTime": startTime, "endTime": None, "stayTime": None})
                    self.resultDict[fenceNum][id] = dict({"startTime": startTime, "endTime": None, "stayTime": None})

            ### 消失的ID, 記錄離開時間
            leaveIdList = list()
            for id in self.existIdDict[fenceNum].keys():
                if id not in idList:
                    startTime = self.resultDict[fenceNum][id]["startTime"]
                    endTime = time.time()
                    stayTime = endTime - startTime
                    leaveIdList.append(id)
                    self.resultDict[fenceNum][id] = dict(
                        {"startTime": startTime, "endTime": endTime, "stayTime": stayTime}
                    )
                    exitIdDict[fenceNum][id] = dict({"startTime": startTime, "endTime": endTime, "stayTime": stayTime})

            # 從當前ID列表中移除消失的ID
            for id in leaveIdList:
                self.existIdDict[fenceNum].pop(id)

            ### 刪除超過最大長度的舊資料
            if len(self.resultDict[fenceNum]) > self.maxLen:
                delNum = len(self.resultDict[fenceNum]) - self.maxLen
                while delNum != 0:
                    resultIdDict = list(self.resultDict[fenceNum].keys())
                    for delId in resultIdDict:
                        ### 避免刪到目前存在的ID
                        if delId not in self.existIdDict[fenceNum].keys():
                            self.resultDict[fenceNum].pop(delId)
                            delNum -= 1
                            break
                        ### 所有ID都還存在則不刪除任何資料
                        elif delId == resultIdDict[-1]:
                            delNum = 0

            ### DEVELOP:
            ### 輸出txt & 計算平均停留時間
            stayTimeSum = 0
            file = open(os.path.join(self.outputFolder, "fence_" + fenceNum + ".txt"), "wt")
            for id, idInfo in self.resultDict[fenceNum].items():
                startTime, endTime, stayTime = idInfo["startTime"], idInfo["endTime"], idInfo["stayTime"]

                ### 目標尚未離開, 以目前時間計算
                if stayTime is None:
                    stayTime = time.time() - startTime
                    endTime = "None"

                stayTimeSum += stayTime
                file.write("{} startTime: {}, endTime:{}, stayTime: {:.2f}s\n".format(id, startTime, endTime, stayTime))
            if len(self.resultDict[fenceNum].keys()) != 0:
                avgStayTimeDict[fenceNum] = stayTimeSum / len(self.resultDict[fenceNum].keys())
            else:
                avgStayTimeDict[fenceNum] = 0
            file.write("Average Stay {:.2f}s".format(avgStayTimeDict[fenceNum]))
            file.close()
        return entryIdDict, exitIdDict, avgStayTimeDict


if __name__ == "__main__":
    heatmapUrl = "http://tw100043939.corpnet.auo.com:2022/API/GetHeatmap"
    areaVisitorUrl = "http://tw100043939.corpnet.auo.com:2022/API/GetAreaVisitor"
    webApi = WebApi(
        heatmapUrl=heatmapUrl,
        areaVisitorUrl=areaVisitorUrl,
        areaNameList=["展區1", "展區2", "展區3", "展區4", "展區5", "展區6", "展區7", "展區8"],
    )

    webApi.post_heatmap(peopleCount=1, heatMapData=list((100, 100, 60)), accCount=1)
    webApi.post_area_visitor(fenceCntDict={"1": 1, "2": 1, "3": 37, "4": 2, "5": 4, "6": 3, "7": 0, "8": 0})
