import cv2
import sys
import numpy as np
import time

sys.path.append("./")
from utils.PeopleCount import PeopleCount
from utils.Layout import Layout
from utils.Fence import Fence
from utils.CamCapture import CamCapture
from utils.calibrate import (
    get_layout_region,
    img_distortion_corr,
    point_distortion_corr,
    img_affin_trans,
    point_affin_trans,
)
from utils.StayTracker import StayTracker
from server.WebApi import WebApi
from packages.Rapid import Detector
from packages.ImageProcess import ImageProcess


def draw_pts(img, pts):
    rstImg = img.copy()
    for pt in pts:
        cv2.circle(rstImg, pt, 5, (0, 0, 255), -1)
    return rstImg


def core(
    cam1Path,
    cam2Path,
    cam3Path,
    cam4Path,
    layoutImgPath,
    heatmapUrl,
    areaVisitorUrl,
    addAvgTimeUrl,
    ModifyAvgTimeUrl,
    cuda=True,
    visualize=False,
    videoMode=False,
    nFrame=0,
):
    ##############################################
    ##            初始化
    ##############################################
    frame = 0
    t1 = time.time()
    ### 攝影機初始化
    camCapture = CamCapture(cam1Path, cam2Path, cam3Path, cam4Path, videoMode=videoMode)

    ### RAPiD初始化
    detector = Detector(model_name="rapid", weights_path=r"data\model_weights\best_20230223.ckpt", use_cuda=cuda)

    ### 出入口人流計算區初始化
    ### 畸變校正後座標 (969*969) -> (2160*2160)
    n = 2.23
    cntDict = {
        "1": {"camID": "1", "data": [((390) * n, (447) * n), ((800) * n, (739) * n)]},
        "4": {"camID": "4", "data": [((515) * n, (375) * n), ((895) * n, (620) * n)]},
    }
    peopleCount = PeopleCount(cntDict)

    ### 魚眼矯正矩陣初始化
    mapxList = np.load(r"data\calibrate\matrix\distortion\distortion_corr_matix_mapx.npy")
    mapyList = np.load(r"data\calibrate\matrix\distortion\distortion_corr_matix_mapy.npy")
    distortionCorrMatix = [mapxList, mapyList]
    affinMatrixDict = dict()
    for camId in ["1", "2", "3_1", "3_2"]:
        affinMatrixDict[camId] = np.load(rf"data\calibrate\matrix\affine\cam{camId}_affine_matrix.npy")

    ### 展區圍籬初始化
    ### 畸變校正後座標 (969*969) -> (2160*2160)
    n = 2.23
    fenceDict = {
        "1": {"camID": "1", "data": [(327 * n, 186 * n), ((643) * n, 750 * n)]},
        "2": {"camID": "2", "data": [((190) * n, 169 * n), ((774) * n, (662 - 20) * n)]},
        "3": {"camID": "3_1", "data": [((111 + 50) * n, (223 + 30) * n), (774 * n, 340 * n)]},
        "4": {"camID": "2", "data": [(77 * n, 168 * n), ((170 + 20) * n, (673 + 20) * n)]},
        "5": {"camID": "3_2", "data": [(326 * n, 456 * n), ((810 - 100) * n, 628 * n)]},
        "6": {"camID": "3_2", "data": [(62 * n, (522 - 66) * n), (326 * n, 779 * n)]},
        "7": {"camID": "3_2", "data": [(326 * n, 628 * n), (579 * n, 779 * n)]},
        # "8": {"camID": "3_2", "data": [(594 * n, 636 * n), (860 * n, 784 * n)]},
        "8": {"camID": "4", "data": [((500 - 200) * n, (520 - 200) * n), (773 * n, 740 * n)]},
    }
    fence = Fence(fenceDict)

    ### 各展區人數追蹤初始化
    stayTracker = StayTracker(fenceDict, visualize=visualize)

    ### Layout投影初始化
    layoutImg = cv2.imread(layoutImgPath)
    ### (5216*4106) -> (1044*822)
    n = 0.2
    layoutRegionList = [
        {"CamId": "1", "Point": [(4049 * n, 609 * n), (5030 * n, 2786 * n)]},
        {"CamId": "2", "Point": [(233 * n, 285 * n), (3994 * n, 1956 * n)]},
        {"CamId": "3_1", "Point": [(233 * n, 1956 * n), (4042 * n, 2829 * n)]},
        {"CamId": "3_2", "Point": [(233 * n, 2829 * n), (5034 * n, 4082 * n)]},
    ]
    camIdList = ["1", "2", "3_1", "3_2"]
    layout = Layout(layoutImg, camIdList, layoutRegionList)

    ### 網頁API初始化
    webApi = WebApi(
        heatmapUrl=heatmapUrl, areaVisitorUrl=areaVisitorUrl, areaNameList=["1", "2", "3", "4", "5", "6", "7", "8"]
    )
    print("初始化完成: {:.2f}s".format(time.time() - t1))

    while True:
        frame += 1
        if True:
            ##############################################
            ##            建立攝影機串流
            ##############################################
            t1 = time.time()
            framImg = camCapture.get_frame()
            print("等待影片串流: {:.2f}s".format(time.time() - t1))
            t2 = time.time()

            ##############################################
            ##            RAPiD 模型檢測
            ##############################################
            size = 272  # 272
            pil_img = ImageProcess.cv2pil(framImg)
            pointList, detectImg = detector.detect_one(
                pil_img=pil_img, input_size=size * 2, conf_thres=0.3, return_img=True
            )
            detectImg = cv2.cvtColor(np.array(detectImg, dtype=np.uint8), cv2.COLOR_RGB2BGR)

            detectImgShow = cv2.resize(detectImg, (800, 800))
            cv2.imshow("detectImg", detectImgShow)
            cv2.waitKey(1)

            print("RAPiD 模型檢測: {:.2f}s".format(time.time() - t2))
            t2 = time.time()
            detectImg = cv2.resize(detectImg, (4320, 4320))

        ### 圖片測試
        elif False:
            size = 304
            final_matrix = np.zeros((size * 2, size * 2, 3), np.uint8)
            cam1Img = cv2.imread(r"data\calibrate\fisheye\cam1.jpg")
            cam2Img = cv2.imread(r"data\calibrate\fisheye\cam2.jpg")
            cam3Img = cv2.imread(r"data\calibrate\fisheye\cam3.jpg")
            cam4Img = cv2.imread(r"data\calibrate\fisheye\cam4.jpg")
            camImgList = [cam1Img, cam2Img, cam3Img, cam4Img]

            resizeList = [[1, 2, 0, 1], [0, 1, 0, 1], [0, 1, 1, 2], [1, 2, 1, 2]]
            for i, camImg in enumerate(camImgList):
                resize = cv2.resize(camImg, (size, size))
                x1, x2, y1, y2 = resizeList[i]
                x1, x2, y1, y2 = (
                    size * x1,
                    size * x2,
                    size * y1,
                    size * y2,
                )
                final_matrix[y1:y2, x1:x2] = resize
            framImg = final_matrix

            t2 = time.time()
            ##############################################
            ##            RAPiD 模型檢測
            ##############################################
            size = 304
            pil_img = ImageProcess.cv2pil(framImg)
            pointList, detectImg = detector.detect_one(
                pil_img=pil_img, input_size=size * 2, conf_thres=0.3, return_img=True
            )
            detectImg = cv2.cvtColor(np.array(detectImg, dtype=np.uint8), cv2.COLOR_RGB2BGR)
            if visualize:
                cv2.imshow("detectImg", detectImg)
                cv2.waitKey(1)

            print("RAPiD 模型檢測: {:.2f}s".format(time.time() - t2))
            t2 = time.time()
            detectImg = cv2.resize(detectImg, (4320, 4320))

        ### 假資料
        else:
            pointList = [
                (1041, 1395),
                (1072, 3596),
                (487, 2657),
                (780, 2768),
                (672, 953),
                (933, 3779),
                (1608, 1429),
                (1329, 1388),
                (1674, 1383),
                (1383, 1031),
                (1856, 3407),
                (658, 1340),
                (363, 2696),
                (414, 1046),
                (763, 1353),
                (3373, 956),
                (844, 1502),
                (483, 3570),
                (261, 3387),
                (1186, 1440),
                (1066, 2534),
                (350, 3486),
                (689, 2794),
                (1409, 878),
                (1233, 1268),
                (993, 653),
                (1668, 917),
                (1360, 1225),
                (1243, 1027),
                (1262, 846),
                (1773, 3493),
                (548, 1266),
                (653, 1140),
                (781, 993),
                (899, 1190),
                (692, 826),
                (945, 809),
                (1047, 1203),
                (258, 3421),
                (1103, 786),
                (959, 985),
                (905, 1356),
                (1260, 692),
                (1129, 674),
                (1107, 1010),
                (506, 824),
                (527, 690),
                (642, 650),
                (3836, 993),
                (1529, 658),
                (840, 806),
                (1373, 713),
                (313, 1302),
                (846, 650),
                (945, 3871),
                (602, 812),
                (441, 1188),
                (1895, 3435),
            ]
            detectImg = cv2.imread(r"data\images\sidadun_500_new.jpg")
            if visualize:
                cv2.imshow("Img", detectImg)
                cv2.waitKey(1)

        ##############################################
        ##          4合1大圖切分各攝影機
        ##############################################
        t2 = time.time()
        if True:
            camWidth, camHeight = 2160, 2160
            cam1Img = detectImg[0:camHeight, camWidth:]
            cam2Img = detectImg[0:camHeight, 0:camWidth]
            cam3_1Img = detectImg[camHeight:, 0:camWidth]
            cam3_2Img = detectImg[camHeight:, 0:camWidth]
            cam4Img = detectImg[camHeight:, camWidth:]
            cam1PtsList, cam2PtsList, cam3_1PtsList, cam3_2PtsList, cam4PtsList = list(), list(), list(), list(), list()
            for point in pointList:
                x, y = point
                if x >= 2160 and y < 2160:
                    x, y = x - 2160, y
                    cam1PtsList.append((x, y))
                elif x < 2160 and y < 2160:
                    x, y = x, y
                    cam2PtsList.append((x, y))
                elif x < 2160 and y >= 2160:
                    x, y = x, y - 2160
                    cam3_1PtsList.append((x, y))
                    cam3_2PtsList.append((x, y))
                elif x >= 2160 and y >= 2160:
                    x, y = x - 2160, y - 2160
                    cam4PtsList.append((x, y))

        else:
            ### FIXME: 假資料
            cam1Img = cv2.imread(r"data\calibrate\fisheye\cam1.jpg")
            cam1PtsList = [(900, 1000)]
            cam2Img = cv2.imread(r"data\calibrate\fisheye\cam2.jpg")
            cam2PtsList = [(500, 700)]
            cam3_1Img = cv2.imread(r"data\calibrate\fisheye\cam3.jpg")
            cam3_1PtsList = [(500, 700)]
            cam3_2Img = cv2.imread(r"data\calibrate\fisheye\cam3.jpg")
            cam3_2PtsList = [(1750, 1350)]
            dataDictList = [
                {"CamId": "1", "CamImg": cam1Img, "point": cam1PtsList},
                {"CamId": "2", "CamImg": cam2Img, "point": cam2PtsList},
                {"CamId": "3_1", "CamImg": cam3_1Img, "point": cam3_1PtsList},
                {"CamId": "3_2", "CamImg": cam3_2Img, "point": cam3_2PtsList},
            ]

            if False:
                cam3_2Img = draw_pts(cam3_2Img, cam3_2PtsList)
                cv2.imshow("cam3_2Img", cam3_2Img)

        dataDictList = [
            {"CamId": "1", "CamImg": cam1Img, "point": cam1PtsList},
            {"CamId": "2", "CamImg": cam2Img, "point": cam2PtsList},
            {"CamId": "3_1", "CamImg": cam3_1Img, "point": cam3_1PtsList},
            {"CamId": "3_2", "CamImg": cam3_2Img, "point": cam3_2PtsList},
            {"CamId": "4", "CamImg": cam4Img, "point": cam4PtsList},
        ]

        print("4合1大圖切分各攝影機: {:.2f}s".format(time.time() - t2))
        t2 = time.time()

        ##############################################
        ##            魚眼校正
        ##############################################
        for idx, camData in enumerate(dataDictList):
            camId = camData["CamId"]
            CamImg = camData["CamImg"]
            point = camData["point"]
            ### 畸變矯正
            t3 = time.time()
            imgSize = (CamImg.shape[1], CamImg.shape[0])
            if visualize:
                corrImg = img_distortion_corr(CamImg, distortionCorrMatix)
            else:
                corrImg = None
            corrPoint = point_distortion_corr(point, imgSize, distortionCorrMatix)
            ### 仿設變換
            t4 = time.time()
            # print("畸變矯正: {:.4f}".format(t4 - t3))
            region = get_layout_region(layoutRegionList, camId)
            if region is not None:
                affinMatrix = affinMatrixDict[camId]
                if visualize:
                    affineImg = img_affin_trans(corrImg, region, affinMatrix)
                else:
                    affineImg = None
                affinePoint = point_affin_trans(corrPoint, region, affinMatrix, imgSize)
            else:
                affineImg, affinePoint = None, None
            # print("仿設變換: {:.4f}".format(time.time() - t4))
            dataDictList[idx]["corrImg"] = corrImg
            dataDictList[idx]["corrPoint"] = corrPoint
            dataDictList[idx]["affineImg"] = affineImg
            dataDictList[idx]["affinePoint"] = affinePoint
            dataDictList[idx]["layoutRegion"] = region

        print("魚眼矯正: {:.4f}s,".format((time.time() - t2)))
        t2 = time.time()

        ##############################################
        ##            場館總人數追蹤
        ##############################################
        cntNow, cntDay = peopleCount.count_total_people(dataDictList)

        print("場館總人數追蹤: {:.2f}s".format(time.time() - t2))
        t2 = time.time()

        ### 只有總人數每幀計算
        if nFrame != 0 and not frame % nFrame == 0:
            continue

        ##############################################
        ##            各展區人數計算
        ##############################################

        fenceCntDict = fence.count_fence_people(dataDictList)
        # print(fenceCntDict)
        print("各展區人數計算: {:.2f}s".format(time.time() - t2))
        t2 = time.time()

        ##############################################
        ##            各展區停留時間
        ##############################################
        idDict = stayTracker.people_track(dataDictList)
        print(idDict)
        print("各展區停留時間: {:.2f}s".format(time.time() - t2))
        t2 = time.time()

        ##############################################
        ##            熱力圖 Layout
        ##############################################

        t2 = time.time()
        layoutPoint = layout.fisheyePts2layout(dataDictList)
        if visualize:
            layoutImg = layout.fisheyeImg2layout(dataDictList)
            layoutImg = draw_pts(layoutImg, layoutPoint)
            cv2.imshow("layoutImg", layoutImg)
            cv2.waitKey(1)
        print("輸出熱力圖: {:.2f}s".format(time.time() - t2))
        t2 = time.time()

        ##############################################
        ##            前端串接
        ##############################################
        heatMapData = list()
        if False:
            ### DEVELOP: 假資料
            cntDay = 32  # 當日人次
            cntNow = 15  # 館內總人數

        for point in layoutPoint:
            data = list((point[0], point[1], 60))
            heatMapData.append(data)
        heatMapData = str(heatMapData)
        webApi.post_heatmap(peopleCount=cntNow, heatMapData=heatMapData, accCount=cntDay)
        webApi.post_area_visitor(fenceCntDict=fenceCntDict)
        avgStayTimeDict = webApi.post_id(idDict=idDict)

        print("Post到前端: {:.2f}s".format(time.time() - t2))
        costTime = time.time() - t1
        print("total cost {:.1f}s, FPS: {:.1f}\n".format(costTime, 1 / costTime))
        print("\n" + "=" * 50)
        print(f"館內人數: {cntNow}人, 當日總人次: {cntDay}人")
        for fenceNum in fenceCntDict.keys():
            if fenceNum in avgStayTimeDict.keys():
                avgStayTime = round(avgStayTimeDict[fenceNum], 2)
            else:
                avgStayTime = 0
            print(f"展區{fenceNum}: 目前{fenceCntDict[fenceNum]}人, 平均停留{avgStayTime}s")
        print("=" * 50 + "\n")


if __name__ == "__main__":
    # cam1Path = "rtsp://admin:Auo+84149738@192.168.226.201/profile1"
    # cam2Path = "rtsp://admin:Auo+84149738@192.168.226.202/profile1"
    # cam3Path = "rtsp://admin:Auo+84149738@192.168.226.203/profile1"
    # cam4Path = "rtsp://admin:Auo+84149738@192.168.226.204/profile1"
    core(
        cam1Path=r"data\videos\16_39_56_CAM_172_Monitor.avi",
        cam2Path=r"data\videos\16_39_56_CAM_172_Monitor.avi",
        cam3Path=r"data\videos\16_39_56_CAM_172_Monitor.avi",
        cam4Path=r"data\videos\16_39_56_CAM_172_Monitor.avi",
        layoutImgPath=r"data\images\layout-blank-new.png",
        heatmapUrl="http://localhost:2023/API/GetHeatmap",
        areaVisitorUrl="http://localhost:2023/API/GetAreaVisitor",
    )
