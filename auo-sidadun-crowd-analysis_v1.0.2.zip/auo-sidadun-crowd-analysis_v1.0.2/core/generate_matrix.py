import cv2
import numpy as np
import sys
import os

sys.path.append("./")
from packages.AffineTransform import AffineTransform
from packages.DistortionCorrection import DistortionCorrection


def get_affin_trans_matrix(srcPts, targetPts):
    affineMatrix = AffineTransform.get_matrix(srcPts, targetPts)
    return affineMatrix


def get_cam_distortion_corr_matix(imgPath, matrixSavePath, matrixName, visualize):
    img = cv2.imread(imgPath)
    DistortionCorrection.get_remap_matrix(
        img, mode=3, matrixSavePath=matrixSavePath, matrixName=matrixName, visualize=visualize
    )


def get_all_cam_affin_trans_matrix(matrixSavePath):
    ### 畸變校正後的座標 (969*969) -> (2160*2160)
    n = 2.23
    src = [
        {"CamId": "1", "Point": [(360 * n, 724 * n), (359 * n, 225 * n), (622 * n, 726 * n)]},
        {
            "CamId": "2",
            "Point": [((110) * n, 181 * n), ((785 + 10) * n, 240 * n), ((790) * n, (651-50) * n)],
        },
        {
            "CamId": "3_1",
            "Point": [((97-50) * n * n, 365 * n), ((110-10) * n, (240) * n), ((794-30) * n, 342 * n)],
        },
        {"CamId": "3_2", "Point": [((115 - 10) * n, 473 * n), ((839 + 20) * n, 479 * n), ((817 + 20) * n, (687+80) * n)]},
    ]

    ### Layout座標 (5216*4106) -> (1044*822)
    n = 0.2
    target = [
        {"CamId": "1", "Point": [(0 * n, 2177 * n), (0 * n, 0 * n), (981 * n, 2177 * n)]},
        {"CamId": "2", "Point": [(0 * n, 0 * n), (3761 * n, 0 * n), (3761 * n, 1693 * n)]},
        {"CamId": "3_1", "Point": [(0 * n, 873 * n), (0 * n, 0 * n), (3809 * n, 873 * n)]},
        {"CamId": "3_2", "Point": [(0 * n, 0 * n), (5034 * n, 0 * n), (4801 * n, 1253 * n)]},
    ]

    for i in range(len(src)):
        srcPts = np.float32((src[i]["Point"]))
        targetPts = np.float32(target[i]["Point"])
        CamId = src[i]["CamId"]
        matrix = get_affin_trans_matrix(srcPts, targetPts)
        np.save(os.path.join(matrixSavePath, f"cam{CamId}_affine_matrix.npy"), matrix)


def main():
    get_cam_distortion_corr_matix(
        imgPath=r"data\calibrate\fisheye\cam1.jpg",
        matrixSavePath=r"data\calibrate\matrix\distortion",
        matrixName="distortion_corr_matix",
        visualize=False,
    )
    get_all_cam_affin_trans_matrix(matrixSavePath=r"data\calibrate\matrix\affine")


if __name__ == "__main__":
    main()
