import cv2
import numpy as np
import sys

sys.path.append("./")
from packages.DistortionCorrection import DistortionCorrection


class Fence:
    def __init__(self, fenceDict):
        self.fenceDict = fenceDict
        self.fenceCnt = dict()

    def count_fence_people(self, dataDictList):
        """計算個圍籬區人數

        Args:
            img (_type_): _description_
        """
        for fenceNum, fenceData in self.fenceDict.items():
            self.fenceCnt[fenceNum] = 0
            camId, fenceCord = fenceData["camID"], fenceData["data"]
            ### 畸變校正後座標
            for dataDict in dataDictList:
                if dataDict["CamId"] == camId:
                    corrImg = dataDict["corrImg"]
                    PtsList = dataDict["corrPoint"]
                    break

            for point in PtsList:
                x, y = point[0], point[1]
                if x < fenceCord[0][0] or x > fenceCord[1][0] or y < fenceCord[0][1] or y > fenceCord[1][1]:
                    continue
                self.fenceCnt[fenceNum] += 1

            if False:
                corrImg = cv2.rectangle(
                    corrImg,
                    (int(fenceCord[0][0]), int(fenceCord[0][1])),
                    (int(fenceCord[1][0]), int(fenceCord[1][1])),
                    (0, 255, 0),
                    2,
                )
                # print(f"展區{fenceNum}: {self.fenceCnt[fenceNum]}人")
                corrImg = draw_pts(corrImg, PtsList)
                if int(fenceNum) not in [1, 3,4,7,8]:
                    continue
                corrImg = cv2.resize(corrImg, (corrImg.shape[1] // 2, corrImg.shape[0] // 2))
                cv2.imshow(f"{fenceNum}corrImg", corrImg)
                cv2.waitKey(1)
        return self.fenceCnt


def draw_pts(img, pts):
    rstImg = img.copy()
    for pt in pts:
        cv2.circle(rstImg, pt, 5, (0, 0, 255), -1)
    return rstImg
