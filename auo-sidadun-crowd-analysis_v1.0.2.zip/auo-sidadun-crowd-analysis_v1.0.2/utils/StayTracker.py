import cv2
import sys

sys.path.append("./")
from packages.CentroidTracker import CentroidTracker


class StayTracker:
    def __init__(self, fenceDict, visualize=True):
        self.fenceDict = fenceDict
        self.visualize = visualize
        self.trackerDict = dict()
        self.visualizeImgDict = dict()
        for fenceNum, fenceData in self.fenceDict.items():
            self.trackerDict[fenceNum] = CentroidTracker(maxDisappeared=10)

    def people_track(self, dataDictList):
        idDict = dict()
        for fenceNum, fenceData in self.fenceDict.items():
            # ### debug
            # if fenceNum != "1":
            #     continue
            pointInFence = list()
            idDict[fenceNum] = list()
            camId, fenceCord = fenceData["camID"], fenceData["data"]
            ### 畸變校正後座標
            for dataDict in dataDictList:
                if dataDict["CamId"] == camId:
                    corrImg = dataDict["corrImg"]
                    PtsList = dataDict["corrPoint"]
                    if camId not in self.visualizeImgDict.keys():
                        self.visualizeImgDict[camId] = corrImg
                    break

            ### 過濾不在圍籬區內的座標
            for point in PtsList:
                x, y = point[0], point[1]
                if x < fenceCord[0][0] or x > fenceCord[1][0] or y < fenceCord[0][1] or y > fenceCord[1][1]:
                    continue
                pointInFence.append(point)

            ### 更新追蹤器
            objects = self.trackerDict[fenceNum].update(pointInFence)

            for (objectID, centroid) in objects.items():
                idDict[fenceNum].append(objectID)
                ### visualize
                if self.visualize:
                    ### Visualize
                    cv2.putText(
                        self.visualizeImgDict[camId],
                        str(objectID),
                        tuple((centroid[0], centroid[1])),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        1,
                        (0, 0, 255),
                        1,
                        cv2.LINE_AA,
                    )

        ### visualize
        if self.visualize:
            for camId, visualizeImg in self.visualizeImgDict.items():
                visualizeImg = cv2.resize(visualizeImg, (visualizeImg.shape[1] // 2, visualizeImg.shape[0] // 2))
                cv2.imshow(camId, visualizeImg)
                cv2.waitKey(1)
            self.visualizeImgDict = dict()

        return idDict
