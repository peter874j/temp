### 仿射變換 AffineTransform http://www.juzicode.com/opencv-python-warpaffine-rotate-warpperspective/
"""
@author: YJChou
@modular: YJChou
@time: 2023/02
"""
import numpy as np
import cv2
import sys

sys.path.append("./")
from packages.DistortionCorrection import DistortionCorrection


class Transform:
    def __init__(self, src, target, layoutRegion, calibrateMatrix, layoutSize=(5216, 4106)) -> None:
        """_summary_

        Args:
            src (_type_): 畸變校正後座標
            target (_type_): layout 上的座標
            layoutRegion (_type_): layout上對應的區域
            calibrateMatrix (_type_): 畸變校正矩陣
            layoutSize (tuple, optional): layout尺寸. Defaults to (5216, 4106).
        """
        self.src = src
        self.target = target
        self.layoutRegion = layoutRegion
        self.layoutSize = layoutSize
        self.calibrateMatrix = calibrateMatrix

    def _get_pts(self, setting):
        for cam in setting:
            if cam["CamId"] == self.camId:
                pts = cam["Point"]
                return pts

    def _get_layout_region(self, layoutRegion):
        for cam in layoutRegion:
            if cam["CamId"] == self.camId:
                roi = cam["Point"]
                return roi

    def get_matrix(self, camId):
        self.camId = camId
        srcPts = np.float32(self._get_pts(self.src))
        targetPts = np.float32(self._get_pts(self.target))

        ### Apply Perspective Transform Algorithm
        matrix = cv2.getAffineTransform(srcPts, targetPts)
        return matrix

    def img2layout(self, img, matrix, layout):
        ### 畸變校正
        rstImg = DistortionCorrection.imgCalibration(
            img,
            matrixSavePath=self.calibrateMatrix,
            mapxName="cam_mapx",
            mapyName="cam_mapy",
        )
        # return rstImg
        ### 仿射變換
        roi = self._get_layout_region(self.layoutRegion)
        rstImg = cv2.warpAffine(rstImg, matrix, dsize=(roi[1][0] - roi[0][0], roi[1][1] - roi[0][1]))
        layout[roi[0][1] : roi[1][1], roi[0][0] : roi[1][0]] = rstImg
        return layout

    def point2layout(self, pts, imgSize, matrix):
        ### 畸變校正
        rstPts = DistortionCorrection.ptsCalibration(
            pts,
            imgSize,
            matrixSavePath=self.calibrateMatrix,
            mapxName="cam_mapx",
            mapyName="cam_mapy",
        )
        # return rstPts
        ### 仿射變換
        roi = self._get_layout_region(self.layoutRegion)

        if False:
            rstPts2 = []
            for pt in rstPts:
                rst = np.matrix(matrix) * np.matrix([pt[0], pt[1], 1]).T
                rst = np.array(rst.T)
                a = rst[0][0].tolist()
                b = rst[0][1].tolist()
                rstPts2.append((int(a), int(b)))

        if True:
            canvas = np.zeros((imgSize[1], imgSize[0]), np.uint8)
            for pt in rstPts:
                canvas[pt[1], pt[0]] = 1
                rstcanvas = canvas.copy()
            rstcanvas = cv2.warpAffine(rstcanvas, matrix, dsize=(roi[1][0] - roi[0][0], roi[1][1] - roi[0][1]))

            layoutCanvus = np.zeros((self.layoutSize[1], self.layoutSize[0]), np.uint8)
            layoutCanvus[roi[0][1] : roi[1][1], roi[0][0] : roi[1][0]] = rstcanvas

            rstPts = [
                (layoutCanvus.nonzero()[1][i], layoutCanvus.nonzero()[0][i])
                for i in range(len(layoutCanvus.nonzero()[0]))
            ]
        return rstPts


if __name__ == "__main__":
    src = [
        {"CamId": 1, "Point": [(840, 1600), (1325, 510), (1350, 1595)]},
        {"CamId": 2, "Point": []},
        {"CamId": 3_1, "Point": [[128, 319], [184, 128], [708, 291]]},
        {"CamId": 3_2, "Point": []},
    ]
    target = [
        {"CamId": 1, "Point": [(4060, 2780), (5020, 670), (5020, 2780)]},
        {"CamId": 2, "Point": []},
        {"CamId": 3_1, "Point": [[265, 2615], [237, 280], [3977, 2577]]},
        {"CamId": 3_2, "Point": []},
    ]

    img = cv2.imread(r"data\calibrate\fisheye\cam1.jpg")
    transform = Transform()
    matrix = transform.get_matrix(src, target, camId=1)
    rstImg = transform.transform(img, matrix, dSize=(5216, 4106))
    cv2.imshow("result", rstImg)
    cv2.waitKey(0)
