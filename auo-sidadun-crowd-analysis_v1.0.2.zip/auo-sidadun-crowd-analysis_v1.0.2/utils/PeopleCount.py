import cv2
import sys

sys.path.append("./")
from packages.CentroidTracker import CentroidTracker


def draw_area(img, bbox):
    resImg = img.copy()
    x1, y1, x2, y2 = int(bbox[0][0]), int(bbox[0][1]), int(bbox[1][0]), int(bbox[1][1])
    cv2.rectangle(resImg, (x1, y1), (x2, y2), color=(0, 0, 255), thickness=2)
    return resImg


def draw_pts(img, pts):
    rstImg = img.copy()
    for pt in pts:
        cv2.circle(rstImg, pt, 5, (0, 0, 255), -1)
    return rstImg


class PeopleCount:
    def __init__(self, cntDict, maxSize=999, visualize=False):
        self.cntDict = cntDict
        self.visualize = visualize
        self.cntNow = 0  # 當前館內總人數
        self.cntDay = 0  # 當天總參訪人次
        self.lastEntryMaxId, self.lastExitMaxId = 0, 0
        self.entryTracker = CentroidTracker(maxDisappeared=2)
        self.exitTracker = CentroidTracker(maxDisappeared=2)
        self.entryPtDictList, self.historyEntryPtDictList = dict(), dict()
        self.exitPtDictList, self.historyExitPtDictList = dict(), dict()
        self.entryIdList, self.exitIdList = list(), list()
        self.maxSize = maxSize  # 通過的ID暫存數量
        self.cntLineWidth = 0  # 計數線寬度 (未開發完成)

    def is_point_in_area(self, point, area):
        x, y = point[0], point[1]
        if x < area[0][0] or x > area[1][0] or y < area[0][1] or y > area[1][1]:
            return False
        else:
            return True

    def __entryCnt(self, entryDataDict):
        entryNum, maxId = 0, 0
        self.entryArea = self.cntDict["1"]["data"].copy()
        pointList = entryDataDict["point"]
        if self.visualize:
            self.entryImg = entryDataDict["corrImg"].copy()

        self.pointInEntryArea = list()
        ### 在入口區域的點座標
        for point in pointList:
            if self.is_point_in_area(point, self.entryArea):
                self.pointInEntryArea.append(point)

        ### 點座標追蹤
        self.historyEntryPtDictList = self.entryPtDictList
        self.entryPtDictList = dict()
        objects = self.entryTracker.update(self.pointInEntryArea)
        for (objectID, centroid) in objects.items():
            if objectID > maxId:
                maxId = objectID
            self.entryPtDictList[objectID] = dict()
            self.entryPtDictList[objectID]["objectID"] = objectID
            self.entryPtDictList[objectID]["point"] = tuple((centroid[0], centroid[1]))

            ### Visualize
            if self.visualize:
                cv2.putText(
                    self.entryImg,
                    str(objectID),
                    tuple((centroid[0], centroid[1])),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    1,
                    (0, 0, 255),
                    1,
                    cv2.LINE_AA,
                )

        if True:
            ### 計算通過計數線數量
            x1, x2 = self.entryArea[0][0], self.entryArea[1][0]
            cntLineX = (x1 + x2) // 2 - 70
            rightCntLineX = cntLineX + 130
            topLineY = self.entryArea[0][1] + 220

            for personId, ptDict in self.entryPtDictList.items():
                point = ptDict["point"]
                ### 上一幀目標存在
                if personId in self.historyEntryPtDictList.keys():
                    lastPoint = self.historyEntryPtDictList[personId]["point"]
                    ### 通過計數線 (同時判斷右至左, 下至上)
                    if True:
                        if lastPoint[0] >= cntLineX and lastPoint[1] >= topLineY:
                            ### 相同ID不重複計算
                            if personId in self.entryIdList:
                                continue
                            if point[0] < cntLineX:
                                self.entryIdList.append(personId)
                                entryNum += 1
                            elif point[1] < topLineY and point[0] < rightCntLineX:
                                self.entryIdList.append(personId)
                                entryNum += 1

                            if len(self.entryIdList) > self.maxSize:
                                self.entryIdList.pop(0)
                    else:
                        ### 通過計數線 (右至左)
                        if lastPoint[0] > cntLineX + self.cntLineWidth and point[0] <= cntLineX - self.cntLineWidth:
                            # ### 相同ID不重複計算
                            # if personId in self.entryIdList:
                            #     continue
                            # if len(self.entryIdList) > self.maxSize:
                            #     self.entryIdList.pop(0)
                            # self.entryIdList.append(personId)
                            entryNum += 1
        else:
            ### 追蹤到的最大ID
            entryNum = maxId - self.lastEntryMaxId + 1
            self.lastEntryMaxId = maxId

        ### Visualize
        if self.visualize:
            cv2.line(
                self.entryImg,
                (int(cntLineX + self.cntLineWidth), int(topLineY)),
                (int(cntLineX + self.cntLineWidth), int(self.entryArea[1][1])),
                (255, 0, 0),
                2,
            )
            cv2.line(
                self.entryImg,
                (int(cntLineX), int(topLineY)),
                (int(rightCntLineX), int(topLineY)),
                (255, 0, 0),
                2,
            )

        return entryNum

    def __exitCnt(self, exitDataDict):
        exitNum, maxId = 0, 0
        self.exitArea = self.cntDict["4"]["data"].copy()
        pointList = exitDataDict["point"]
        if self.visualize:
            self.exitImg = exitDataDict["corrImg"].copy()

        self.pointInExitArea = list()
        ### 在出口區域的點座標
        for point in pointList:
            if self.is_point_in_area(point, self.exitArea):
                self.pointInExitArea.append(point)

        ### 點座標追蹤
        self.historyExitPtDictList = self.exitPtDictList
        self.exitPtDictList = dict()
        objects = self.exitTracker.update(self.pointInExitArea)
        for (objectID, centroid) in objects.items():
            if objectID > maxId:
                maxId = objectID
            self.exitPtDictList[objectID] = dict()
            self.exitPtDictList[objectID]["objectID"] = objectID
            self.exitPtDictList[objectID]["point"] = tuple((centroid[0], centroid[1]))

            ### Visualize
            if self.visualize:
                cv2.putText(
                    self.exitImg,
                    str(objectID),
                    tuple((centroid[0], centroid[1])),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    1,
                    (0, 0, 255),
                    1,
                    cv2.LINE_AA,
                )

        if True:
            ### 計算通過計數線數量
            x1, x2 = self.exitArea[0][0], self.exitArea[1][0]
            cntLineX = (x1 + x2) // 2 + 130
            topCntLineY = self.exitArea[0][1] + 180
            bottomCntLineY = self.exitArea[1][1] - 150

            for personId, ptDict in self.exitPtDictList.items():
                point = ptDict["point"]
                ### 上一幀目標存在
                if personId in self.historyExitPtDictList.keys():
                    lastPoint = self.historyExitPtDictList[personId]["point"]
                    if True:
                        ### 通過計數線 (矩形區左至右)
                        if point[0] > cntLineX and point[1] > topCntLineY and point[1] < bottomCntLineY:
                            ### 相同ID不重複計算
                            if personId in self.exitIdList:
                                continue
                            if (
                                lastPoint[0] <= cntLineX
                                or lastPoint[1] <= topCntLineY
                                or lastPoint[1] >= bottomCntLineY
                            ):
                                self.exitIdList.append(personId)
                                exitNum += 1
                            if len(self.exitIdList) > self.maxSize:
                                self.exitIdList.pop(0)
                    else:
                        ### 通過計數線 (左至右)
                        if lastPoint[0] < cntLineX - self.cntLineWidth and point[0] >= cntLineX + self.cntLineWidth:
                            # ### 相同ID不重複計算
                            # if personId in self.exitIdList:
                            #     continue
                            # if len(self.exitIdList) > self.maxSize:
                            #     self.exitIdList.pop(0)
                            # self.exitIdList.append(personId)
                            exitNum += 1
        else:
            ### 追蹤到的最大ID
            exitNum = maxId - self.lastExitMaxId + 1
            self.lastExitMaxId = maxId

        ### Visualize
        if self.visualize:
            cv2.line(
                self.exitImg,
                (int(cntLineX - self.cntLineWidth), int(topCntLineY)),
                (int(cntLineX - self.cntLineWidth), int(bottomCntLineY)),
                (255, 0, 0),
                2,
            )
            cv2.line(
                self.exitImg,
                (int(cntLineX), int(topCntLineY)),
                (int(self.exitArea[1][0]), int(topCntLineY)),
                (255, 0, 0),
                2,
            )
            cv2.line(
                self.exitImg,
                (int(cntLineX), int(bottomCntLineY)),
                (int(self.exitArea[1][0]), int(bottomCntLineY)),
                (255, 0, 0),
                2,
            )

        return exitNum

    def count_total_people(self, dataDictList):
        for dataDict in dataDictList:
            ### 入口
            if dataDict["CamId"] == "1":
                entryNum = self.__entryCnt(dataDict)
            ### 出口
            elif dataDict["CamId"] == "4":
                exitNum = self.__exitCnt(dataDict)
        self.cntNow = self.cntNow + entryNum - exitNum
        ### 邊界條件, 避免出現負值
        if self.cntNow < 0:
            self.cntNow = 0
        self.cntDay += entryNum

        if self.visualize:
            self.entryImg = draw_area(self.entryImg, self.entryArea)
            self.entryImg = draw_pts(self.entryImg, self.pointInEntryArea)
            self.entryImg = cv2.resize(self.entryImg, (self.entryImg.shape[1] // 2, self.entryImg.shape[0] // 2))
            self.exitImg = draw_area(self.exitImg, self.exitArea)
            self.exitImg = draw_pts(self.exitImg, self.pointInExitArea)
            self.exitImg = cv2.resize(self.exitImg, (self.exitImg.shape[1] // 2, self.exitImg.shape[0] // 2))
            cv2.imshow("entryImg", self.entryImg)
            cv2.imshow("exitImg", self.exitImg)
            cv2.waitKey(1)

        return self.cntNow, self.cntDay
