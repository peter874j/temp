import numpy as np
import sys
import cv2
import time

sys.path.append("./")
from packages.DistortionCorrection import DistortionCorrection
from packages.AffineTransform import AffineTransform


def get_layout_region(layoutRegionList, camId):
    for cam in layoutRegionList:
        if cam["CamId"] == camId:
            region = cam["Point"]
            return region
    return None


def img_distortion_corr(img, distortionCorrMatix):
    """單張圖片畸變轉換

    Args:
        img (_type_): _description_
        distortionCorrMatix (_type_): _description_

    Returns:
        _type_: _description_
    """
    mapxList, mapyList = distortionCorrMatix
    resImg = DistortionCorrection.imgCalibration(img, mapxList, mapyList)
    return resImg


def point_distortion_corr(pointList, imgSize, distortionCorrMatix):
    """點座標畸變轉換

    Args:
        pointList (_type_): _description_
        imgSize (_type_): _description_

    Returns:
        _type_: _description_
    """
    if True:
        ### 座標轉換方法
        mapxList, mapyList = distortionCorrMatix
        resPointList = DistortionCorrection.ptsCalibration(pointList, mapxList, mapyList)

    else:
        ### FIXME:
        canvas = np.zeros((imgSize[1], imgSize[0]), np.uint8)
        for point in pointList:
            # canvas[point[1], point[0]] = 1
            cv2.circle(canvas, point, 1, 1, -1)

        resCanvas = canvas.copy()
        resCanvas = img_distortion_corr(resCanvas, distortionCorrMatix)
        if True:
            ### 過濾轉換後多餘座標
            value = resCanvas.nonzero()
            resPointList = list()
            threshold = 5
            for i in range(len(value[0])):
                newX, newY = value[1][i], value[0][i]
                if len(resPointList) == 0:
                    resPointList.append((newX, newY))
                elif abs(newX - resPointList[-1][0]) >= threshold or abs(newY - resPointList[-1][1]) >= threshold:
                    resPointList.append((newX, newY))
                else:
                    # print('')
                    pass

            ### 避免靠近點不相鄰情況
            if len(resPointList) > len(pointList):
                filterList = list()
                for i, resPoint in enumerate(resPointList):
                    for comparePoint in resPointList[i + 1 :]:
                        if (
                            abs(resPoint[0] - comparePoint[0]) < threshold
                            and abs(resPoint[1] - comparePoint[1]) < threshold
                        ):
                            if i not in filterList:
                                filterList.append(i)
                tmpList = list()
                for i in range(len(resPointList)):
                    if i not in filterList:
                        tmpList.append(resPointList[i])
                resPointList = tmpList

            # print(f"{len(pointList)}->{len(value[0])}->{len(resPointList)}")
            # if len(resPointList) != len(pointList):
            #     print(pointList)
            #     print(value)
            #     print(resPointList)
            #     print('')

        else:
            resPointList = [
                (resCanvas.nonzero()[1][i], resCanvas.nonzero()[0][i]) for i in range(len(resCanvas.nonzero()[0]))
            ]
            print(f"{len(pointList)}->{len(resPointList)}")
            if len(pointList) != len(resPointList):
                print(pointList)
                print(resPointList)

    return resPointList


def img_affin_trans(img, region, affinMatrix):
    """單張圖片畸變轉換

    Args:
        img (_type_): _description_
        camId (_type_): _description_

    Returns:
        _type_: _description_
    """
    # affinMatrix = self.affinMatrix[camId]
    # region = self.__get_layout_region(camId)
    dSize = (int(region[1][0]) - int(region[0][0]), int(region[1][1]) - int(region[0][1]))
    resImg = AffineTransform.img_trasform(img, affinMatrix, dSize)
    return resImg


def point_affin_trans(pointList, region, affinMatrix, imgSize, layoutSize=(1044, 822)):
    """點座標仿設轉換

    Args:
        pointList (_type_): _description_
        camId (_type_): _description_
        imgSize (_type_): _description_

    Returns:
        _type_: _description_
    """
    if True:
        ### 座標轉換方法
        # affinMatrix = self.affinMatrix[camId]
        # region = self.__get_layout_region(camId)
        afinePointList = AffineTransform.point_transform(pointList, affinMatrix)
        ### 拼入 Layout
        resPointList = list()
        for point in afinePointList:
            x, y = point
            dSize = (int(region[1][0]) - int(region[0][0]), int(region[1][1]) - int(region[0][1]))
            ### 濾除超出邊界的點
            if x < 0 or y < 0 or x > dSize[0] or y > dSize[1]:
                continue
            x += region[0][0]
            y += region[0][1]
            resPointList.append((int(x), int(y)))
        # print(f"{len(pointList)}->{len(resPointList)}")
    else:
        ### FIXME: 暫時使用圖像進行矯正
        canvas = np.zeros((imgSize[1], imgSize[0]), np.uint8)
        # layoutSize = (self.layoutImg.shape[1], self.layoutImg.shape[0])
        resCanvas = np.zeros((layoutSize[1], layoutSize[0]), np.uint8)

        for point in pointList:
            # canvas[point[1], point[0]] = 1
            cv2.circle(canvas, point, 8, 1, -1)

        transCanvas = img_affin_trans(canvas, camId)
        # region = self.__get_layout_region(camId)
        resCanvas[int(region[0][1]) : int(region[1][1]), int(region[0][0]) : int(region[1][0])] = transCanvas
        if True:
            value = resCanvas.nonzero()
            resPointList = list()
            n = 0.003
            thresholdX, thresholdY = resCanvas.shape[1] * n, resCanvas.shape[0] * n
            for i in range(len(value[0])):
                newX, newY = value[1][i], value[0][i]
                if len(resPointList) == 0:
                    resPointList.append((newX, newY))
                elif abs(newX - resPointList[-1][0]) >= thresholdX and abs(newY - resPointList[-1][1]) >= thresholdY:
                    resPointList.append((newX, newY))
                else:
                    # print("")
                    pass
            print(f"{len(pointList)}->{len(value[0])}->{len(resPointList)}")
        elif False:
            resPointList = [
                (resCanvas.nonzero()[1][i], resCanvas.nonzero()[0][i]) for i in range(len(resCanvas.nonzero()[0]))
            ]

    return resPointList
