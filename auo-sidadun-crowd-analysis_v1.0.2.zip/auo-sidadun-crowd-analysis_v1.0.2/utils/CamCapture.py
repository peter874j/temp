import numpy as np
import cv2
import threading
import queue
import time


class CamCapture:
    def __init__(self, cam1Path, cam2Path, cam3Path, cam4Path, size=304, videoMode=False) -> None:
        self.size = size
        self.combineImg = np.zeros((size * 2, size * 2, 3), np.uint8)
        self.videoMode = videoMode

        camImg = np.zeros((size, size, 3), np.uint8)
        self.camDict = {
            "1": {"camImg": camImg, "flag": True, "xyxy": [1, 2, 0, 1]},
            "2": {"camImg": camImg, "flag": True, "xyxy": [0, 1, 0, 1]},
            "3": {"camImg": camImg, "flag": True, "xyxy": [0, 1, 1, 2]},
            "4": {"camImg": camImg, "flag": True, "xyxy": [1, 2, 1, 2]},
        }
        cap1 = cv2.VideoCapture(cam1Path)
        cap2 = cv2.VideoCapture(cam2Path)
        cap3 = cv2.VideoCapture(cam3Path)
        cap4 = cv2.VideoCapture(cam4Path)

        cam1Thread = threading.Thread(target=self.cam_read, args=(cap1, "1"))
        cam2Thread = threading.Thread(target=self.cam_read, args=(cap2, "2"))
        cam3Thread = threading.Thread(target=self.cam_read, args=(cap3, "3"))
        cam4Thread = threading.Thread(target=self.cam_read, args=(cap4, "4"))
        cam1Thread.start()
        cam2Thread.start()
        cam3Thread.start()
        cam4Thread.start()

    def cam_read(self, cap, camId):
        # if not self.videoMode:
        #     time.delay(5)
        while True:
            time.sleep(0.0001)
            if not self.camDict[camId]["flag"]:
                continue

            _, frame = cap.read()

            ### DEVELOP:
            if False:
                ### 影片在耍寶
                frame = frame[0:1536, 1024 - 768 : 1024 + 768]

            ### DEVELOP:
            if False:
                ### For SE 提供 demo影片
                if camId == "1":
                    frame = frame[0:398, 400 : 400 * 2]
                elif camId == "2":
                    frame = frame[0:398, 0:400]
                if camId == "3":
                    frame = frame[398 : 398 * 2, 0:400]
                if camId == "4":
                    frame = frame[398 : 398 * 2, 400 : 400 * 2]

            resizeImg = cv2.resize(frame, (self.size, self.size))
            self.camDict[camId]["camImg"] = resizeImg
            if self.videoMode:
                self.camDict[camId]["flag"] = False

    def get_frame(self):
        for camId, camData in self.camDict.items():
            x1, x2, y1, y2 = camData["xyxy"]
            self.combineImg[self.size * y1 : self.size * y2, self.size * x1 : self.size * x2] = camData["camImg"]
            camData["flag"] = True
        return self.combineImg


if __name__ == "__main__":
    cam1Path = "rtsp://admin:Auo+84149738@192.168.226.201/profile1"
    cam2Path = "rtsp://admin:Auo+84149738@192.168.226.202/profile1"
    cam3Path = "rtsp://admin:Auo+84149738@192.168.226.203/profile1"
    cam4Path = "rtsp://admin:Auo+84149738@192.168.226.204/profile1"
    # cam1Path = r"data\videos\cam1_demo.mp4"
    # cam2Path = r"data\videos\cam2_demo.mp4"
    # cam3Path = r"data\videos\cam3_demo.mp4"
    # cam4Path = r"data\videos\cam4_demo.mp4"
    camCapture = CamCapture(cam1Path, cam2Path, cam3Path, cam4Path, videoMode=False)

    while True:
        framImg = camCapture.get_frame()
        cv2.imshow("frame", framImg)
        cv2.waitKey(1)
