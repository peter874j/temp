### 魚眼相機畸變校正 https://www.jiangdabai.com/3753
"""
@author: YJChou
@modular: YJChou
@time: 2023/02
"""

import numpy as np
from tqdm import tqdm
import cv2
import os
import time


class DistortionCorrection:
    @staticmethod
    def get_useful_area(img, center=None, radius=None):
        """去除魚眼黑邊

        Args:
            img (_type_): _description_

        Returns:
            _type_: _description_
        """
        ### 自適應魚眼範圍
        if center is None or radius is None:
            imgGray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            _, imgBinary = cv2.threshold(imgGray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
            contours, _ = cv2.findContours(imgBinary, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
            contourFisheye = sorted(contours, key=cv2.contourArea, reverse=True)[0]
            center, radius = cv2.minEnclosingCircle(contourFisheye)

        mask = np.zeros_like(img, dtype=np.uint8)
        mask = cv2.circle(mask, (int(center[0]), int(center[1])), int(radius), (1, 1, 1), -1)
        imageUseful = img * mask
        cv2.imshow("imageUseful", imageUseful)
        imgFisheye = imageUseful[
            int(center[1]) - int(radius) : int(center[1]) + int(radius),
            int(center[0]) - int(radius) : int(center[0]) + int(radius),
        ]
        return imgFisheye

    @staticmethod
    def longitude_calibration(img):
        """經度校正

        Args:
            img (_type_): _description_
        """
        r = img.shape[0] // 2
        mapx = np.zeros([2 * r, 2 * r], dtype=np.float32)
        mapy = np.zeros([2 * r, 2 * r], dtype=np.float32)
        for i in range(mapx.shape[0]):
            for j in range(mapx.shape[1]):
                mapx[i, j] = (j - r) / r * (r**2 - (i - r) ** 2) ** 0.5 + r
                mapy[i, j] = i
        return mapx, mapy

    @staticmethod
    def latitude_calibration(img):
        """緯度校正

        Args:
            img (_type_): _description_
        """
        r = img.shape[0] // 2
        mapx = np.zeros([2 * r, 2 * r], dtype=np.float32)
        mapy = np.zeros([2 * r, 2 * r], dtype=np.float32)
        for i in range(mapx.shape[0]):
            for j in range(mapx.shape[1]):
                mapx[i, j] = j
                mapy[i, j] = (i - r) / r * (r**2 - (j - r) ** 2) ** 0.5 + r
        return mapx, mapy

    @staticmethod
    def remap(img, mapx, mapy):
        """_summary_

        Args:
            img (_type_): _description_
            mapx (_type_): _description_
            mapy (_type_): _description_

        Returns:
            _type_: _description_
        """
        # imgRemap = cv2.remap(img, mapx, mapy, interpolation=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT)
        imgRemap = cv2.remap(img, mapx, mapy, interpolation=cv2.INTER_NEAREST, borderMode=cv2.BORDER_CONSTANT)
        return imgRemap

    @staticmethod
    def perspective_transformation(img, pts1, pts2):
        """透視變換

        Args:
            img (_type_): _description_

        Returns:
            _type_: _description_
        """
        # Apply Perspective Transform Algorithm
        matrix = cv2.getPerspectiveTransform(pts1, pts2)
        result = cv2.warpPerspective(img, matrix, (500, 600))
        return result

    @staticmethod
    def get_remap_matrix(img, mode, matrixSavePath=None, matrixName=None, visualize=False):
        """經緯度校正

        Args:
            img (_type_): _description_
            matrixSavePath (_type_, optional): _description_. Defaults to None.
            mode (int, optional): _description_. Defaults to 1.
            visualize (bool, optional): _description_. Defaults to False.

        Returns:
            _type_: _description_
        """
        if mode == 1:
            methods = [DistortionCorrection.longitude_calibration]
        elif mode == 2:
            methods = [DistortionCorrection.latitude_calibration]
        elif mode == 3:
            methods = [DistortionCorrection.longitude_calibration, DistortionCorrection.latitude_calibration]
        else:
            raise ("Error mode")

        imgCopy = img.copy()
        finalMapx, finalMapy = list(), list()
        for method in methods:
            if False:
                imgFisheye = DistortionCorrection.get_useful_area(imgCopy)
                # imgFisheye = Calibration.get_useful_area(imgCopy, center=(535, 467), radius=930)
            imgFisheye = imgCopy
            mapx, mapy = method(imgFisheye)
            finalMapx.append(mapx)
            finalMapy.append(mapy)
            imgCopy = DistortionCorrection.remap(imgCopy, mapx, mapy)

        if matrixSavePath:
            finalMapx = np.array(finalMapx)
            finalMapy = np.array(finalMapy)
            np.save(os.path.join(matrixSavePath, f"{matrixName}_mapx.npy"), finalMapx)
            np.save(os.path.join(matrixSavePath, f"{matrixName}_mapy.npy"), finalMapy)
            print(f"Save matrix to '{os.path.join(matrixSavePath)}'")

        if visualize:
            cv2.imshow("org", img)
            cv2.imshow("outImg", imgCopy)
            cv2.waitKey(0)

    @staticmethod
    def imgCalibration(img, mapxList=None, mapyList=None, matrixSavePath=None, mapxName=None, mapyName=None):
        """經緯度校正

        Args:
            img (_type_): _description_
            mode (int, optional): 1: 只做經度, 2: 只做緯度, 3: 先做經度再做緯度

        Returns:
            _type_: _description_
        """
        if mapxList is None:
            mapxList = np.load(os.path.join(matrixSavePath, f"{mapxName}.npy"))
            mapyList = np.load(os.path.join(matrixSavePath, f"{mapyName}.npy"))

        resultImg = img.copy()
        for i in range(mapxList.shape[0]):
            resultImg = DistortionCorrection.remap(resultImg, mapxList[i], mapyList[i])
        return resultImg

    ### 僅支援先做精度再做緯度
    @staticmethod
    def ptsCalibration(pts, mapxList=None, mapyList=None, matrixSavePath=None, mapxName=None, mapyName=None):
        

        if mapxList is None:
            mapxList = np.load(os.path.join(matrixSavePath, f"{mapxName}.npy"))
            mapyList = np.load(os.path.join(matrixSavePath, f"{mapyName}.npy"))

        rstPts = list()

        r = mapxList[0].shape[0]//2
        for pt in pts:
            x ,y = pt
            ### 經度校正
            xRes = (r*(x-r))/((r**2 - (y-r)**2))**0.5 + r
            yRes = y
            matrixX, matrixY = mapxList[0],  mapyList[0]
            # print(f'({matrixX[int(yRes), int(xRes)]}, {matrixY[int(yRes), int(xRes)]})')

            ### 緯度校正
            # x ,y = xRes, yRes
            xRes = x
            yRes = (r*(y-r))/((r**2 - (x-r)**2))**0.5 + r

            rstPts.append(tuple((int(xRes), int(yRes))))
        return rstPts


if __name__ == "__main__":
    img = cv2.imread(r"data\calibrate\fisheye\cam4.jpg")
    mapxList = np.load(r"data\calibrate\matrix\distortion\distortion_corr_matix_mapx.npy")
    mapyList = np.load(r"data\calibrate\matrix\distortion\distortion_corr_matix_mapy.npy")
    resImg = DistortionCorrection.imgCalibration(img, mapxList, mapyList)
    cv2.imshow("resImg", resImg)
    cv2.waitKey(0)
