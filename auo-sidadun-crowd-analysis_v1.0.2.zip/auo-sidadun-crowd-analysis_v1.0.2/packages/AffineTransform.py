import cv2
import numpy as np


class AffineTransform:
    @staticmethod
    def get_matrix(srcPts, targetPts):
        ### Apply Perspective Transform Algorithm
        matrix = cv2.getAffineTransform(srcPts, targetPts)
        return matrix

    @staticmethod
    def img_trasform(img, matrix, dSize):
        rstImg = img.copy()
        rstImg = cv2.warpAffine(rstImg, matrix, dSize)
        return rstImg

    @staticmethod
    def point_transform(pointList, matrix):
        resPointList = list()
        temp = np.array([[0, 0, 1]])
        matrix = np.concatenate((matrix, temp), axis=0)
        for point in pointList:
            x, y = point
            point = list((x, y, 1))
            resPoint = np.matrix(matrix) * np.matrix(point).T
            resPoint = (np.squeeze(resPoint.T)).tolist()[0]
            x, y, _ = resPoint
            resPointList.append((int(x), int(y)))
        return resPointList
