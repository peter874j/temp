import cv2
from pypylon import pylon
import threading
import os
from defect_detection import flaw_detect
import time


class Camera:
    def __init__(self, devices=None, tlFactory=None, converter=None, cameras=None, device=None):
        self.isrunning = True
        self.device = device
        self.devices = devices
        self.tlFactory = tlFactory
        self.converter = converter
        self.cameras = cameras
        self.create_device()

    def create_device(self):
        # Create and attach all Pylon Devices.
        for i, cam in enumerate(self.cameras):
            if i == self.device:
                cam.Attach(self.tlFactory.CreateDevice(self.devices[i]))
                cam.Open()
                cam.Width.SetValue(1920)
                cam.Height.SetValue(1200)
                self.cameras[i].StartGrabbing(pylon.GrabStrategy_LatestImageOnly)

    def run(self):
        self.thread = threading.Thread(target=self.update, args=([self.device]))
        self.thread.start()

    def update(self, device):
        while True:
            while self.cameras[device].IsGrabbing() and self.isrunning:
                try:
                    grabResult = self.cameras[device].RetrieveResult(5000, pylon.TimeoutHandling_ThrowException)
                    if grabResult.GrabSucceeded():
                        self.status = True
                        image = self.converter.Convert(grabResult)
                        self.frame = image.GetArray()

                    grabResult.Release()

                except:
                    try:
                        self.create_device()
                    except:
                        cv2.destroyAllWindows()
                        print("Waiting camera[{}] open...".format(device + 1))

            try:
                self.create_device()
            except:
                print("Waiting create device[{}]...".format(device + 1))

    def updateVideo(self):
        n = 0
        cap = cv2.VideoCapture("./plc_test2.mp4")
        while cap.isOpened() and self.isrunning:
            n += 1
            if n == 1:  # read every 4th frame
                (self.status, frame) = cap.read()
                if self.status:
                    # frame = cv2.resize(frame, (1024, 768))
                    self.frame = frame
                    # self.frame = cv2.imread("./test.png")
                    self.frame = cv2.resize(self.frame, (1024, 768))
                n = 0
            time.sleep(0.025)

    def stop(self):
        self.isrunning = False

    def get_frame(self, stream=True):
        if stream:
            if self.status:
                result = flaw_detect(self.frame)
                return result
            else:
                print("no image...")
                return None
        else:
            print("gg")
            pass


if __name__ == "__main__":
    os.environ["PYLON_CAMEMU"] = "3"
    maxCamerasToUse = 4
    # # Get the transport layer factory.
    # tlFactory = pylon.TlFactory.GetInstance()
    # # Get all attached devices and exit application if no device is found.
    # devices = tlFactory.EnumerateDevices()
    # # converting to opencv bgr format
    # converter = pylon.ImageFormatConverter()
    # converter.OutputPixelFormat = pylon.PixelType_BGR8packed
    # converter.OutputBitAlignment = pylon.OutputBitAlignment_MsbAligned
    # # Create an array of instant cameras for the found devices and avoid exceeding a maximum number of devices.
    # cameras = pylon.InstantCameraArray(min(len(devices), maxCamerasToUse))

    # if len(devices) == 0:
    #     raise pylon.RuntimeException("No camera present.")

    # for i in range(maxCamerasToUse):
    #     camInstance = Camera(devices = devices, tlFactory = tlFactory, converter = converter , cameras = cameras, device = i)
    #     camInstance.run()
