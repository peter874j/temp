# -*- coding: utf-8 -*-
"""
Created on Mon Dec  5 09:47:28 2022

@author: User
"""

import os
# os.environ["PYLON_CAMEMU"] = "3"

import cv2
import numpy as np
from pypylon import genicam
from pypylon import pylon
import sys


maxCamerasToUse = 2  # 要抓取的basler數量

# The exit code of the sample application.
exitCode = 0

try:

    # Get the transport layer factory.
    tlFactory = pylon.TlFactory.GetInstance()

    # Get all attached devices and exit application if no device is found.
    devices = tlFactory.EnumerateDevices()
    if len(devices) == 0:
        raise pylon.RuntimeException("No camera present.")

    # Create an array of instant cameras for the found devices and avoid exceeding a maximum number of devices.
    cameras = pylon.InstantCameraArray(min(len(devices), maxCamerasToUse))
    converter = pylon.ImageFormatConverter()
    converter.OutputPixelFormat = pylon.PixelType_BGR8packed
    converter.OutputBitAlignment = pylon.OutputBitAlignment_MsbAligned

    l = cameras.GetSize()

    # Create and attach all Pylon Devices.
    for i, cam in enumerate(cameras):
        cam.Attach(tlFactory.CreateDevice(devices[i]))

        cam.Open()
        cam.Width.SetValue(1920)
        cam.Height.SetValue(1080)

        # Print the model name of the camera.
        print("Using device ", cam.GetDeviceInfo().GetModelName())

    # Starts grabbing for all cameras
    cameras.StartGrabbing(pylon.GrabStrategy_LatestImageOnly, pylon.GrabLoop_ProvidedByUser)


    while cameras.IsGrabbing():
        for i in range(maxCamerasToUse):
            grabResult = cameras[i].RetrieveResult(5000, pylon.TimeoutHandling_ThrowException)
            if grabResult.GrabSucceeded():
                image = converter.Convert(grabResult)
                img = image.GetArray()
                cv2.imshow('Acquisition'+str(i), img)
            if cv2.waitKey(1) & 0xFF == 27:
                break


except genicam.GenericException as e:
    # Error handling
    print("An exception occurred.", e.GetDescription())
    exitCode = 1

cv2.destroyAllWindows()
sys.exit(exitCode)
