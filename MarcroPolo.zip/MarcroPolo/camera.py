# -*- coding: utf-8 -*-
"""
Created on Fri Dec  9 11:10:44 2022

@author: User
"""
import cv2
import time
import numpy as np
from pypylon import genicam
from pypylon import pylon
import threading

tlFactory = pylon.TlFactory.GetInstance()
devices = tlFactory.EnumerateDevices()


class Camera:
    def __init__(self, devices = None, device_num = 0, camWidth = None, camHeight = None):

        self.frame = None
        self.status = False
        self.device_num = device_num
        # self.cameras =  pylon.InstantCameraArray(min(len(devices), maxCamerasToUse))
        self.cameras =  pylon.InstantCameraArray(1)

        for i, cam in enumerate(self.cameras):
            # cam.Attach(tlFactory.CreateDevice(devices[self.device]))
            cam.Attach(tlFactory.CreateDevice(devices[self.device_num]))
            print("Using device ", cam.GetDeviceInfo().GetModelName())
            cam.Open()
            cam.Width.SetValue(camWidth)
            cam.Height.SetValue(camHeight)


        self.camera = self.cameras
        # self.camera.StartGrabbing()
        self.camera.StartGrabbing(pylon.GrabStrategy_LatestImageOnly)

        self.converter = pylon.ImageFormatConverter()
        self.converter.OutputPixelFormat = pylon.PixelTyp e_BGR8packed
        self.converter.OutputBitAlignment = pylon.OutputBitAlignment_MsbAligned

    def run(self):
        self.thread = threading.Thread(target=self.update, args=([self.camera]), daemon=True)
        self.thread.start()

    def update(self, camera):
        while camera.IsGrabbing():
            grabResult = camera.RetrieveResult(5000, pylon.TimeoutHandling_ThrowException)
            if grabResult.GrabSucceeded():
                self.status = True
                cameraContextValue = grabResult.GetCameraContext()
                image = self.converter.Convert(grabResult)
                img = image.GetArray()
                self.frame = img
    def get_frame(self ,stream = True):
        ### Camera有讀到影像
        if stream:
            if self.status:
                return self.frame
            else:
                print("no image...")
                return None
        else:
            print("gg")
            pass








#%%
