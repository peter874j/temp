# -*- coding: utf-8 -*-
"""
Created on Wed Nov  9 10:33:42 2022

@author: User
"""

from pypylon import pylon
import cv2
import time
import os
import numpy as np

os.environ["PYLON_CAMEMU"] = "2"
now_time = time.strftime("%m%d%Y%H%M%S", time.localtime())
fourcc = cv2.VideoWriter.fourcc("M", "J", "P", "G")
out = cv2.VideoWriter(now_time + ".avi", fourcc, 20.0, (1920, 1200))

camera = pylon.InstantCamera(pylon.TlFactory.GetInstance().CreateFirstDevice())
camera.StartGrabbing(pylon.GrabStrategy_LatestImageOnly)
converter = pylon.ImageFormatConverter()
converter.OutputPixelFormat = pylon.PixelType_BGR8packed
converter.OutputBitAlignment = pylon.OutputBitAlignment_MsbAligned
while camera.IsGrabbing():
    grabResult = camera.RetrieveResult(5000, pylon.TimeoutHandling_ThrowException)

    if grabResult.GrabSucceeded():
        image = converter.Convert(grabResult)
        img = image.GetArray()
        result = img.copy()

        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        blur = cv2.medianBlur(gray, 5)
        canny = cv2.Canny(blur, 20, 50)

        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (5, 5))
        dst = cv2.morphologyEx(canny, cv2.MORPH_CLOSE, kernel)

        ### 將重疊的輪廓填滿以形成完整大輪廓 ###
        mask = np.zeros(dst.shape[:2], dtype=np.uint8)
        contours, hierarchy = cv2.findContours(dst, cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)
        for cnt in contours:
            area = cv2.contourArea(cnt)
            x, y, w, h = cv2.boundingRect(cnt)

            if area >= 50 and area < 1000:
                cv2.rectangle(mask, (x, y), (x + w, y + h), (255), -1)

        ### 重新抓取輪廓 ###
        contours, hierarchy = cv2.findContours(mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)
        for c in contours:
            cv2.drawContours(result, [c], -1, (0, 0, 255), 1)
        out.write(result)
        # cv2.imshow('mask',mask)
        cv2.imshow("result", result)

        k = cv2.waitKey(1)
        if k == ord("s"):
            t = time.strftime("%m%d%Y%H%M%S", time.localtime())
            cv2.imwrite(t + ".jpg", img)
            cv2.imwrite(t + "r.jpg", result)
        elif k == ord("q"):
            break

    grabResult.Release()

camera.StopGrabbing()
out.release()
cv2.destroyAllWindows()
