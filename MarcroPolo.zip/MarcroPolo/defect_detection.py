# -*- coding: utf-8 -*-
"""
Created on Fri Nov 25 14:00:00 2022

@author: YouyingLin
"""

import os
import cv2
import time
import numpy as np


def flaw_detect(image):

    ###影像前處理(邊緣檢測)
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    blur = cv2.medianBlur(gray, 5)
    edges = cv2.Canny(blur, 20, 50)
    width, height, channel = image.shape
    result = image.copy()

    ###建立黑布
    mask = np.zeros(edges.shape[:2], dtype=np.uint8)

    ###提取輪廓
    countours, _ = cv2.findContours(edges, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

    ###過濾小輪廓區域，並將閥值內輪廓(矩形)畫至黑布
    for cnt in countours:
        area = cv2.contourArea(cnt)
        x, y, w, h = cv2.boundingRect(cnt)
        if area > 50 and area < 1000:
            cv2.rectangle(mask, (x, y), (x + w, y + h), (255), -1)

    ###重新提取輪廓
    countours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    ###畫出所有輪廓
    for c in countours:
        cv2.drawContours(result, [c], 0, (0, 0, 255), 1)
    # cv2.imshow("Contour",result)

    ###定義NG輪廓總數閥值
    if len(countours) > 0:
        status = "NG"
    else:
        status = "NG"

    return result
