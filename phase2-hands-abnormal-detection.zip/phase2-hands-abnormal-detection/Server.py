from csv import list_dialects
from flask import Flask, render_template, Response, request, json, send_file, redirect, url_for
from Camera import Camera, perspective_transform
from Logger import *
from datetime import datetime
import cv2
import copy
import win32api
import numpy as np
import csv
from pathlib import Path

from Config import Frame, ServiceConfig, SrvCfg
from flask_login import LoginManager, UserMixin
from AIModule.SystemDetection import Hands
import sys
sys.path.insert(0, './AIModule/YOLOV5')

app = Flask(__name__)
login_manager = LoginManager()
login_manager.init_app(app)

class User(UserMixin):
    pass

def InitGlbVar():
    global camFrame

def iterate_detection_result_frame(camID: str, detectionModel: Hands) -> list:

    camInfo = ServiceConfig.allCamInfo.get(camID)
    camInstance = camInfo.get('instance')
    camAlarmCount = camInfo.get('alarmCount')
    
    while True:
        try:
            frame = camInstance.get_frame()
            frame = perspective_transform(frame, ServiceConfig.get_perspective_trans_coord(camID)) # 得到透視變換圖
            try:
                frame, judgeFlag = detectionModel.run(frame)
            except:
                judgeFlag = False
            if judgeFlag:
                camAlarmCount += 1 
                ServiceConfig.allCamInfo[camID]["alarmCount"] = camAlarmCount # 更改目前Cam的異常frame數
            yield Frame.encode(frame)
            if SrvCfg.noStreamCamID[camID] == True: # 原本沒訊號，後來有訊號
                SrvCfg.noStreamCamID[camID] = False
        except:
            yield Frame.encode(np.zeros((1280,720), dtype=np.uint8)) # 若沒有訊號，則回傳黑畫面
            if SrvCfg.noStreamCamID[camID] == False: # 原本有訊號，後來有沒訊號
                SrvCfg.noStreamCamID[camID] = True

def iteratate_cam_frame(camID: str) -> list:
    global camFrame
    camFrame = np.zeros((1280,720),dtype=np.uint8) 
    assert camID in ServiceConfig.allCamInfo.keys(), 'camID 不存在'
    camInstance = ServiceConfig.allCamInfo[camID].get('instance')
    while True:
        camFrame = camInstance.get_frame()
        bytesObject = Frame.encode(camFrame) # 轉成Bytes物件
        yield bytesObject
            
### 主頁面進入前的帳密登入頁面
@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        return render_template("login.html")
    user_id = request.form['user_id']
    if (user_id == SrvCfg.fabID + '_' + 'admin') and (request.form['password'] == 'zn123456'):
        return redirect(url_for('entrypoint'))
    
    win32api.MessageBox(0, "無法識別該用戶帳號及密碼\nThe username or password is not recognized.", "Authentication Error", 0x1000) #4096
    return render_template('login.html')

### 主頁面進入點
@app.route("/entrypoint", methods=['GET'])
def entrypoint():
    return render_template("index.html", eqID = SrvCfg.eqID, noStreamCamID = SrvCfg.noStreamCamID)

### 跳轉子頁面
@app.route("/sec_page", methods=['GET'])
def second_entrypoint():
    Logger.info("Requested /second_page")
    return render_template("sec_page.html", camList = ServiceConfig.get_cam_list(), noStreamCamID = SrvCfg.noStreamCamID)

@app.route("/initialize_html", methods=['POST'])
def initialize_html():
    if request.method == "POST":
        speakerFlag = dict()
        for key, value in ServiceConfig.allCamInfo.items():
            speakerFlag[key] = value.get("speakerFlag")
        return json.dumps(speakerFlag)

### 取得系統時間
@app.route("/now_time.txt")
def system_time_info():
    return datetime.now().strftime("%Y/%m/%d %H:%M:%S")

### 子頁面取得機台編號
@app.route("/get_eqID/<string:camID>")
def get_eqID(camID):
    return json.dumps(SrvCfg.eqID[camID])

### 子頁面的串流
@app.route("/feed_cam_frame/<string:camID>")
def feed_cam_frame(camID):
    return Response(iteratate_cam_frame(camID), mimetype="multipart/x-mixed-replace; boundary=frame")

############################################################################################ 未來可合併

### 第1個camera的串流含式(手部)
@app.route("/video_feed_1")
def video_feed_1():
    return Response(iterate_detection_result_frame("Cam1", HandsDetectionModel["Cam1"]),
		mimetype="multipart/x-mixed-replace; boundary=frame")

### 第2個camera的串流含式(手部)
@app.route("/video_feed_2")
def video_feed_2():
    return Response(iterate_detection_result_frame("Cam2", HandsDetectionModel["Cam2"]),
		mimetype="multipart/x-mixed-replace; boundary=frame")

### 第2個camera的串流含式(手部)
@app.route("/video_feed_3")
def video_feed_3():
    return Response(iterate_detection_result_frame("Cam3", HandsDetectionModel["Cam3"]),
		mimetype="multipart/x-mixed-replace; boundary=frame")

### 第2個camera的串流含式(手部)
@app.route("/video_feed_4")
def video_feed_4():
    return Response(iterate_detection_result_frame("Cam4", HandsDetectionModel["Cam4"]),
		mimetype="multipart/x-mixed-replace; boundary=frame")

### 第5個camera的串流含式(手部)
@app.route("/video_feed_5")
def video_feed_5():
    return Response(iterate_detection_result_frame("Cam5", HandsDetectionModel["Cam5"]),
		mimetype="multipart/x-mixed-replace; boundary=frame")

############################################################################################

@app.route("/sound_switch/<string:camID>") 
def sound_switch(camID):
    ServiceConfig.allCamInfo[camID]["speakerFlag"] = not ServiceConfig.allCamInfo[camID]["speakerFlag"]
    return json.dumps(ServiceConfig.allCamInfo[camID]["speakerFlag"])

### 取得手部狀態的函數，給前端使用(前端會一直呼叫這個函數)
@app.route("/detection_result/<string:camID>", methods=['POST']) 
def detection_result(camID):
    if request.method == "POST":
        assert camID in ServiceConfig.allCamInfo.keys(), 'camID 不存在'
        alarmCount = ServiceConfig.allCamInfo[camID].get("alarmCount")
        if alarmCount > 0:
            alarmCount -= 1
            ServiceConfig.allCamInfo[camID]["alarmCount"] = alarmCount
            return json.dumps({"flag":True, "eqID": SrvCfg.eqID.get(camID)})
        else:
            return json.dumps({"flag":False, "eqID": SrvCfg.eqID.get(camID)})
    else:
        raise BaseException("Http Request Error: /detection_result !!!!!")

### 得到透視變換座標點
@app.route("/get_perspective_trans_coord/<string:camID>", methods=['POST'])
def read_cam_config(camID):
    if request.method == "POST":
        coordinate = ServiceConfig.get_perspective_trans_coord(camID)
        return json.dumps(coordinate)
    else:
        raise BaseException("Http Request Error: /get_perspective_trans_coord !!!!!")

### 得到透視變換圖
@app.route("/get_perspective_trans_img/<string:camID>", methods=['GET'])
def get_perspective_trans_img(camID):
    coordinate = ServiceConfig.get_perspective_trans_coord(camID)
    warpedImg = perspective_transform(camFrame, coordinate)
    fileObject = Frame.transform_virtual_file(warpedImg)
    return send_file(fileObject, mimetype='image/PNG')
  
### 手部座標點寫入json
@app.route("/save_perspective_trans_coord/<string:camID>", methods=['POST'])
def coordinate_submit(camID):
    if request.method == "POST":
        coordinate = request.get_json(force=True)
        ServiceConfig.save_perspective_trans_coord(camID, coordinate)
        return "OK"
    else:
        raise BaseException("Http Request Error: /save_perspective_trans_coord !!!!!")

### 子頁面的console寫入txt
@app.route("/download_console", methods=["POST"])
def download_console():
    if request.method == "POST":
        data = request.get_json(force=True)
        ServiceConfig.write_config(data['text'], data['consoleType'])    
        return "OK"
    else:
        raise BaseException("Http Request Error: /download_console !!!!!")

### 子頁面的console讀取txt
@app.route("/read_console_config", methods=['POST'])
def read_consoleInfo():
    if request.method == "POST":
        consoleType = request.get_json(force=True)
        data = ServiceConfig.get_console_config(consoleType)
        return json.dumps(data) 
    else: # status code 405
        raise BaseException("Http Request Error: /read_console_config !!!!!")

@app.route('/api/QueryLogData', methods=['GET'])
def query_log_data():
    data = request.get_json(force=True)
    logData = get_log_data(data)
    return Response(json.dumps(logData), mimetype='application/json')

def get_log_data(requestData):

    ### parse request data
    startDate = requestData["start_date"]
    endDate = requestData["end_date"]
    # mode = requestData["mode"]
    datePathList = get_date_folder_list(startDate, endDate)
    ### declare response data
    responseData = dict()
    dataDict = dict()
    infoDict = dict()
    ### initial responseData
    dataDict["data_infos"] = list()
    responseData["status"] = "success" if check_request_condition(requestData, startDate, endDate) else "Fail"
    responseData["data"] = dict()
    responseData["message"] = "null" if check_request_condition(requestData, startDate, endDate) else "Request Condition Fail"
    seqCount = 1
    try:
        if responseData["status"] == "success":
            for logPath in datePathList:
                logFile = Path(logPath).joinpath('alarm_logs.csv')
                if logFile.exists():
                    with open(logFile, newline='') as csvfile:
                        # 讀取 CSV 檔案內容
                        rows = csv.DictReader(csvfile)
                        # 以迴圈輸出每一列
                        for row in rows:
                            if check_time_on_interval(row["date_time"], startDate, endDate):
                                infoDict["seq_id"] = seqCount
                                infoDict["fab_id"] = row["fab_id"]
                                infoDict["eq_id"] = row["eq_id"]
                                infoDict["error_description"] = row["error_msg"]
                                fileName = Path(row["record_path"]).name
                                infoDict["record_path"] =  str(Path(SrvCfg.mountPath).joinpath(fileName))
                                infoDict["date_time"] = row["date_time"].replace("T", "  ")
                                dataDict["data_infos"].append(infoDict.copy())   # add a row data
                                infoDict.clear()    # clean
                                seqCount += 1 
            responseData["data"] = dataDict
            print("Call Log Data successfully!")

    except Exception as err:
        responseData["message"] = str(err)
        responseData["status"] = "Error"
        print("Call Log Data Fail...")
    return responseData

def check_request_condition(requestData, startDate, endDate):
    checkFlag = True
    ### check length = 2 (start_date/end_date)
    checkFlag = checkFlag if len(requestData) == 2 else False    
    ### check date format
    start = startDate.replace("T", "").replace(":", "")
    end = endDate.replace("T", "").replace(":", "")
    checkFlag = checkFlag if start <= end else False 
    checkFlag = checkFlag if "T" in startDate and "T" in endDate else False 
    return checkFlag

def check_time_on_interval(sourceDate, startDate, endDate):
    timeFlag = False
    source = sourceDate.replace("/", "").replace("T", "").replace(":", "")
    start = startDate.replace("T", "").replace("-", "").replace(":", "")
    end = endDate.replace("T", "").replace("-", "").replace(":", "")
    timeFlag = True if source >= start and source <= end else False
    return timeFlag

def get_date_folder_list(startDate, endDate):
    folderList = []
    start = startDate.split("T")[0].replace("-", "")
    end = endDate.split("T")[0].replace("-", "")
    localPath = SrvCfg.recordPath
    pathList = Path(localPath).glob('**/*')
    for filePath in pathList:
        if filePath.is_dir() and len(filePath.name) == 8 and filePath.name >= start and filePath.name <= end:   # length YYYYMMDD = 8
            folderList.append(filePath)
    return folderList

if __name__=="__main__":

    ### set parameter
    InitGlbVar()
    
    ### Log Module Config
    Logger.config(
        logTypes=LogType.Console | LogType.File,
        consoleLogConfig=ConsoleLogConfig(
            level=LogLevel.WARNING,
        ),
        fileLogConfig=FileLogConfig(
            level=LogLevel.INFO,
            newline=False,
            dirname=SrvCfg.recordPath,
            suffix="debug",
        )
    )
    
    print("Welcome to AUO Vision Guard V2.1.0...")

    # 檢查透視變換座標json檔是否存在
    ServiceConfig.check_json_file_existence()

    ### 建立檢測模型
    HandsDetectionModel = dict()
    HandsDetectionModel["Cam1"] = Hands(SrvCfg.handsThres, "ABF", "Cam1")
    HandsDetectionModel["Cam2"] = Hands(SrvCfg.handsThres, "ABF", "Cam2")
    HandsDetectionModel["Cam3"] = Hands(SrvCfg.handsThres, "ABF", "Cam3")
    HandsDetectionModel["Cam4"] = Hands(SrvCfg.handsThres, "ABF", "Cam4")
    HandsDetectionModel["Cam5"] = Hands(SrvCfg.handsThres, "ABF", "Cam5")
    
    ### 初始化所有camera
    # global allCamInfo
    for cameraID in ServiceConfig.get_cam_list():
        camInstance = Camera(video_source=SrvCfg.handsSource[cameraID])
        camInstance.run() 
        ServiceConfig.allCamInfo[cameraID] =  {"instance":camInstance, "alarmCount":0, "speakerFlag":True}
        Logger.info(f"Loading camera1 from {SrvCfg.handsSource[cameraID]}")

    ### Build Web Server
    Logger.info("Starting Web Server...")
    app.run(host=SrvCfg.host, port=SrvCfg.port)
