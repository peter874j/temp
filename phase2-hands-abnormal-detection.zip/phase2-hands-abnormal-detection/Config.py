import io
import configparser
from re import A
import numpy as np
from pathlib import Path
import os
from datetime import datetime
import cv2
from PIL import Image
import json
import re

from AIModule.ObjectUtils import BBox

class SrvCfg:
	__parser = configparser.ConfigParser()
	__parser.read('./config/setting.cfg')

	### section names
	__source = __parser['Source']
	__target = __parser['Target']
	__weights = __parser['Weights']
	__equipmentID = __parser['EquipmentID']
	__threshold = __parser['Threshold']
	__sound = __parser['Sound']
	__alarm = __parser['AlarmInfo']
	__fileScheduling = __parser['FileScheduling']

	### items in section
	handsSource = {'Cam1':__source['CAM1'], 'Cam2':__source['CAM2'], 'Cam3':__source['CAM3'], 'Cam4':__source['CAM4'], 'Cam5':__source['CAM5']}

	# 存入沒有串流的Camera ID，提供給前端使用 #
	noStreamCamID = dict()
	for key, value in handsSource.items():
		noStreamCamID[key] = True if value == "None" else False
	######################################################

	port = int(__source['port'])
	host = __source['host']

	recordPath = __target['recordPath']
	mountPath = __target['mountPath']
	perspectiveTransCoordPath = __target['perspectiveTransCoordPath']
	handsWeight = __weights['hands']

	eqID = {'Cam1':__equipmentID['CAM1'], 'Cam2':__equipmentID['CAM2'], 'Cam3':__equipmentID['CAM3'], 'Cam4':__equipmentID['CAM4'], 'Cam5':__equipmentID['CAM5']}
	handsThres = {'ABF':int(__threshold['ABFPixels']), 'BT':int(__threshold['BTPixels']), 'degree':float(__threshold['degree']), 'stayFPS':int(__threshold['stayFPS'])}

	soundOfHandsAlert = __sound['audio']
	AMSSwitch = __alarm['AMSSwitch']
	fabID = __alarm['fabID']
	process = __alarm['process']
	alarmMessage = __alarm['alarmMessage']

	maxMBSize = int(__fileScheduling['maxMBSize'])
	maxDays = int(__fileScheduling['maxDays'])

class ServiceConfig:

	allCamInfo = dict()

	# 確認有無紀錄透視變換座標的json檔，若無則建立json檔，寫入所有攝影機ID
	@staticmethod
	def check_json_file_existence() -> None:
		path = SrvCfg.perspectiveTransCoordPath
		if not os.path.isfile(path):
			list = []
			with open(path, 'w') as file:
				for index in range(1, 6):  ##### 要想怎麼確認目前有幾台攝影機 暫時寫5台 (看RTSP個數)
					list.append({'Cam%d'%index:[[1,1],[1,1],[1,1],[1,1]]})
				json.dump(list, file)

	# 從紀錄透視變換座標的json檔得到攝影機列表 List = [cam1, cam2, cam3, ...]	
	@staticmethod		
	def get_cam_list() -> list:
		path = SrvCfg.perspectiveTransCoordPath
		camList = []
		with open(path, 'r') as file:
			jsonContents = json.load(file)
			for camInfo in jsonContents:
				for key in camInfo.keys():
					if re.match("Cam", key):
						camList.append(key)
			return camList

	# 獲得透視變換座標點
	@staticmethod
	def get_perspective_trans_coord(camID: str) -> list:
		path = SrvCfg.perspectiveTransCoordPath
		with open(path, 'r') as file:
			jsonContents = json.load(file)
			index = int(camID.translate({ord(i):None for i in 'Cam'})) - 1
			return jsonContents[index][camID]
	
	# 儲存透視變換座標點
	@staticmethod
	def save_perspective_trans_coord(camID: str, coordinate: list) -> None:
		path = SrvCfg.perspectiveTransCoordPath

		# 預先讀取json檔內容，存在變數中
		with open(path, 'r') as file:
			jsonContents = json.load(file)

		# 更改jsons內容，並寫入json
		with open(path, 'w+') as file:
			index = int(camID.translate({ord(i):None for i in 'Cam'})) - 1
			try: # 若key (key="cam1") 已存在，則直接改value
				jsonContents[index][camID] = coordinate
			except:  # 若key不存在，則新增此筆資料
				newCamCoord = {camID: coordinate}
				jsonContents.append(newCamCoord)
			json.dump(jsonContents, file)

	@staticmethod
	def write_config(data, type):
		dateFormat = "%Y/%m/%d"
		dateText = datetime.now().strftime(dateFormat)
		### 處理hand、motion txt
		if isinstance(data, list):
			with open('config/{}.txt'.format(type), 'w') as f:
				f.write(('\n').join(data)) 
		else:
			### 處理console txt
			dateInfo = dateText.replace('/','')
			savePath = os.path.join(SrvCfg.recordPath, dateInfo) 
			Path(savePath).mkdir(parents=True, exist_ok=True)
			consoleFile = os.path.join(savePath, f'{type}.txt')
			with open(consoleFile, 'a+') as f:
				f.write(data + '\n') 

	#獲得console內容
	@staticmethod
	def get_console_config(type):
		date = datetime.now().strftime('%Y%m%d')	
		path = f"{SrvCfg.recordPath}/{date}"
		file = os.path.join(path, f'{type}.txt') 
		Path(f"{SrvCfg.recordPath}/{date}").mkdir(parents=True, exist_ok=True) #建立資料夾
		Path(file).touch() #建立txt
		with open(file, 'r') as f:
			contents = f.readlines()      
			return contents


class Frame:
	@staticmethod
	def draw_rectangle_in_zone(frame):
		for BBox in Frame.BBoxInfo:
			pts = np.array([[BBox.pointOfTopLeft.x, BBox.pointOfTopLeft.y], [BBox.pointOfTopRight.x, BBox.pointOfTopRight.y],
			 					[BBox.pointOfBottomLeft.x, BBox.pointOfBottomLeft.y], [BBox.pointOfBottomRight.x, BBox.pointOfBottomRight.y]], np.int32)
			cv2.polylines(frame, [pts], True, (0,0,255), 5)
			cv2.putText(frame, BBox.zoneName, (BBox.pointOfTopLeft.x, BBox.pointOfTopLeft.y), cv2.FONT_HERSHEY_DUPLEX, 2, (0, 255, 255), 3, cv2.LINE_AA)

	@staticmethod
	def transform_virtual_file(frame):
		frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
		frame = Image.fromarray(frame.astype('uint8'))
		file_object = io.BytesIO()
		frame.save(file_object, 'PNG')
		file_object.seek(0)
		return file_object

	@staticmethod
	def encode(frame):
		frame = cv2.imencode('.png', frame)[1].tobytes()
		frame = (b'--frame\r\n'b'Content-Type: image/png\r\n\r\n' + frame + b'\r\n')
		return frame
