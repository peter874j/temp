from abc import ABC, abstractmethod, abstractstaticmethod
import numpy as np
import math
import cv2
from threading import Thread
import copy
import sys
from datetime import datetime

sys.path.append('./AIModule')
from AIModule.YoloModel import HandsYoloModel
from Alarm import HandsSound, AlarmUtils
from YOLOV5.utils.plots import plot_fail_touch
from Config import SrvCfg

######################################################################################### 手部檢測
class Hands:

    def __init__(self, thresholdInfo, productID, camID: str):
        """initialize parameter

        Args:
            model (torch): YOLOv5 Model
        """        
        self.model = HandsYoloModel.build()
        self.alarmSound = HandsSound(camID)
        self.alarmUtils = AlarmUtils(camID)
        self.pixelThres = thresholdInfo[productID]
        self.clipThres = 15
        self.degree = thresholdInfo['degree']
        self.overlapThres = thresholdInfo['stayFPS']
        self.NGFlag = None 
        self.lastNGImg = None 
        self.lastTimeText = 'init'
        self.lastAlarmTime = datetime(1911, 1, 1, 1, 1, 1)
        self.overlapCounts = 0
        self.preMaskBoxes = []
        self.frameLock = True
        
    def run(self, image):
        """Stream Hands Abnomal Detection

        Args:
            image (img): perspective image

        Returns:
            img: resultsImg
        """        
        streamImg = image.copy()
        resultsImg = None
        IOUThresh = 0.25
        yoloResult = self.model.detect(image)
        ### initial last NG image
        if self.NGFlag == None:
            self.lastNGImg = cv2.imread('config/idle.jpg')   
        ### last  NG Img resize
        if self.lastNGImg.shape != streamImg.shape:
            self.lastNGImg = cv2.resize(self.lastNGImg, (streamImg.shape[1], streamImg.shape[0]), interpolation=cv2.INTER_AREA)

        ### reload pixel config

        ### draw system time on image
        dateFormat = "%Y/%m/%d %H:%M:%S"
        nowTime = datetime.now()
        AlarmInterval = (nowTime - self.lastAlarmTime).total_seconds()
        dateText = nowTime.strftime(dateFormat)

        (imgH, imgW, _) = streamImg.shape
        self.pixelThres = self.normalize_distance_threshold(self.pixelThres, imgW)   # pixel 正規化
        # fontScale = imgH * imgW / (450 * 450)
        # thickness = max(int(2 * imgH * imgW / (450 * 450)), 2)
        # t_size = cv2.getTextSize(dateText, 0, fontScale=fontScale, thickness=thickness)[0]
        # xCoords = int(0.05 * imgW)
        # yCoords = int(imgH - t_size[1])
        # cv2.putText(streamImg, dateText, (10, streamImg.shape[1] - 30), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 0, 0), 2)
        # cv2.putText(streamImg, dateText, (xCoords, yCoords), cv2.FONT_HERSHEY_SIMPLEX, fontScale, (255, 0, 0), thickness)

        ### YOLO Predict PCB and Gloves
        if len(yoloResult['PCB']) > 0 and len(yoloResult['Gloves']) > 1:
            streamImg, inPlateMask, self.NGFlag, centerFlag = self.check_hands_touch(streamImg, yoloResult['PCB'], yoloResult['Gloves'], self.pixelThres, self.clipThres, self.degree)
        else:
            self.NGFlag = False
            centerFlag = False

        ### Record NG Image
        judgeFlag = False
        if self.NGFlag and centerFlag:
            streamImg = self.draw_mask_on_image(streamImg, inPlateMask)
            ### on the same second & alarm time interval over than 3 seconds
            if dateText == self.lastTimeText and AlarmInterval >= 3:  
                if not self.frameLock:
                    ### calcullate IOU between preFrame and currentFrame
                    maskBoxes = self.get_mask_box(inPlateMask)
                    for box1 in maskBoxes:
                        for box2 in self.preMaskBoxes:
                            boxIOU = self.get_iou(box1, box2)
                            if boxIOU >= IOUThresh:    # continuous touching
                                self.overlapCounts += 1
                                if self.overlapCounts >= self.overlapThres:
                                    judgeFlag = True
                                    self.overlapCounts = 0
                                    self.lastAlarmTime = nowTime
                                    self.preMaskBoxes = []
                                    self.frameLock = True
                                    plot_fail_touch(streamImg, yoloResult['PCB'], self.pixelThres, color=None, line_thickness=3)
                                    self.lastNGImg = streamImg
                                    self.alarmUtils.save_frame(self.lastNGImg, dateText, SrvCfg.recordPath)
                                    self.alarmUtils.save_log(dateText, SrvCfg.recordPath)
                                    self.alarmUtils.save_frame(self.lastNGImg, dateText, SrvCfg.mountPath)
                                    self.alarmUtils.save_log(dateText, SrvCfg.mountPath)
                                    ### Trigger Alert
                                    thread = Thread(target=self.alarmSound.play())
                                    thread.start()
                                    self.alarmUtils.send_AMS()
                                    break
                        else:
                            continue
                        break
                    self.preMaskBoxes = maskBoxes
            else:
                self.lastTimeText = dateText
                self.preMaskBoxes = []
                self.frameLock = False

        resultsImg = np.hstack((streamImg, self.lastNGImg))   # Concatenate Stream & History Abnomal Image
        return resultsImg, judgeFlag

    ### CV Judge Hands Touch Mask
    def check_hands_touch(self, image, PCBBoxes, glovesBoxes, pixelThres, clipThres, glovesDegree):
        """hands touch check function

        Args:
            image (img): Original BGR Image 
            PCBBoxes (list): PCB YOLO Bounding Box
            glovesBoxes (list): Gloves YOLO Bounding Box
            pixelThres (int): Inner Pixels Values
            glovesDegree (float): detection range of gloves

        Returns:
            [img]: image
            [img]: inPlateMask
            [bool]: touchFlag
            [bool]: centerFlag
        """
        touchFlag = False
        centerFlag = False
        (imgH, imgW, _) = image.shape
        ### check PCB board
        if self.check_iron_board(image, PCBBoxes):
            inPlateMask = np.zeros((imgH, imgW), np.uint8)
            return image, inPlateMask, touchFlag, centerFlag
        ### Mask of PCB、Gloves
        inPlateMask = np.zeros((imgH, imgW), np.uint8)
        PCBMask = np.zeros((imgH, imgW), np.uint8)
        glovesImg = np.zeros((imgH, imgW, 3), np.uint8)
        PCBMask[int(PCBBoxes[1]) + pixelThres + clipThres:int(PCBBoxes[3]) - pixelThres - clipThres, int(PCBBoxes[0]) + pixelThres:int(PCBBoxes[2])- pixelThres] = 255
        ### Mask of GlovesL、GlovesR
        lowerGloves = np.array([150, 150, 150])   # BGR
        upperGloves = np.array([255, 255, 255])   # BGR
        glovesMask = self.get_gloves_mask(image, glovesBoxes, glovesDegree, lowerGloves, upperGloves)

        ### Bitwise PCB&Gloves Mask
        inPlateMask = cv2.bitwise_and(PCBMask, glovesMask)
        inPlatePixels = np.sum(inPlateMask)

        ### Place the PCB Center Check
        # radius = 0.5 * pixelThres
        radius = 0.5 * 13
        midPCB = [0.5 * int(PCBBoxes[0] + PCBBoxes[2]), 0.5 * int(PCBBoxes[1] + PCBBoxes[3])]
        midImg = [0.5 * imgW - 1, 0.5 * imgH - 1]
        midDiff = np.array(midPCB) - np.array(midImg)
        midDistance = math.hypot(midDiff[0], midDiff[1])
        centerFlag = True if (midDistance <= radius) else False
        touchFlag = True if inPlatePixels else False

        ### dilate inPlateMask
        kernel = np.ones((3, 3),np.uint8)
        inPlateMask = cv2.dilate(inPlateMask, kernel, iterations=1)

        return image, inPlateMask, touchFlag, centerFlag

    def get_gloves_mask(self, image, glovesBoxes, glovesDegree, lowerGloves, upperGloves):
        (imgH, imgW, _) = image.shape
        glovesDegreeImg = np.zeros((imgH, imgW, 3), np.uint8)
        for BBox in glovesBoxes:
            halfBBoxH = int((1 - glovesDegree) * (BBox[3] - BBox[1]))
            # halfbBoxW = int((1 - glovesDegree) * (BBox[2] - BBox[0]))
            glovesDegreeImg[int(BBox[1]):int(BBox[3] - halfBBoxH), int(BBox[0]):int(BBox[2])] = image[int(BBox[1]):int(BBox[3] - halfBBoxH), int(BBox[0]):int(BBox[2])]
        glovesMask = cv2.inRange(glovesDegreeImg, lowerGloves, upperGloves)
        # Open Operation
        kernel = np.ones((3, 3),np.uint8)
        glovesMask = cv2.morphologyEx(glovesMask, cv2.MORPH_OPEN, kernel)   
        return glovesMask

    ### Draw Gloves Mask on Image
    def draw_mask_on_image(self, img, maskImg):
        (imgH, imgW, _) = img.shape
        zeroMask = np.zeros((imgH, imgW), np.uint8)
        backgroundMask = cv2.bitwise_not(maskImg)
        backgroundImg = cv2.bitwise_and(img, img, mask=backgroundMask)
        touchImg = cv2.merge([zeroMask, zeroMask, maskImg])
        resultImg = cv2.add(backgroundImg, touchImg)
        return resultImg

    ### get touch image
    def get_mask_box(self, maskImg):
        maskBoxes = []
        # cv2.findContours: 找到ROI的輪廓
        contours, hierarchy = cv2.findContours(maskImg, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        for i in range(0, len(contours)):
            # 輸出：(x, y)矩形左上角座標、w 矩形寬(x軸方向)、h 矩形高(y軸方向)
            x, y, w, h = cv2.boundingRect(contours[i])
            maskBoxes.append([x, y, x + w, y + h])
        return maskBoxes

    def get_iou(self, boxA, boxB):

        # determine the (x, y)-coordinates of the intersection rectangle
        xA = max(boxA[0], boxB[0])
        yA = max(boxA[1], boxB[1])
        xB = min(boxA[2], boxB[2])
        yB = min(boxA[3], boxB[3])

        # compute the area of intersection rectangle
        interArea = abs(max((xB - xA, 0)) * max((yB - yA), 0))
        if interArea == 0:
            return 0
        # compute the area of both the prediction and ground-truth
        # rectangles
        boxAArea = abs((boxA[2] - boxA[0]) * (boxA[3] - boxA[1]))
        boxBArea = abs((boxB[2] - boxB[0]) * (boxB[3] - boxB[1]))

        # compute the intersection over union by taking the intersection
        # area and dividing it by the sum of prediction + ground-truth
        # areas - the interesection area
        iou = interArea / float(boxAArea + boxBArea - interArea)

        # return the intersection over union value
        return iou

    ### check iron board
    def check_iron_board(self, img, PCBBoxes):

        ironBoardFlag = False
        ironBoardImg = img.copy()
        ironBoardImg = ironBoardImg[int(PCBBoxes[1]):int(PCBBoxes[3]), int(PCBBoxes[0]):int(PCBBoxes[2])]
        (imgH, imgW, _) = ironBoardImg.shape
        lowerPCB = np.array([0, 0, 0])   # BGR
        upperPCB = np.array([100, 100, 100])   # BGR
        ironPCBMask = cv2.inRange(ironBoardImg, lowerPCB, upperPCB)
        if np.sum(ironPCBMask)/255 > 0.5 * imgH * imgW:
            ironBoardFlag = True
        return ironBoardFlag

    ### distance threshold normalization
    def normalize_distance_threshold(self, pixelThres, imgW):
        
        offset = 60  # Jig機台實際距離(cm)
        ### 暫時解
        transPixelThres = pixelThres * int(round(imgW / 335))

        return transPixelThres
