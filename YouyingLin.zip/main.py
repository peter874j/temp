# -*- coding: utf-8 -*-
"""
Created on Fri Nov 18 13:42:33 2022

@author: YouyingLin
"""

import os
import sys
import cv2
import csv
#import time
#import serial
import threading
import numpy as np
# import pandas as pd
# import configparser

# from PIL import ImageQt
from PyQt5 import QtWidgets, QtGui, QtCore

from PyQt5.QtCore import *
from PyQt5.QtCore import QRect, QPoint, Qt, pyqtSignal, QObject, QThread, QTimer, QDateTime
from PyQt5.QtGui import *
from PyQt5.QtGui import QImage, QPixmap, QPainter, QPen, QGuiApplication, QFont
from PyQt5.QtWidgets import QLabel, QFileDialog, QMainWindow, QMessageBox, QComboBox, QMenuBar, QMenu, QAction, QWidget, QSlider, QVBoxLayout

from Local_UI import Ui_MainWindow
from defect_detection import flaw_detect


class MainWindow(QtWidgets.QMainWindow):
    def __init__(self):
        global ok_count, ng_count
        super(MainWindow, self).__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.setWindowFlags(Qt.WindowCloseButtonHint)
        
        
        
        self.timer=QTimer()
        self.timer.timeout.connect(self.showtime)#這個通過呼叫槽函式來重新整理時間
        self.timer.start(1000)
        
        self.N = 4
        self.cap = []
        self.flag_printer = 0  # 噴墨訊號
        
        self.init_ui()

        
    def init_ui(self):
        
        self.ui.label_logo.setPixmap(QtGui.QPixmap("auo.jpg"))
        self.ui.label_logo.setScaledContents(True)
        
        self.open_cameras_clicked()
        self.timer_camera = QTimer()
        self.timer_camera.timeout.connect(self.show_camera)
        self.timer_camera.start(33) # 1s又等於1000ms，所以平均每幀的生成時間為1000/30=33ms
        
        self.ui.Btn_Printer.clicked.connect(self.printer_set)  
        self.ui.Btn_Printer.setCheckable(True)
        
        self.ui.Btn_Check.clicked.connect(self.log_check)
        
    def showtime(self):
        time=QDateTime.currentDateTime()#獲取當前時間
        timedisplay=time.toString("yyyy-MM-dd hh:mm:ss")#格式化一下時間
        self.ui.label_time.setText(timedisplay)
        
    def open_cameras_clicked(self):
        print(self.N)
        for i in range(self.N):
            temp = cv2.VideoCapture(i, cv2.CAP_DSHOW)
            temp.set(cv2.CAP_PROP_FRAME_WIDTH, 640)  
            temp.set(cv2.CAP_PROP_FRAME_HEIGHT, 480) 
            temp.set(cv2.CAP_PROP_FPS, 30) # 解決延遲:CAP_PROP_FPS必須在CAP_PROP_FOURCC之前設置
            temp.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc('M', 'J', 'P', 'G'))
            
            if temp.isOpened() == True:
                self.cap.append(temp)
                print('Open cameras x ' + str(i))
            else:
                print("oh")
                temp.release()
            
    def printer_set(self, event):
        if self.ui.Btn_Printer.isChecked():
            self.ui.Btn_Printer.setStyleSheet("background-color: red");
            self.flag_printer = 1

        else:
            self.ui.Btn_Printer.setStyleSheet("background-color: green");
            self.flag_printer = 0

            
            
    def show_camera(self): 
        len_cap = len(self.cap)
        if len_cap != 0:
            for i in range(len_cap): 
                if i == 0:
                    ret1 ,frame1 = self.cap[i].read()
                    if ret1:
                        # frame1 = flaw_detect(frame1)
                        frame1 = self.webcam_display(frame1)
                        self.ui.top_cam1.setPixmap(frame1)
                        self.ui.top_cam1.setScaledContents(True)
                        
                elif i == 1:
                    ret2 ,frame2 = self.cap[i].read()
                    if ret2:
                        # frame2 = flaw_detect(frame2)
                        cv2.imshow("frame2",frame2)
                        frame2 = self.webcam_display(frame2)
                        self.ui.top_cam2.setPixmap(frame2)
                        self.ui.top_cam2.setScaledContents(True)       
                        
                elif i == 2:
                    ret3 ,frame3 = self.cap[i].read()
                    if ret3:
                        # frame3 = flaw_detect(frame3)
                        frame3 = self.webcam_display(frame3)
                        self.ui.btm_cam1.setPixmap(frame3)
                        self.ui.btm_cam1.setScaledContents(True)
                        
                elif i == 3:
                    ret4 ,frame4 = self.cap[i].read()
                    if ret4:
                        # frame4 = flaw_detect(frame4)
                        frame4 = self.webcam_display(frame4)
                        self.ui.btm_cam2.setPixmap(frame4)
                        self.ui.btm_cam2.setScaledContents(True)
               
 
    
    def webcam_display(self, frame):
        ''' 處理OpenCV圖片轉QPixmap '''
        height, width, depth = frame.shape
        frame = cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)
        cvimg = QImage(frame.data, frame.shape[1], frame.shape[0], frame.shape[1] * 3, QImage.Format_RGB888)
        return QPixmap.fromImage(cvimg)

    def log_check(self):
        now_time = QDateTime.currentDateTime()
        date = now_time.toString("yyyyMMdd") 
        folder_path = QFileDialog.getExistingDirectory(self,
                  "Open folder",
                  "./log/"+date)                 # start path
        print(folder_path)

    
    def closeEvent(self, event):
        self.timer_camera.stop()
        len_cap = len(self.cap)
        if len_cap != 0:
            for i in range(len_cap):
                self.cap[i].release()
        self.cap = []

if __name__ == '__main__': 
     app = QtCore.QCoreApplication.instance()
     if app is None:
        app = QtWidgets.QApplication(sys.argv)
     window = MainWindow()
     window.show()  
     
     sys.exit(app.exec_())
     