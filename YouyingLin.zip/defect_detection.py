# -*- coding: utf-8 -*-
"""
Created on Fri Nov 25 14:13:28 2022

@author: YouyingLin
"""

import os
import cv2 
import time
import numpy as np


def flaw_detect(image):
    
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    blur = cv2.medianBlur(gray, 5)
    edges = cv2.Canny(blur, 20, 50)  
    width, height, channel = image.shape

    countours, hierarchy = cv2.findContours(edges, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    result = image.copy()
    mask = np.zeros(edges.shape[:2],dtype=np.uint8)
    for cnt in countours:
        area = cv2.contourArea(cnt) 
        x,y,w,h  = cv2.boundingRect(cnt)

        if area >10 and area <100:
            cv2.rectangle(mask,(x,y),(x+w,y+h),(255), -1)
#    cv2.imshow("mask",mask)
    
    countours,hierarchy = cv2.findContours(mask,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
    for c in countours:
        cv2.drawContours(result, [c], 0, (0,0,255), 1)
#    cv2.imshow("Contour",result)

    if len(countours) > 0:
        status = "NG"
    else:
        status = "NG"

    return result
            

    cv2.waitKey(0)
    cv2.destroyAllWindows()