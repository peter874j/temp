
import os
import cv2
import numpy as np

def modify_contrast_and_brightness(img, brightness , contrast):
    import math
    
    B = brightness / 255.0
    c = contrast / 255.0 
    k = math.tan((45 + 44 * c) / 180 * math.pi)

    img = (img - 127.5 * (1 - B)) * k + 127.5 * (1 + B)

    # 所有值必須介於 0~255 之間，超過255 = 255，小於 0 = 0
    img = np.clip(img, 0, 255).astype(np.uint8)

    return img

def flood_fill(image):
    im_floodfill = image.copy()
    h, w = image.shape[:2]
    mask = np.zeros((h+2, w+2), np.uint8)
    
    isbreak = False
    for i in range(im_floodfill.shape[0]):
        for j in range(im_floodfill.shape[1]):
             if(im_floodfill[i][j]==0):
                seedPoint=(i,j)
                isbreak = True
                break
        if(isbreak):
            break              
    cv2.floodFill(im_floodfill, mask, seedPoint, 255, cv2.FLOODFILL_MASK_ONLY)
    im_floodfill_inv = cv2.bitwise_not(im_floodfill)
    im_out = image | im_floodfill_inv
    return im_out
###############################################

fileDir = r'C:\Users\WYLee\Desktop\circle'
fileName = "10142022102448" + ".jpg"
filePath = os.path.join(fileDir, fileName)

img = cv2.imread(filePath)
h, w, c = img.shape

gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
# cv2.imshow('gray',gray)

# clahe = cv2.createCLAHE(clipLimit=2.0)
# n_img = clahe.apply(gray)
# cv2.imshow('n_img',n_img)

x = cv2.Sobel(gray, cv2.CV_16S, 1, 0)
y = cv2.Sobel(gray, cv2.CV_16S, 0, 1)
absX = cv2.convertScaleAbs(x)# 轉回uint8
absY = cv2.convertScaleAbs(y)
dst = cv2.addWeighted(absX, 0.5, absY, 0.5, 0)
cv2.imshow('dst',dst)

blur = cv2.medianBlur(dst, 5)

# canny = cv2.Canny(blur, 30, 60)
# cv2.imshow('canny',canny)

############### HOUGH圓 ################
circles= cv2.HoughCircles(blur, cv2.HOUGH_GRADIENT, 1, minDist=80, param1=100, param2=60, minRadius=80, maxRadius=250)
# circles= cv2.HoughCircles(canny, cv2.HOUGH_GRADIENT, 1, 130, param1=100, param2=60, minRadius=40,maxRadius=90)
for circle in circles[0]:
    #圓的基本資訊
    # print(circle[2])
    #座標行列
    x=int(circle[0])
    y=int(circle[1])
    #半徑
    r=int(circle[2])
    #在原圖用指定顏色標記出圓的位置
    cv2.circle(img,(x,y),r,(0,0,255),1)
cv2.imshow('res',img)



cv2.waitKey(0)
cv2.destroyAllWindows()

